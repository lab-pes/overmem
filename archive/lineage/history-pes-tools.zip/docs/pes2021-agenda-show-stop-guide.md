# Guia de análise: agenda anual e regra de `show + stop` no PES 2021

## Objetivo

O objetivo atual não é mais "achar datas especiais".

O objetivo é reconstruir a lógica pela qual o jogo:

1. reconhece que uma data tem um evento relevante
2. decide se essa data deve aparecer para o jogador
3. decide se a simulação deve parar nessa data

Em termos de negócio, queremos sair de:

- `raw marker`

para:

- `evento semântico`
- `data visível ao jogador`
- `stop-day real`

## O que já sabemos

Hoje o modelo de calendário já está separado em camadas:

1. `main calendar`
   - base de partidas e rodadas

2. `secondary calendar`
   - marcadores de dia, placeholders, headers e pontes de agenda

3. `runtime/UI`
   - a agenda efetivamente carregada para a tela e para o fluxo de avanço do tempo

Também já sabemos que essas camadas não são equivalentes:

- há dias que existem semanticamente no `secondary`, mas não aparecem como partida materializada
- há dias que aparecem na UI por projeção/runtime
- há dias que já foram inferidos por heurística antiga, mas não têm materialização própria no save-side bruto

Exemplo importante:

- `2026-12-01`
  - jogo de campeonato materializado no calendario
  - tratar como `calendar-match-day`, nao como evento anual de premio
- `2026-12-02`
  - anuncio do premio de melhor jogador do mundo
  - pausa real e linha visivel confirmadas; normalizar como evento semantico especifico (`semantic-event-day`), nao como familia generica de dezembro
- `2026-12-05`
  - controle negativo para essa normalizacao
  - nao promover a stop-day sem linha/evento materializado
- `2026-12-11`, `2026-12-13`
  - controles negativos do heurístico antigo
  - tratá-los como falsos positivos até nova evidência

## Princípio de trabalho

Toda análise deve respeitar a seguinte ordem de confiança:

1. `raw save-side evidence`
   - bytes, headers, counts, items, records

2. `cross-check with visible UI behavior`
   - aparece para o usuário?
   - para a simulação?

3. `runtime-only evidence`
   - clusters, caches, projeções, estado de navegação

4. `legacy reader heuristics`
   - só usar quando explicitamente marcadas como heurística

Se houver conflito entre:

- nome herdado do reader antigo
- dado bruto atual do save/processo

o dado bruto vence, e o nome herdado deve ser rebaixado para hipótese ou heurística legada.

## Perguntas que estamos tentando responder

A análise atual tenta responder, nesta ordem:

1. qual é a fonte bruta do evento?
2. esse evento é visível ao jogador?
3. esse evento para a simulação?
4. qual camada faz a projeção entre marker bruto e dia efetivo visível?
5. qual regra faz o motor decidir `show + stop`?

As saídas do serviço já expõem `source role`, `visibility`, `stop-state` e `dayRole`; use esses campos para separar `main-backed`, `secondary-backed`, `runtime-projected`, `calendar-match-day` e `semantic-event-day` em vez de inferir isso só pelo texto.

## Método de análise

### Etapa 1: validar a data no `main calendar`

Pergunta:

- existe partida ou agenda materializada no `main` para a data?

Ferramentas:

- `pes2021_dump_calendar_date`
- `pes2021_calendar_summary`

Resultado esperado:

- confirmar se a data existe como fixture/competição materializada

Leitura:

- se existir no `main`, o dia já tem forte evidência de agenda objetiva
- se não existir, isso não encerra a análise; o dia pode viver no `secondary` ou no runtime

### Etapa 2: validar a data no `secondary calendar`

Pergunta:

- existe `DayEntry` real para a data?
- há headers?
- há `count/items`?

Ferramentas:

- `pes2021_find_secondary_calendar_base_by_date`
- `pes2021_dump_secondary_calendar_day`

Resultado esperado:

- identificar se a data tem:
  - header semântico
  - placeholder
  - bridge para `d+1`
  - payload de itens
  - nada

Leitura:

- `header + count/items`
  - dia fortemente materializado
- `header sem items`
  - marker semântico ou placeholder
- `nada`
  - provavelmente não é uma data bruta do `secondary`

### Etapa 3: classificar a semântica do dia

Pergunta:

- o dia já corresponde a um evento conhecido?

Ferramentas:

- `pes2021_inventory_annual_events`
- `pes2021_classify_runtime_day_variant`

Resultado esperado:

- rotular o dia como:
  - evento confirmado
  - candidato
  - marker-fonte
  - projeção legada
  - desconhecido real

Regra:

- se o nome depender de reader antigo e não houver evidência save-side atual suficiente, usar rótulo fraco
- exemplo:
  - `hidden_competition_projection_source_marker`
  - e não semântica forte de competição/final

### Etapa 4: cruzar com o comportamento da UI

Pergunta:

- a data aparece para o jogador?
- o calendário para nela?

Fonte:

- observação manual no jogo
- screenshots
- navegação com o cursor

Resultado esperado:

- classificar o dia em uma destas classes:
  - `visible + stop`
  - `visible + no stop`
  - `not visible + no stop`
  - `raw marker only`
  - `runtime projection only`

Observação:

- esta etapa é decisiva
- sem ela, o dado bruto sozinho não basta para afirmar `show + stop`

### Etapa 5: medir o runtime do dia selecionado

Pergunta:

- qual cache/estrutura o jogo carrega quando o cursor está naquela data?

Ferramentas:

- `pes2021_scan_runtime_day_index_clusters`
- `pes2021_dump_runtime_day_payload_family`
- `pes2021_compare_runtime_day_payload_family`
- `pes2021_dump_runtime_day_payload_cluster_detail`
- `pes2021_analyze_runtime_day_payload_cluster`

Resultado esperado:

- separar:
  - ruído global
  - cache privado de agenda visível
  - projeção do dia selecionado

Leitura:

- datas visíveis e stop costumam ter melhor ancoragem semântica no `secondary`
- datas projetadas/invisíveis podem ter runtime forte, mas sem evidência save-side local

### Etapa 6: comparar dias vizinhos e dias-controle

Pergunta:

- o que muda entre um dia visível/stop e um dia sem stop?

Comparações úteis:

1. `dia anterior` vs `dia alvo` vs `dia seguinte`
2. `visible + stop` vs `raw marker only`
3. `visible + stop` vs `runtime projection only`

Exemplos de bom uso:

- `28/12` vs `29/12` vs `30/12`
- `10/12` vs `11/12` vs `12/12`

Objetivo:

- descobrir o que é:
  - marker bruto
  - projeção do reader/UI
  - stop-day real do jogador

## Como decidir se vale continuar numa trilha

Continuar na trilha se:

1. a data tem evidência nova em alguma camada
2. a data ajuda a separar `raw marker` de `visible stop`
3. a comparação com um controle próximo parece limpa

Encerrar ou rebaixar a trilha se:

1. a data não existe no `main`
2. a data não existe no `secondary`
3. a semântica só sobrevive por heurística antiga
4. o runtime só produz ruído e não ajuda a separar comportamento

Exemplo de rebaixamento correto:

- `2026-12-11`
  - manter como caso de controle de projeção/runtime
  - não insistir nela como data de agenda bruta principal

## Caminho atual recomendado

Hoje a ordem de trabalho mais produtiva é:

1. priorizar datas `visible + stop`
2. usar datas projetadas/invisíveis apenas como controle negativo
3. comparar blocos locais de UI
4. procurar a regra que diferencia:
   - `marker semântico no secondary`
   - `data visível`
   - `parada real da simulação`

Na prática, isso significa:

1. usar blocos confirmados como:
   - `29/12`, `30/12`, `31/12`
   - `27/08`
   - `30/06`
   - `22/09`

2. usar casos como `10/12`, `11/12`, `12/12` só para testar:
   - projeção
   - ausência de materialização save-side
   - diferença entre marker-fonte e dia efetivo

## Passo a passo operacional

### Fluxo padrão para uma nova data

1. confirmar se a data é visível e se para a simulação
2. rodar `pes2021_dump_calendar_date`
3. rodar `pes2021_dump_secondary_calendar_day`
4. classificar o dia semanticamente
5. se o dia for visível ou suspeito de stop real, medir runtime com o cursor sobre ele
6. comparar com:
   - um vizinho sem evento
   - um vizinho com evento diferente
   - um controle negativo
7. decidir se o dia é:
   - `main-backed`
   - `secondary-backed`
   - `runtime-projected`
   - `legacy-heuristic-only`

### Fluxo padrão para isolar a regra de stop

1. escolher um dia `visible + stop`
2. escolher um dia `raw marker only` ou `runtime projection only`
3. medir `secondary`
4. medir runtime com o cursor sobre cada um
5. filtrar clusters `Private/ReadWrite`
6. comparar famílias recorrentes
7. tentar localizar a estrutura comum dos dias que realmente param

## O que não devemos fazer

1. dar nome forte a um tipo de evento só porque um reader antigo usava esse nome
2. tratar projeção `dayIdx + 1` como fato bruto do save
3. insistir indefinidamente em um dia sem evidência nova
4. confundir `evento do calendário mundial` com `evento visível ao jogador`

## Critério de sucesso

Esta linha de trabalho terá atingido o objetivo quando conseguirmos responder, com evidência:

1. qual é a fonte bruta do evento
2. qual camada o projeta para o jogador
3. qual condição faz o dia aparecer
4. qual condição faz o dia parar a simulação

## Próximos alvos recomendados

1. consolidar o bloco `29/12-31/12`
2. comparar o trio `01/12-02/12-05/12` com os controles `11/12` e `13/12`
3. atacar as frentes de suporte:
   - `0xBEB3A8` como cache derivado de dois slots
   - `0xB42430..0xB432B8` como família monotônica por `dayIdx`
   - `PlayerEventTable` / `Struct3` / `0x22BC84..0x2307AC` como controle negativo
4. reduzir a diferença entre:
   - `semantic marker`
   - `visible agenda line`
   - `stop-day`
