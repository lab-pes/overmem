# overmem Inventory and Migration Matrix

This document inventories `overmem` using the monorepo-wide classification model defined in [../../MONOREPO-SHARED-TAXONOMY.md](../../MONOREPO-SHARED-TAXONOMY.md).

## Executive Summary

`overmem` is a cohesive product/backend repository rather than a mixed operational workspace.

Its current shape is centered on:

- First-party .NET source code under `src/`
- A full automated verification surface under `tests/`
- Root and supplementary documentation under `README.md` and `docs/`
- Local MCP/editor wiring under `.vscode/`
- Project-local workflow prompts under `.github/`

Unlike `pes-desenv` and `analise-pes`, this project does not currently present meaningful mixed workspace state, raw save corpora, or generated artifact roots at the top level.

## Classification Matrix

| Path | Current role | Content found | Shareability | Recommended monorepo treatment | Notes |
| --- | --- | --- | --- | --- | --- |
| `src/` | First-party application and platform source | Abstractions, application, runtime, search, hosting, CLI, Windows provider, MCP server | Medium | Keep project-scoped as product source; extract only deliberately shared libraries later | This is the core owned code surface |
| `tests/` | Tests and validation harnesses | Unit tests, integration tests, and a controlled test target process | Medium | Keep close to the owning project | Strong project-local verification surface |
| `README.md` | Product and operational documentation | Capability surface, architecture, CLI/MCP usage, build/test instructions | High | Promote as reusable knowledge where relevant | The main human entry point for the project |
| `docs/` | Supplementary technical knowledge | PES 2021 agenda/show-stop analysis guide | High | Promote as reusable knowledge | Domain-specific guide that may help other PES analysis projects |
| `.vscode/` | Local automation and editor wiring | MCP config, cheat-engine bridge config, launch script | Low | Keep local; extract patterns only | Machine-bound and operator-bound configuration |
| `.github/` | Project-local AI workflow metadata | Planning prompts | Medium | Keep local first; extract only proven cross-project workflow assets | Workflow guidance specific to this repository |
| `Directory.Build.props` | Project build coordination | Shared .NET build settings for the solution | Low to medium | Keep project-scoped | Build metadata tied to this solution |
| `Overmem.slnx` | Solution orchestration | Root solution entry point | Low | Keep project-scoped | Product/solution boundary, not a shared asset |

## Detailed Area Notes

### `src/`

Observed code areas:

- `Overmem.Abstractions/`
- `Overmem.Application/`
- `Overmem.Runtime/`
- `Overmem.Search/`
- `Overmem.Hosting/`
- `Overmem.Cli/`
- `Overmem.Windows/`
- `Overmem.McpServer/`

Operational conclusion:

- `overmem` is primarily a platform/backend codebase.
- Its architecture is already intentionally separated into layers and execution surfaces.
- It should remain a coherent project unit unless specific libraries prove stable enough for deliberate cross-project extraction.

### `tests/`

Observed test areas:

- `Overmem.Tests/`
- `Overmem.TestTarget/`

Operational conclusion:

- These are strong project-owned tests, not generic utilities.
- They belong with the product source and should not be treated as a central shared tool surface.

### `README.md`

The root README already documents:

- scope and product positioning
- current capability surface
- solution layout
- major gaps
- build and test usage
- CLI usage patterns

Operational conclusion:

- This is a high-value knowledge asset.
- It may inform other memory tooling efforts in the monorepo, but it remains attached to the `overmem` product surface.

### `docs/`

Observed docs content:

- `pes2021-agenda-show-stop-guide.md`

Operational conclusion:

- This is domain knowledge rather than product code.
- It has cross-project reuse value because it encodes PES 2021 analysis semantics that can inform other repositories.

### `.vscode/`

Observed local config:

- `mcp.json`
- `cheat-engine-mcp.config.json`
- `launch-cheat-engine-mcp.ps1`

Operational conclusion:

- This surface is operationally important but machine-bound.
- Reuse should happen by pattern or documentation, not by lifting the files wholesale into a shared surface.

## Centralization Decision Table

| Category | Include in future shared surface? | How |
| --- | --- | --- |
| Product source under `src/` | Not in the first wave | Keep as a coherent project unless specific libraries are intentionally extracted |
| Tests under `tests/` | No, by default | Keep attached to the owning project |
| Root and supplementary docs | Yes | Promote relevant technical knowledge into the shared knowledge model |
| `.vscode/` automation wiring | No | Keep local; share patterns only |
| `.github/` prompts | Maybe | Extract only if their workflow value is clearly cross-project |
| Build and solution files | No | Keep project-scoped |

## Recommended Next Actions For `overmem`

1. Treat `overmem` primarily as a product/project boundary, not as a mixed workspace to be split aggressively.
2. Reuse documentation and domain knowledge from `README.md` and `docs/` where it benefits other PES analysis efforts.
3. Avoid trying to centralize `src/` prematurely; any sharing there should be an explicit architectural extraction.
4. Keep `.vscode/` and solution/build files local to the project.

## Practical Reuse Value

For future monorepo centralization, `overmem` contributes these assets first:

1. A mature backend/platform codebase that should remain intact as a project.
2. High-value technical documentation around runtime memory tooling and PES 2021 agenda semantics.
3. Potential future extractable libraries, but only as a deliberate later step rather than a migration default.