# Overmem

Overmem is a Windows-only .NET 8 process memory platform focused on headless operation. The current repository scope is the backend surface only: shared contracts, application services, a Win32 provider, a one-shot CLI, and a local stdio MCP server. UI work is intentionally out of scope for now.

The project already covers a meaningful subset of Cheat Engine style workflows for process attachment, region/module inspection, typed reads and writes, pointer resolution, pattern scanning, freezing, exact value search, memory tables, and host runtime diagnostics. It does not yet cover the full Cheat Engine feature set.

## Status At A Glance

Ready now:

- Process attach and detach by PID or process name.
- Module listing and virtual memory region enumeration.
- Typed memory read and write for `Bytes`, `Int32`, `Int64`, `Float`, `Double`, `Utf8String`, and `Utf16String`.
- Pointer-chain resolution from an absolute base address.
- Pointer-chain resolution from a module-relative base address.
- Initial absolute pointer discovery with bounded depth and offset scanning.
- Pattern scanning with `??` wildcards.
- Freeze orchestration with automatic cleanup on detach.
- Exact value search sessions with `Exact`, `NotEqual`, `Changed`, `Unchanged`, `Increased`, `Decreased`, `IncreasedBy`, `DecreasedBy`, `ChangedBy`, and `Between` refinement.
- Unknown initial value search sessions: capture all aligned baseline values and narrow with `Changed`, `Unchanged`, `Increased`, `Decreased`, `Between`, etc.
- JSON-backed memory tables with on-demand refresh.
- Host runtime diagnostics for active attachments and recent operations.
- Headless execution through a local CLI.
- Host integration through a local stdio MCP server.

Partially ready:

- CLI value search supports exact one-shot scans only. Multi-step refinement is currently MCP-host only.
- Pointer discovery now supports optional base-module filtering and candidate revalidation, but pointer maps and large-scale ranking/revalidation workflows are not implemented yet.
- Value-search sessions are in-memory host state only. They are not persisted.
- Memory-table refresh is on demand only. There is no background refresh daemon.

Not implemented yet:

- Any UI surface.
- Cheat Engine `.CT` import and export.
- Full pointer scanner workflows with pointer maps, ranking, and revalidation.
- Advanced value search modes such as grouped searches. Unknown initial value, ranges, deltas, and inequality are already supported.
- Disassembly, instruction-level inspection, breakpoints, tracing, or debugger features.
- Code patching, injection, hooks, speedhack, or instrumentation workflows.
- Lua runtime and compatibility execution.
- Managed-runtime providers for Mono, .NET object inspection, or Java.
- Plugin system or extension model.
- Remote/distributed execution model.
- Kernel or privileged providers.

## Solution Layout

- `src/Overmem.Abstractions`: contracts shared by every layer.
- `src/Overmem.Application`: application-facing orchestration and validation.
- `src/Overmem.Runtime`: host-level runtime services such as attachment session tracking and recent-operation journals.
- `src/Overmem.Search`: exact value search sessions and refinement logic.
- `src/Overmem.Hosting`: shared dependency injection wiring for local hosts.
- `src/Overmem.Cli`: one-shot command-line host.
- `src/Overmem.Windows`: Win32-backed implementation of the process memory gateway.
- `src/Overmem.McpServer`: local stdio MCP host exposing the headless workflows.
- `tests/Overmem.TestTarget`: controlled process used by integration tests.
- `tests/Overmem.Tests`: unit and integration suite.

## Implemented Capability Surface

### Process and Runtime

- Attach to a process by PID or by name.
- Detach and release native handles.
- Track active attachments in long-lived hosts.
- Record recent host operations in a bounded in-memory journal.

### Memory Access

- List loaded modules.
- Enumerate virtual memory regions with readable, writable, and executable flags.
- Read typed values from absolute addresses.
- Write typed values to absolute addresses.
- Resolve pointer chains from absolute bases.
- Resolve pointer chains from module-relative bases.
- Scan readable regions for hex signatures with optional `??` wildcards.

### Pointer Discovery

- Discover absolute pointer candidates that can resolve to a known target address.
- Bound discovery by maximum depth.
- Bound discovery by maximum absolute offset per dereference.
- Annotate candidates with module-relative base information when the candidate base falls inside a loaded module.
- Optionally filter candidates by a required base module name.
- Optionally revalidate candidates by resolving the discovered pointer chain before returning it.
- Rank candidates by a heuristic score: revalidated > module-rooted > shorter chain > smaller offsets > aligned offsets.

### Freeze Workflows

- Freeze a value at an absolute address.
- Freeze a value resolved from an absolute-base pointer chain.
- Freeze a value resolved from a module-relative pointer chain.
- List active freezes.
- Cancel freezes explicitly.
- Stop freezes automatically when the owning attachment is detached.

### Value Search

- Start an unknown initial value search session (captures all aligned baseline values without an exact match).
- Refine a search session by exact value.
- Refine a search session by changed value.
- Refine a search session by unchanged value.
- Refine a search session by increased numeric value.
- Refine a search session by decreased numeric value.
- Refine a search session by an exact numeric delta (`IncreasedBy`, `DecreasedBy`, `ChangedBy`).
- Refine a search session by a numeric range (`Between`).
- Refine a search session by inequality (`NotEqual`).
- List active search sessions.
- Read the current results of a search session.
- Close a search session.

### Memory Tables

- Load a versioned JSON memory table document from disk.
- Save a memory table document.
- Refresh a memory table into a snapshot of resolved addresses and current values.

## Current Gaps And Remaining Work

This repository still needs the following major capability groups before it approaches a fuller Cheat Engine replacement on the backend side:

- Richer search engine: typed groups, result persistence, and larger-scan ergonomics. Numeric ranges, deltas, and unknown-initial-value mode are already supported.
- Pointer discovery: pointer-map generation and large-scale revalidation beyond the current bounded candidate scan. Candidate ranking is already implemented.
- Artifact persistence: durable sessions, saved searches, durable freeze sets, and richer event streams.
- Debug and inspection: disassembly, instruction decode, breakpoints, memory viewer semantics, and trace capture.
- Scripting: Lua runtime, compatibility layer, script-host lifecycle, and safe API exposure.
- Managed runtime support: Mono/.NET/Java-specific inspection and value resolution.
- Execution surfaces: persistent CLI host mode, packaged binaries, and better operational ergonomics.
- Provider expansion: alternative providers, elevated modes where appropriate, and future remote-agent work.
- Compatibility work: `.CT` translation/import/export and broader interoperability.

## Build And Test

Build the solution:

```powershell
dotnet build Overmem.slnx
```

Run all tests:

```powershell
dotnet test Overmem.slnx
```

Collect coverage:

```powershell
dotnet test Overmem.slnx --collect:"XPlat Code Coverage"
```

Coverage artifacts are written under each test run's `TestResults` directory.

## Manual Usage Guide

### Prerequisites

- Windows.
- .NET 8 SDK.
- Sufficient rights to open the target process.

### Value Kinds

The current typed operations use these value kinds:

- `Bytes`
- `Int32`
- `Int64`
- `Float`
- `Double`
- `Utf8String`
- `Utf16String`

For `Bytes`, values are hex strings without separators. For fixed-size strings and byte arrays, use the `size` parameter when required.

### CLI Startup

Show CLI help:

```powershell
dotnet run --project src/Overmem.Cli -- help
```

The CLI is intentionally one-shot. Each command attaches, executes, prints JSON to standard output, and then detaches.

### CLI Commands

- `modules`
- `regions`
- `read`
- `write`
- `scan-pattern`
- `discover-pointers`
- `resolve-pointer`
- `resolve-module-pointer`
- `table-load`
- `table-save`
- `table-refresh`
- `scan-value`

### CLI Examples

List modules by PID:

```powershell
dotnet run --project src/Overmem.Cli -- modules --pid 1234
```

List regions by process name:

```powershell
dotnet run --project src/Overmem.Cli -- regions --name notepad
```

Read a typed value:

```powershell
dotnet run --project src/Overmem.Cli -- read --name notepad --address 0x12345678 --value-kind Int32
```

Write a typed value:

```powershell
dotnet run --project src/Overmem.Cli -- write --pid 1234 --address 0x12345678 --value-kind Int32 --value 7331
```

Scan a pattern:

```powershell
dotnet run --project src/Overmem.Cli -- scan-pattern --name game --pattern "DE AD ?? EF" --max-results 25
```

Discover pointer candidates for a known target address:

```powershell
dotnet run --project src/Overmem.Cli -- discover-pointers --pid 1234 --target-address 0x12345678 --max-depth 2 --max-offset 0x20 --max-results 50 --base-module-name game.exe
```

Use `--skip-revalidation` if you want the raw discovered candidates without a resolve check before they are returned.

Resolve an absolute pointer chain:

```powershell
dotnet run --project src/Overmem.Cli -- resolve-pointer --pid 1234 --base-address 0x140000100 --offsets 0x10,0x20,0x8
```

Resolve a module-relative pointer chain:

```powershell
dotnet run --project src/Overmem.Cli -- resolve-module-pointer --pid 1234 --module-name game.exe --base-offset 0x123456 --offsets 0x10,0x20
```

Run an exact value search:

```powershell
dotnet run --project src/Overmem.Cli -- scan-value --pid 1234 --value-kind Int32 --value 1337 --alignment 4 --max-results 100
```

For multi-step numeric refinement such as `Increased`, `Decreased`, `IncreasedBy`, `DecreasedBy`, `ChangedBy`, `Between`, or `NotEqual`, use the MCP host. The CLI remains one-shot and does not hold a search session open across commands.

Refresh a memory table:

```powershell
dotnet run --project src/Overmem.Cli -- table-refresh --pid 1234 --file .\tables\player.json
```

### PES 2021 Agenda MCP

For the current reverse-engineering objective around player-visible agenda lines and stop-days, see also:

- `docs/pes2021-agenda-show-stop-guide.md`

For `eFootball PES 2021 SEASON UPDATE`, the MCP server now exposes a higher-level agenda workflow that is easier to use than the low-level generic reads:

- `pes2021_agenda_guide`
- `pes2021_calendar_search_priorities`
- `pes2021_find_calendar_base`
- `pes2021_dump_calendar_date`
- `pes2021_calendar_summary`
- `pes2021_inspect_secondary_calendar_candidate`
- `pes2021_scan_secondary_calendar_candidates`
- `pes2021_find_secondary_calendar_base_by_date`
- `pes2021_dump_secondary_calendar_day`
- `pes2021_scan_runtime_day_index_clusters`
- `pes2021_dump_runtime_day_payload_family`
- `pes2021_compare_runtime_day_payload_family`
- `pes2021_dump_runtime_day_payload_cluster_detail`
- `pes2021_analyze_runtime_day_payload_cluster`
- `pes2021_classify_runtime_day_variant`
- `pes2021_inventory_annual_events`

The guide command reads the local Cheat Engine table at `C:\Users\Willian\OneDrive\Documentos\#PC\PES 2021 - wILL- v0.0.1.CT`, follows its Lua bootstrap to the calendar inspector script, and extracts the known agenda offsets and references. The search-priority command returns the CT-derived search map, including the `match_array` and `secondary_calendar` paths that are most relevant for fixtures and schedules.

The runtime-day-index scan is meant for the harder cases where the visible calendar line is not explained by the `match_array` or by the raw `secondary_calendar` header alone. It scans the live process for the selected `dayIndex`, groups nearby hits inside private heap regions, and decodes an `Int32` preview from each cluster so you can inspect runtime cache/window structures without dropping back to raw pattern scans.

The runtime-day payload-family dump is the focused follow-up for the same scenario. Instead of relying on a global pattern-scan result cap, it walks readable private heap regions directly, groups the selected `dayIndex` hits, keeps the stride families you care about such as `472` and `528`, and optionally decodes the preview integers against the Master League `match_array` so you can immediately see which preview IDs resolve into plausible agenda records.

The runtime-day payload-family comparison goes one step further: it runs the same focused dump for `day-1`, `day`, and `day+1`, matches clusters by stride and ordinal, and highlights which preview IDs are unique to the current day versus the neighbors. That is the intended command when you are trying to isolate a non-match event that only materializes on one visible calendar line.

The runtime-day payload-cluster detail dump is the low-level follow-up when one cluster stands out, such as a `472`-stride family that only appears on a special day. It keeps the focused cluster selection and then reads local `Int32` windows around each sample hit so you can inspect the internal sublists and slot layout without falling back to an external probe harness.

The runtime-day payload-cluster analysis turns that raw detail into a reusable signature: common anchor prefix, unresolved preview IDs, frequent tail values, and contiguous tail runs per hit. That is the command to use when you suspect the same event type appears on multiple dates and you want a stable fingerprint to compare.

The runtime-day variant classifier now returns two different levels of interpretation:

- `variant`
  - the runtime shape currently loaded for that stop-day
- `semantic event`
  - the confirmed or inferred business meaning of that day in the current save context

The main calendar, secondary calendar, runtime classifier, and annual inventory outputs also expose a small explicit disposition surface:

- `source role`
  - `main-backed`
  - `secondary-backed`
  - `runtime-projected`
- `visibility`
  - `visible`
  - `projected`
  - `hidden`
- `stop-state`
  - `stop`
  - `candidate`
  - `no-stop`

The annual event inventory command is the higher-level blind-audit surface built on top of the same mapping. It inventories the season year from the main calendar plus secondary calendar, keeps only the days that are materially special, and attaches any confirmed semantic labels already known for the current save context.

For days that still do not have a confirmed semantic label, the annual inventory also returns an `inventory pattern` classification. This is a lighter-weight business grouping used to reduce the blind-audit backlog, for example:

- `next_day_schedule_bridge_candidate`
- `standalone_secondary_payload_candidate`
- `post_match_followup_payload_candidate`
- `placeholder_bridge_candidate`
- `pure_placeholder_marker_candidate`
- `rare_header_marker_candidate`

For the current audited 2026 season, the confirmed semantic anchors are:

- `national_team_callup`
  - `2026-03-16`
  - `2026-05-26`
  - `2026-06-23`
  - `2026-08-21`
  - `2026-09-22`
  - `2026-10-30`
- `libertadores_group_stage_matchday_2_followup`
  - `2026-03-19`
  - business meaning: the day after `Conmebol Libertadores Fase de grupos Jornada 2`
- `libertadores_group_stage_matchday_4_followup`
  - `2026-04-16`
  - business meaning: the day after `Conmebol Libertadores Fase de grupos Jornada 4`
- `libertadores_round_of_16_first_leg_placeholder`
  - `2026-06-13`
- `club_ranking_update`
  - `2026-06-26`
- `europe_best_player_award_prelude`
  - `2026-08-26`
  - business meaning: eve of the European best player award announcement, even if the visible day also carries a normal league match
- `europe_best_player_award_announcement`
  - `2026-08-27`
- `transfer_window_start`
  - `2026-01-01`
  - `2026-07-01`
- `transfer_window_end`
  - `2026-01-31`
  - `2026-08-31`
- `coach_offer_response_deadline`
  - `2026-06-30`
- `world_best_player_award_announcement`
  - `2026-12-02`
  - business meaning: explicit world best player award announcement day materialized as a visible agenda line and real stop-day; `2026-12-05` must not be normalized as this event
- `asian_best_player_award_announcement`
  - `2026-12-29`
- `south_america_best_player_award_announcement`
  - `2026-12-30`
- `hidden_competition_projection_source_marker`
  - `2026-12-10`
  - `2026-12-12`
  - business meaning: raw source-marker days in the `secondary_calendar` for hidden/system competition flow; the old `dayIdx + 1` projection to `2026-12-11` and `2026-12-13` should be treated as a reader heuristic, not as proof that those target dates materialize as visible stop-days or main-calendar fixtures
- `last_day_of_season`
  - `2026-12-31`

#### Business View Of The Calendar Layers

At the current state of the mapping, the PES 2021 Master League calendar should be understood as at least three business-facing layers, not as a single flat table:

1. Main calendar array.
   What it means in business terms:
   the base season schedule, mainly the official fixtures, competition rounds, and objective match dates.

   Best answers it provides:
   which matches exist on a given day, which competition owns them, and how the visible season schedule is distributed.

2. Secondary calendar.
   What it means in business terms:
   day markers and auxiliary agenda entries that make a date special even when the main match list does not contain a normal fixture for that day.

   Best answers it provides:
   whether the date is a special stop-day, whether there is a placeholder or bridge to the following day, and whether the date carries a non-match header event.

3. Runtime/UI calendar cache.
   What it means in business terms:
   the live agenda that the game has already assembled in memory for the current screen and for the day-advance simulation flow.

   Best answers it provides:
   what the player is actually seeing right now, why the simulation stops on a given date, and how the same semantic event is materialized under different surrounding schedule contexts.

The practical consequence is important: the annual agenda visible in the game is not explained by the main array alone. The game appears to combine the season fixture base, the secondary day markers, and one or more live runtime caches before deciding what to display and when to stop the time simulation for player input.

Another practical consequence is that not every special annual marker is meant to be visible to the player. The current mapping already includes both:

- player-facing stop-days
  - examples: national-team callups, transfer-window boundaries, awards, coach-response deadlines
- system-facing calendar markers
  - examples: hidden competition eve markers or follow-up markers around competitions the user is not directly involved in

This distinction matters because a date can be semantically real in the world calendar and still never surface as a visible agenda entry for the current user.

The annual inventory also now exposes an explicit `dayRole` field to avoid mixing "real calendar day" with "annual semantic event":

- `calendar-match-day`
  - valid materialized day in the main calendar with a real fixture
  - example: `2026-12-01`
- `semantic-event-day`
  - visible annual/admin day whose primary meaning is the semantic event itself
  - example: `2026-12-02` as the world best player award announcement
- `mixed-match-and-semantic-day`
  - both a real fixture and a semantic annual event share the same date
- `calendar-marker-day`
  - secondary/header-backed marker day with no closed semantic meaning yet

This keeps `2026-12-01` as a valid league-match day without allowing it to inherit the award semantics from `2026-12-02`.

#### Current Runtime Event Taxonomy

The `pes2021_classify_runtime_day_variant` command is intentionally heuristic, but it already captures a useful business taxonomy for stop-days that share the same semantic event while living in different schedule contexts:

- `placeholder_special_runtime`
  - example: `2026-09-22`
  - business meaning: special stop-day with no main-array fixture on the day itself and a distinctive runtime family, currently the cleanest fingerprint for the national-team callup announcement case
- `placeholder_organized_runtime`
  - example: `2026-10-30`
  - business meaning: stop-day with a small bridge payload toward the next day and a simple organized runtime family
- `no_games_runtime`
  - example: `2026-03-16`
  - business meaning: stop-day with no surrounding matches and a single clean runtime family
- `agenda_defined_organized_runtime`
  - example: `2026-06-23`
  - business meaning: stop-day whose following schedule is already well-defined and still materializes in a compact organized runtime family
- `agenda_defined_noisy_runtime`
  - examples: `2026-05-26`, `2026-08-21`
  - business meaning: stop-day whose following schedule is already loaded in a much heavier runtime context, making the event harder to isolate from the surrounding agenda noise

This taxonomy should be treated as a working operational model, not as the final semantic truth of the engine. It is meant to guide further probing of other stop-day types such as transfer-window milestones, negotiation deadlines, or competition phase changes.

The same annual blind-audit pass that isolated the national-team callup dates also exposed a smaller set of administrative boundary dates whose header-event mix does not look like ordinary fixture bridging. In the current live save, the following transfer-window boundaries are confirmed:

- `2026-01-01` transfer-window start
- `2026-01-31` transfer-window end
- `2026-07-01` transfer-window start
- `2026-08-31` transfer-window end

Additional transfer-window prelude candidates that still need semantic confirmation cluster around:

- `2026-01-30`
- `2026-08-30`

These dates are useful blind-audit anchors for future work on transfer-window preludes and other non-match stop-days. The dates listed above as confirmed anchors should be treated as semantic labels already validated in the current save context.

The current classifier also exposes working candidate labels for the still-unconfirmed transfer-window preludes:

- `transfer_window_boundary_prelude_candidate`
  - examples: `2026-01-30`, `2026-08-30`

These candidate labels are not final semantic truth yet. They exist to make annual blind-audits and future grouping work repeatable instead of leaving the remaining dates as undifferentiated `unknown_event` results.

The current annual backlog is no longer a flat `unknown_event` bucket. The recurring business-facing families already visible in the 2026 inventory are:

- `next_day_schedule_bridge_candidate`
  - day has no own fixture, but the secondary payload clearly bridges into a populated `d+1` schedule
- `placeholder_bridge_candidate`
  - same bridging idea, but with `0x003F` placeholder markers present
- `standalone_secondary_payload_candidate`
  - no surrounding main-array matches, but the day still carries a local secondary payload
- `post_match_followup_payload_candidate`
  - small secondary payload that appears immediately after a prior-day match block
- `rare_header_marker_candidate`
  - days with unusual header signatures that likely correspond to more specific semantic event types still waiting to be named

This means the next blind-audit cycle should focus less on "does this date matter at all?" and more on "which repeated business family does this date belong to?".

Suggested flow:

1. Attach to `PES2021.exe` with the existing `attach_process` tool.
2. Run `pes2021_agenda_guide` to confirm the calendar references and known offsets.
3. Run `pes2021_find_calendar_base` if you need the calendar anchor resolved from a visible date or season anchor.
4. Use `pes2021_dump_calendar_date` or `pes2021_calendar_summary` to inspect fixtures and schedule-like agenda data.
5. Use `pes2021_find_secondary_calendar_base_by_date` when a date exists outside the main array and you need to resolve the real `secondary_calendar` base from a raw day-header hit.
6. Use `pes2021_dump_secondary_calendar_day` to inspect the resolved `DayEntry`, including header events, item indices, and `count`.
7. Use `pes2021_scan_runtime_day_index_clusters` when the UI still shows a visible line or stop-day that is not explained by the save-side structures alone.
8. Use `pes2021_dump_runtime_day_payload_family` when the generic runtime scan is too noisy and you need the focused `472`/`528` style heap-family dump plus preview record decode.
9. Use `pes2021_compare_runtime_day_payload_family` to isolate IDs that are unique to the current day compared with the previous and next days.
10. Use `pes2021_dump_runtime_day_payload_cluster_detail` when one runtime cluster looks promising and you need the local `Int32` windows around each hit.
11. Use `pes2021_analyze_runtime_day_payload_cluster` when you want a reusable signature for that cluster type across other dates.
12. Use `pes2021_classify_runtime_day_variant` when you want a provisional subtype label for the selected day, derived from the secondary-calendar day shape plus the focused runtime-family scan. Treat this as heuristic output and verify against the returned reasons.
13. Use the lower-level secondary-calendar candidate tools when the date-based resolution is still not enough and you need to probe broader agenda structures.
14. Use `pes2021_inventory_annual_events` when you want the year-level list of special days first and only then decide which ones deserve deeper runtime analysis.

#### Next Analysis Directions

The current recommended order for further reverse-engineering work is:

1. Promote high-level semantic detectors for already-classified stop-days.
   Immediate goal:
   make the MCP surface answer questions such as "is this a national-team callup stop-day?" without forcing the caller to read raw cluster signatures.

2. Split the `agenda_defined_noisy_runtime` bucket into smaller semantic families.
   Immediate goal:
   separate cases that are currently grouped only because they share heavy runtime noise, for example distinguishing future-fixture-loaded cases from transfer-market or roster-management stop-days.

3. Expand the same pipeline to other known stop-day categories.
   Immediate goal:
   build the same evidence chain for transfer-window start/end, negotiation deadlines, competition phase boundaries, and any other date that visibly interrupts simulation.

4. Find the semantic stop-decision source, not just the rendered runtime shape.
   Immediate goal:
   move from "this runtime family appears on stop-days" to "this structure or rule is what makes the engine stop for player action".

5. Reconstruct the annual agenda projection path.
   Immediate goal:
   explain how the game goes from the save-side layers to the yearly agenda that the player can browse, including which parts are persistent data and which parts are rebuilt as runtime cache.

### Pattern Format

- Exact pattern example: `DE AD BE EF 44 99`
- Wildcard pattern example: `DE AD ?? EF 44 99`

### Memory Table Document Format

Memory tables are stored as versioned JSON documents. The current schema version is `1.0`.

Main fields:

- `SchemaVersion`
- `Name`
- `Entries`

Each entry supports:

- `EntryId`
- `Name`
- `ValueKind`
- `AddressKind`: `Absolute`, `Pointer`, or `ModulePointer`
- `AbsoluteAddress`
- `BaseAddress`
- `ModuleName`
- `BaseOffset`
- `Offsets`
- `Size`
- `RefreshIntervalMs`
- `Freeze`: `{ "Value": "...", "IntervalMs": 25 }`

Example:

```json
{
	"SchemaVersion": "1.0",
	"Name": "Player Table",
	"Entries": [
		{
			"EntryId": "health",
			"Name": "Player Health",
			"ValueKind": "Int32",
			"AddressKind": "ModulePointer",
			"ModuleName": "game.exe",
			"BaseOffset": 1193046,
			"Offsets": [16, 32, 8],
			"Size": 0,
			"RefreshIntervalMs": null,
			"Freeze": {
				"Value": "999",
				"IntervalMs": 25
			}
		}
	]
}
```

## MCP Integration Guide

### Running The MCP Host Manually

Start the stdio MCP server:

```powershell
dotnet run --project src/Overmem.McpServer
```

The server uses stdio transport and keeps runtime state in process memory, including active attachments, freeze state, operation logs, and value-search sessions.

### Adding Overmem To VS Code MCP

This workspace already uses `.vscode/mcp.json` for MCP configuration. Add an `overmem` server entry alongside the existing ones:

```json
{
	"servers": {
		"overmem": {
			"type": "stdio",
			"command": "dotnet",
			"args": [
				"run",
				"--project",
				"D:\\git\\overmem\\src\\Overmem.McpServer"
			]
		}
	}
}
```

If you prefer a faster startup after building once, point to the compiled server executable instead of `dotnet run`.

### Integrating cheat-engine-mcp in this workspace

This workspace keeps a dedicated Cheat Engine bridge profile in `.vscode/cheat-engine-mcp.config.json`.

- `.vscode/mcp.json` launches `.vscode/launch-cheat-engine-mcp.ps1`.
- Set `OFFICIAL_CHEAT_ENGINE_ROOT` to your `official-cheat-engine` checkout before starting the Cheat Engine bridge.
- The launcher sets `CE_MCP_CONFIG` to the workspace-specific config.
- Runtime logs are written to `%LOCALAPPDATA%\Overmem\logs\cheat-engine-mcp.log`.
- Log rotation is enabled by config (`maxLogSizeBytes`, `maxLogFiles`).

### MCP Tool Surface

Process tools:

- `attach_process`
- `detach_process`
- `list_modules`

Memory tools:

- `list_regions`
- `discover_pointers`
- `resolve_pointer`
- `resolve_module_pointer`
- `scan_pattern`
- `read_value`
- `write_value`

Freeze tools:

- `freeze_value_at_address`
- `freeze_value_at_pointer`
- `freeze_value_at_module_pointer`
- `unfreeze_value`
- `list_frozen_values`

Runtime tools:

- `list_active_attachments`
- `list_recent_operations`

Value-search tools:

- `start_value_search`
- `start_unknown_value_search`
- `refine_value_search`
- `list_value_search_sessions`
- `list_value_search_results`
- `close_value_search_session`

Memory-table tools:

- `load_memory_table`
- `save_memory_table`
- `refresh_memory_table`

### MCP Workflow Example

Typical workflow for a long-lived agent:

1. Call `attach_process` with `processId` or `processName`.
2. Use `list_modules`, `list_regions`, `read_value`, `resolve_pointer`, `discover_pointers`, or `scan_pattern` to discover targets.
3. If needed, start a long-lived value-search session with `start_value_search` and refine it with `refine_value_search` using `Exact`, `NotEqual`, `Changed`, `Unchanged`, `Increased`, `Decreased`, `IncreasedBy`, `DecreasedBy`, `ChangedBy`, or `Between` as appropriate. `Between` requires both `value` (lower bound) and `secondaryValue` (upper bound).
4. If needed, freeze a resolved address with one of the `freeze_value_*` tools.
5. Inspect host state with `list_active_attachments`, `list_recent_operations`, `list_frozen_values`, or `list_value_search_sessions`.
6. Persist or refresh tables with `load_memory_table`, `save_memory_table`, and `refresh_memory_table`.
7. End the session with `detach_process` and optionally `close_value_search_session`.

### MCP Operational Notes

- Long-lived workflows are best done through MCP because the host process retains in-memory state.
- Value-search sessions are lost when the MCP host stops.
- Active freezes are also host-local runtime state.
- The server is local and Windows-only.

## Constraints And Non-Goals

- Windows only.
- User mode only.
- No driver or kernel support.
- No anti-cheat bypass or protected-process bypass.
- No code injection, hook engine, or patching workflows yet.
- No UI in the current repository scope.

## Roadmap Direction

The next backend milestones with the highest leverage are:

- richer value-search modes and persisted search artifacts;
- pointer discovery and pointer-map workflows;
- persistent CLI host mode for long-lived operations;
- durable session and artifact services;
- Lua compatibility and script-host support;
- debug, disassembly, and instrumentation primitives.
