using Microsoft.Extensions.DependencyInjection;
using Overmem.Hosting;
using ModelContextProtocol;
using ModelContextProtocol.Server;
using Overmem.Application;
using Overmem.Application.Pes2021;
using Overmem.McpServer.Tools;

namespace Overmem.McpServer;

#pragma warning disable MCPEXP001

public static class OvermemServiceCollectionExtensions
{
    public static IServiceCollection AddOvermemServices(this IServiceCollection services)
    {
        var taskStore = new InMemoryMcpTaskStore(
            pollInterval: TimeSpan.FromSeconds(1),
            cleanupInterval: TimeSpan.FromMinutes(1),
            maxTasks: 256,
            maxTasksPerSession: 256);

        services.AddOvermemPlatformServices();
        services.AddSingleton<IMcpTaskStore>(taskStore);

        services.AddMcpServer(options =>
            {
                options.TaskStore = taskStore;
            })
            .WithStdioServerTransport()
            .WithTools<FreezeTools>()
            .WithTools<ProcessTools>()
            .WithTools<MemoryTools>()
            .WithTools<RuntimeTools>()
            .WithTools<SearchTools>()
            .WithTools<TableTools>()
            .WithTools<Pes2021AgendaTools>();

        return services;
    }
}

#pragma warning restore MCPEXP001
