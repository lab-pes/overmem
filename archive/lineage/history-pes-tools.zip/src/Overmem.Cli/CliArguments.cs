using Overmem.Abstractions.Memory;
using Overmem.Abstractions.Processes;

namespace Overmem.Cli;

public abstract record CliCommand;

public sealed record HelpCliCommand : CliCommand;

public sealed record ListModulesCliCommand(ProcessSelector Selector) : CliCommand;

public sealed record ListRegionsCliCommand(ProcessSelector Selector) : CliCommand;

public sealed record ReadCliCommand(ProcessSelector Selector, ulong Address, MemoryValueKind ValueKind, int Size) : CliCommand;

public sealed record WriteCliCommand(ProcessSelector Selector, ulong Address, MemoryValueKind ValueKind, string Value, int Size) : CliCommand;

public sealed record ScanPatternCliCommand(ProcessSelector Selector, string Pattern, string? ModuleName, int MaxResults) : CliCommand;

public sealed record ResolvePointerCliCommand(ProcessSelector Selector, ulong BaseAddress, long[] Offsets) : CliCommand;

public sealed record ResolveModulePointerCliCommand(ProcessSelector Selector, string ModuleName, long BaseOffset, long[] Offsets) : CliCommand;

public sealed record LoadTableCliCommand(string FilePath) : CliCommand;

public sealed record SaveTableCliCommand(string SourceFilePath, string DestinationFilePath) : CliCommand;

public sealed record RefreshTableCliCommand(ProcessSelector Selector, string FilePath) : CliCommand;

public sealed record ScanValueCliCommand(ProcessSelector Selector, MemoryValueKind ValueKind, string Value, int Size, int Alignment, int MaxResults) : CliCommand;

public sealed record DiscoverPointersCliCommand(ProcessSelector Selector, ulong TargetAddress, int MaxDepth, long MaxOffset, int Alignment, int MaxResults, string? BaseModuleName, bool RevalidateCandidates) : CliCommand;

public static class CliArgumentParser
{
    public static CliCommand Parse(string[] args)
    {
        if (args.Length == 0 || args[0] is "help" or "--help" or "-h")
        {
            return new HelpCliCommand();
        }

        var commandName = args[0];
        var options = ParseOptions(args[1..]);

        return commandName switch
        {
            "modules" => new ListModulesCliCommand(ParseSelector(options)),
            "regions" => new ListRegionsCliCommand(ParseSelector(options)),
            "read" => new ReadCliCommand(
                ParseSelector(options),
                ParseUnsignedLong(GetRequiredOption(options, "address")),
                Enum.Parse<MemoryValueKind>(GetRequiredOption(options, "value-kind"), ignoreCase: true),
                ParseInt32(GetOptionalOption(options, "size") ?? "0")),
            "write" => new WriteCliCommand(
                ParseSelector(options),
                ParseUnsignedLong(GetRequiredOption(options, "address")),
                Enum.Parse<MemoryValueKind>(GetRequiredOption(options, "value-kind"), ignoreCase: true),
                GetRequiredOption(options, "value"),
                ParseInt32(GetOptionalOption(options, "size") ?? "0")),
            "scan-pattern" => new ScanPatternCliCommand(
                ParseSelector(options),
                GetRequiredOption(options, "pattern"),
                GetOptionalOption(options, "module-name"),
                ParseInt32(GetOptionalOption(options, "max-results") ?? "100")),
            "resolve-pointer" => new ResolvePointerCliCommand(
                ParseSelector(options),
                ParseUnsignedLong(GetRequiredOption(options, "base-address")),
                ParseOffsets(GetOptionalOption(options, "offsets"))),
            "resolve-module-pointer" => new ResolveModulePointerCliCommand(
                ParseSelector(options),
                GetRequiredOption(options, "module-name"),
                ParseInt64(GetOptionalOption(options, "base-offset") ?? "0"),
                ParseOffsets(GetOptionalOption(options, "offsets"))),
            "table-load" => new LoadTableCliCommand(GetRequiredOption(options, "file")),
            "table-save" => new SaveTableCliCommand(
                GetRequiredOption(options, "source-file"),
                GetRequiredOption(options, "destination-file")),
            "table-refresh" => new RefreshTableCliCommand(ParseSelector(options), GetRequiredOption(options, "file")),
            "scan-value" => new ScanValueCliCommand(
                ParseSelector(options),
                Enum.Parse<MemoryValueKind>(GetRequiredOption(options, "value-kind"), ignoreCase: true),
                GetRequiredOption(options, "value"),
                ParseInt32(GetOptionalOption(options, "size") ?? "0"),
                ParseInt32(GetOptionalOption(options, "alignment") ?? "1"),
                ParseInt32(GetOptionalOption(options, "max-results") ?? "1000")),
            "discover-pointers" => new DiscoverPointersCliCommand(
                ParseSelector(options),
                ParseUnsignedLong(GetRequiredOption(options, "target-address")),
                ParseInt32(GetOptionalOption(options, "max-depth") ?? "2"),
                ParseInt64(GetOptionalOption(options, "max-offset") ?? "0"),
                ParseInt32(GetOptionalOption(options, "alignment") ?? "0"),
                ParseInt32(GetOptionalOption(options, "max-results") ?? "100"),
                GetOptionalOption(options, "base-module-name"),
                !options.ContainsKey("skip-revalidation")),
            _ => throw new ArgumentException($"Unknown command '{commandName}'.")
        };
    }

    private static Dictionary<string, string?> ParseOptions(string[] args)
    {
        var options = new Dictionary<string, string?>(StringComparer.OrdinalIgnoreCase);
        for (var index = 0; index < args.Length; index++)
        {
            var token = args[index];
            if (!token.StartsWith("--", StringComparison.Ordinal))
            {
                throw new ArgumentException($"Unexpected token '{token}'. Options must start with '--'.");
            }

            var optionName = token[2..];
            if (string.IsNullOrWhiteSpace(optionName))
            {
                throw new ArgumentException("Option names cannot be empty.");
            }

            if (index == args.Length - 1 || args[index + 1].StartsWith("--", StringComparison.Ordinal))
            {
                options[optionName] = null;
                continue;
            }

            options[optionName] = args[++index];
        }

        return options;
    }

    private static ProcessSelector ParseSelector(IReadOnlyDictionary<string, string?> options)
    {
        var pidText = GetOptionalOption(options, "pid");
        var processName = GetOptionalOption(options, "name");
        int? pid = string.IsNullOrWhiteSpace(pidText) ? null : ParseInt32(pidText);

        var selector = new ProcessSelector(pid, processName);
        if (!selector.IsValid())
        {
            throw new ArgumentException("Specify either --pid or --name.");
        }

        return selector;
    }

    private static string GetRequiredOption(IReadOnlyDictionary<string, string?> options, string name)
        => GetOptionalOption(options, name) ?? throw new ArgumentException($"Missing required option '--{name}'.");

    private static string? GetOptionalOption(IReadOnlyDictionary<string, string?> options, string name, string? defaultValue = null)
        => options.TryGetValue(name, out var value) && value is not null ? value : defaultValue;

    private static int ParseInt32(string value)
        => int.Parse(value, System.Globalization.CultureInfo.InvariantCulture);

    private static long ParseInt64(string value)
        => value.StartsWith("0x", StringComparison.OrdinalIgnoreCase)
            ? Convert.ToInt64(value[2..], 16)
            : long.Parse(value, System.Globalization.CultureInfo.InvariantCulture);

    private static ulong ParseUnsignedLong(string value)
        => value.StartsWith("0x", StringComparison.OrdinalIgnoreCase)
            ? Convert.ToUInt64(value[2..], 16)
            : ulong.Parse(value, System.Globalization.CultureInfo.InvariantCulture);

    private static long[] ParseOffsets(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return [];
        }

        return value.Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries)
            .Select(ParseInt64)
            .ToArray();
    }
}