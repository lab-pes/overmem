using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Overmem.Cli;
using Overmem.Hosting;

var builder = Host.CreateApplicationBuilder(args);

builder.Logging.AddSimpleConsole(options =>
{
    options.SingleLine = true;
    options.TimestampFormat = "HH:mm:ss ";
});

builder.Services.AddOvermemPlatformServices();

using var host = builder.Build();
return await CliApplication.RunAsync(args, host.Services, Console.Out, Console.Error);