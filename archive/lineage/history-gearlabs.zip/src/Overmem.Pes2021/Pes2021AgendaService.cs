using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Overmem.Abstractions.Processes;
using Overmem.Application.Pes2021.Features.AnnualCalendar;
using Overmem.Application.Pes2021.Features.DailyCalendar;
using Overmem.Application.Pes2021.Features.MatchCalendar;
using Overmem.Application.Pes2021.Features.RuntimeCalendar;
using Overmem.Application.Pes2021.Shared;

namespace Overmem.Application.Pes2021;

public sealed class Pes2021AgendaService(
    GetGuideHandler getGuide,
    FindMatchCalendarBaseHandler findMatchBase,
    DumpMatchCalendarDateHandler dumpMatchDate,
    CompareMatchCalendarDatesHandler compareDates,
    SummarizeMatchCalendarHandler summarizeMatch,
    InspectDailyCalendarCandidateHandler inspectDailyCandidate,
    ScanDailyCalendarCandidatesHandler scanDailyCandidates,
    FindDailyCalendarBaseByDateHandler findDailyBase,
    DumpDailyCalendarDayHandler dumpDailyDay,
    ScanRuntimeDayIndexClustersHandler scanRuntimeClusters,
    DumpRuntimeDayPayloadFamilyHandler dumpRuntimeFamily,
    CompareRuntimeDayPayloadFamilyHandler compareRuntimeFamily,
    DumpRuntimeDayPayloadClusterDetailHandler dumpRuntimeClusterDetail,
    AnalyzeRuntimeDayPayloadClusterHandler analyzeRuntimeCluster,
    ClassifyRuntimeDayVariantHandler classifyRuntimeVariant,
    InventoryAnnualEventsHandler inventoryAnnualEvents)
{
    public Pes2021AgendaService(ProcessMemoryApplicationService memoryService)
        : this(CreateAll(memoryService))
    {
    }

    private Pes2021AgendaService((
        GetGuideHandler getGuide,
        FindMatchCalendarBaseHandler findMatchBase,
        DumpMatchCalendarDateHandler dumpMatchDate,
        CompareMatchCalendarDatesHandler compareDates,
        SummarizeMatchCalendarHandler summarizeMatch,
        InspectDailyCalendarCandidateHandler inspectDailyCandidate,
        ScanDailyCalendarCandidatesHandler scanDailyCandidates,
        FindDailyCalendarBaseByDateHandler findDailyBase,
        DumpDailyCalendarDayHandler dumpDailyDay,
        ScanRuntimeDayIndexClustersHandler scanRuntimeClusters,
        DumpRuntimeDayPayloadFamilyHandler dumpRuntimeFamily,
        CompareRuntimeDayPayloadFamilyHandler compareRuntimeFamily,
        DumpRuntimeDayPayloadClusterDetailHandler dumpRuntimeClusterDetail,
        AnalyzeRuntimeDayPayloadClusterHandler analyzeRuntimeCluster,
        ClassifyRuntimeDayVariantHandler classifyRuntimeVariant,
        InventoryAnnualEventsHandler inventoryAnnualEvents
    ) tuple)
        : this(
            tuple.getGuide,
            tuple.findMatchBase,
            tuple.dumpMatchDate,
            tuple.compareDates,
            tuple.summarizeMatch,
            tuple.inspectDailyCandidate,
            tuple.scanDailyCandidates,
            tuple.findDailyBase,
            tuple.dumpDailyDay,
            tuple.scanRuntimeClusters,
            tuple.dumpRuntimeFamily,
            tuple.compareRuntimeFamily,
            tuple.dumpRuntimeClusterDetail,
            tuple.analyzeRuntimeCluster,
            tuple.classifyRuntimeVariant,
            tuple.inventoryAnnualEvents)
    {
    }
    private static (
        GetGuideHandler,
        FindMatchCalendarBaseHandler,
        DumpMatchCalendarDateHandler,
        CompareMatchCalendarDatesHandler,
        SummarizeMatchCalendarHandler,
        InspectDailyCalendarCandidateHandler,
        ScanDailyCalendarCandidatesHandler,
        FindDailyCalendarBaseByDateHandler,
        DumpDailyCalendarDayHandler,
        ScanRuntimeDayIndexClustersHandler,
        DumpRuntimeDayPayloadFamilyHandler,
        CompareRuntimeDayPayloadFamilyHandler,
        DumpRuntimeDayPayloadClusterDetailHandler,
        AnalyzeRuntimeDayPayloadClusterHandler,
        ClassifyRuntimeDayVariantHandler,
        InventoryAnnualEventsHandler
    ) CreateAll(ProcessMemoryApplicationService memoryService)
    {
        var memoryReader = new Pes2021MemoryReader(memoryService);
        var dailyScorer = new Pes2021DailyCalendarScorer(memoryReader);
        var addressResolver = new Pes2021AddressResolver();

        var getGuide = new GetGuideHandler();
        var findMatchBase = new FindMatchCalendarBaseHandler(memoryService, memoryReader, addressResolver);
        var dumpMatchDate = new DumpMatchCalendarDateHandler(memoryReader, addressResolver, findMatchBase);
        var compareDates = new CompareMatchCalendarDatesHandler(dumpMatchDate, addressResolver, findMatchBase);
        var summarizeMatch = new SummarizeMatchCalendarHandler(memoryReader, addressResolver, findMatchBase);

        var inspectDailyCandidate = new InspectDailyCalendarCandidateHandler(dailyScorer);
        var scanDailyCandidates = new ScanDailyCalendarCandidatesHandler(dailyScorer);
        var findDailyBase = new FindDailyCalendarBaseByDateHandler(memoryService, dailyScorer, addressResolver);
        var dumpDailyDay = new DumpDailyCalendarDayHandler(memoryReader, addressResolver, findDailyBase);

        var scanRuntimeClusters = new ScanRuntimeDayIndexClustersHandler(memoryService, memoryReader);
        var dumpRuntimeFamily = new DumpRuntimeDayPayloadFamilyHandler(memoryService, memoryReader, addressResolver, findMatchBase);
        var compareRuntimeFamily = new CompareRuntimeDayPayloadFamilyHandler(dumpRuntimeFamily);
        var dumpRuntimeClusterDetail = new DumpRuntimeDayPayloadClusterDetailHandler(dumpRuntimeFamily, memoryReader);
        var analyzeRuntimeCluster = new AnalyzeRuntimeDayPayloadClusterHandler(dumpRuntimeClusterDetail);
        var classifyRuntimeVariant = new ClassifyRuntimeDayVariantHandler(dumpDailyDay, dumpRuntimeFamily);
        var inventoryAnnualEvents = new InventoryAnnualEventsHandler(addressResolver, findMatchBase, findDailyBase, summarizeMatch, dumpDailyDay);

        return (
            getGuide,
            findMatchBase,
            dumpMatchDate,
            compareDates,
            summarizeMatch,
            inspectDailyCandidate,
            scanDailyCandidates,
            findDailyBase,
            dumpDailyDay,
            scanRuntimeClusters,
            dumpRuntimeFamily,
            compareRuntimeFamily,
            dumpRuntimeClusterDetail,
            analyzeRuntimeCluster,
            classifyRuntimeVariant,
            inventoryAnnualEvents
        );
    }

    public Task<Pes2021AgendaGuide> GetGuideAsync(string? cheatTablePath = null, CancellationToken cancellationToken = default)
        => getGuide.HandleAsync(cheatTablePath, cancellationToken);

    public Task<Pes2021CalendarBaseResult> FindBaseAsync(
        AttachmentId attachmentId,
        int? year = null,
        int? month = null,
        int? day = null,
        int? roundValue = null,
        int? competitionCode = null,
        string? moduleName = null,
        int maxResults = 100,
        CancellationToken cancellationToken = default)
        => findMatchBase.HandleAsync(attachmentId, year, month, day, roundValue, competitionCode, moduleName, maxResults, cancellationToken);

    public Task<Pes2021MatchCalendarReport> DumpMatchDateAsync(
        AttachmentId attachmentId,
        int year,
        int month,
        int day,
        ulong? baseAddress = null,
        int maxRecs = 13014,
        CancellationToken cancellationToken = default)
        => dumpMatchDate.HandleAsync(attachmentId, year, month, day, baseAddress, maxRecs, cancellationToken);

    public Task<Pes2021MatchCalendarComparisonReport> CompareDatesAsync(
        AttachmentId attachmentId,
        int firstYear,
        int firstMonth,
        int firstDay,
        int secondYear,
        int secondMonth,
        int secondDay,
        ulong? baseAddress = null,
        int maxRecs = 13014,
        CancellationToken cancellationToken = default)
        => compareDates.HandleAsync(attachmentId, firstYear, firstMonth, firstDay, secondYear, secondMonth, secondDay, baseAddress, maxRecs, cancellationToken);

    public Task<Pes2021CalendarSummary> CalendarSummaryAsync(
        AttachmentId attachmentId,
        ulong? baseAddress = null,
        int maxRecs = 13014,
        CancellationToken cancellationToken = default)
        => summarizeMatch.HandleAsync(attachmentId, baseAddress, maxRecs, cancellationToken);

    public Task<Pes2021DailyCalendarCandidateReport> InspectDailyCalendarCandidateAsync(
        AttachmentId attachmentId,
        ulong baseAddress,
        IReadOnlyList<int> sampleDays,
        CancellationToken cancellationToken = default)
        => inspectDailyCandidate.HandleAsync(attachmentId, baseAddress, sampleDays, cancellationToken);

    public Task<IReadOnlyList<Pes2021DailyCalendarCandidateReport>> ScanDailyCalendarCandidatesAsync(
        AttachmentId attachmentId,
        ulong startValue,
        ulong stopValue,
        ulong step = 0x10,
        int maxResults = 10,
        IReadOnlyList<int>? sampleDays = null,
        CancellationToken cancellationToken = default)
        => scanDailyCandidates.HandleAsync(attachmentId, startValue, stopValue, step, maxResults, sampleDays, cancellationToken);

    public Task<Pes2021CalendarBaseResult> FindDailyBaseByDateAsync(
        AttachmentId attachmentId,
        int year,
        int month,
        int day,
        string? moduleName = null,
        int maxResults = 256,
        CancellationToken cancellationToken = default)
        => findDailyBase.HandleAsync(attachmentId, year, month, day, moduleName, maxResults, cancellationToken);

    public Task<Pes2021DailyCalendarReport> DumpDailyDayAsync(
        AttachmentId attachmentId,
        int year,
        int month,
        int day,
        ulong? baseAddress = null,
        CancellationToken cancellationToken = default)
        => dumpDailyDay.HandleAsync(attachmentId, year, month, day, baseAddress, cancellationToken);

    public Task<Pes2021RuntimeCalendarScanReport> ScanRuntimeDayIndexClustersAsync(
        AttachmentId attachmentId,
        int year,
        int month,
        int day,
        int maxResults = 5000,
        int clusterGap = 0x1000,
        int previewBytes = 0x100,
        CancellationToken cancellationToken = default)
        => scanRuntimeClusters.HandleAsync(attachmentId, year, month, day, maxResults, clusterGap, previewBytes, cancellationToken);

    public Task<Pes2021RuntimeCalendarFamilyReport> DumpRuntimeDayPayloadFamilyAsync(
        AttachmentId attachmentId,
        int year,
        int month,
        int day,
        ulong? startAddress = null,
        ulong? stopAddress = null,
        ulong? matchBaseAddress = null,
        int[]? preferredStrides = null,
        int minHitCount = 3,
        int clusterGap = 0x1000,
        int previewBytes = 0x100,
        CancellationToken cancellationToken = default)
        => dumpRuntimeFamily.HandleAsync(attachmentId, year, month, day, startAddress, stopAddress, matchBaseAddress, preferredStrides, minHitCount, clusterGap, previewBytes, cancellationToken);

    public Task<Pes2021RuntimeCalendarFamilyComparisonReport> CompareRuntimeDayPayloadFamilyAsync(
        AttachmentId attachmentId,
        int year,
        int month,
        int day,
        ulong? startAddress = null,
        ulong? stopAddress = null,
        ulong? matchBaseAddress = null,
        int[]? preferredStrides = null,
        int minHitCount = 3,
        int clusterGap = 0x1000,
        int previewBytes = 0x100,
        CancellationToken cancellationToken = default)
        => compareRuntimeFamily.HandleAsync(attachmentId, year, month, day, startAddress, stopAddress, matchBaseAddress, preferredStrides, minHitCount, clusterGap, previewBytes, cancellationToken);

    public Task<Pes2021RuntimeCalendarClusterDetailReport> DumpRuntimeDayPayloadClusterDetailAsync(
        AttachmentId attachmentId,
        int year,
        int month,
        int day,
        int clusterOrdinal,
        ulong? startAddress = null,
        ulong? stopAddress = null,
        ulong? matchBaseAddress = null,
        int[]? preferredStrides = null,
        int minHitCount = 3,
        int clusterGap = 0x1000,
        int previewBytes = 0x100,
        int intsBeforeHit = 8,
        int intsAfterHit = 24,
        CancellationToken cancellationToken = default)
        => dumpRuntimeClusterDetail.HandleAsync(attachmentId, year, month, day, clusterOrdinal, startAddress, stopAddress, matchBaseAddress, preferredStrides, minHitCount, clusterGap, previewBytes, intsBeforeHit, intsAfterHit, cancellationToken);

    public Task<Pes2021RuntimeCalendarClusterSignatureReport> AnalyzeRuntimeDayPayloadClusterAsync(
        AttachmentId attachmentId,
        int year,
        int month,
        int day,
        int clusterOrdinal,
        ulong? startAddress = null,
        ulong? stopAddress = null,
        ulong? matchBaseAddress = null,
        int[]? preferredStrides = null,
        int minHitCount = 3,
        int clusterGap = 0x1000,
        int previewBytes = 0x100,
        int intsBeforeHit = 8,
        int intsAfterHit = 24,
        CancellationToken cancellationToken = default)
        => analyzeRuntimeCluster.HandleAsync(attachmentId, year, month, day, clusterOrdinal, startAddress, stopAddress, matchBaseAddress, preferredStrides, minHitCount, clusterGap, previewBytes, intsBeforeHit, intsAfterHit, cancellationToken);

    public Task<Pes2021RuntimeCalendarVariantReport> ClassifyRuntimeDayVariantAsync(
        AttachmentId attachmentId,
        int year,
        int month,
        int day,
        ulong? startAddress = null,
        ulong? stopAddress = null,
        ulong? dailyBaseAddress = null,
        ulong? matchBaseAddress = null,
        int[]? preferredStrides = null,
        int minHitCount = 3,
        int clusterGap = 0x1000,
        int previewBytes = 0x100,
        CancellationToken cancellationToken = default)
        => classifyRuntimeVariant.HandleAsync(attachmentId, year, month, day, startAddress, stopAddress, dailyBaseAddress, matchBaseAddress, preferredStrides, minHitCount, clusterGap, previewBytes, cancellationToken);

    public Task<Pes2021AnnualCalendarEventInventoryReport> InventoryAnnualEventsAsync(
        AttachmentId attachmentId,
        int year,
        ulong? matchBaseAddress = null,
        ulong? dailyBaseAddress = null,
        CancellationToken cancellationToken = default)
        => inventoryAnnualEvents.HandleAsync(attachmentId, year, matchBaseAddress, dailyBaseAddress, cancellationToken);
}
