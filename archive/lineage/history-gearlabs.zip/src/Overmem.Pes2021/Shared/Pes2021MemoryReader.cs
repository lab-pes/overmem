using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Overmem.Abstractions.Memory;
using Overmem.Abstractions.Processes;
using Overmem.Application;

namespace Overmem.Application.Pes2021.Shared;

public sealed record dailyHeaderState(bool Ok, string State);

public sealed class Pes2021MemoryReader(ProcessMemoryApplicationService memoryService)
{
    public static readonly int DailyMaxItems = (Pes2021AgendaProfile.DailyItemsEnd - Pes2021AgendaProfile.DailyItemsStart) / sizeof(ushort);

    public async Task<byte[]?> ReadBytesAsync(AttachmentId attachmentId, ulong address, int size, CancellationToken cancellationToken)
    {
        try
        {
            var result = await memoryService.ReadAsync(
                new ReadMemoryRequest(attachmentId, address, MemoryValueKind.Bytes, size),
                cancellationToken);

            return Convert.FromHexString(result.Value);
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch
        {
            return null;
        }
    }

    public async Task<byte[]> ReadClusterPreviewBytesAsync(
        AttachmentId attachmentId,
        ulong clusterStartAddress,
        ulong regionBaseAddress,
        ulong regionSize,
        int requestedSize,
        CancellationToken cancellationToken)
    {
        var clippedSize = ClipReadSizeToRegion(regionBaseAddress, regionSize, clusterStartAddress, requestedSize);
        if (clippedSize <= 0)
        {
            return [];
        }

        return await ReadBytesAsync(attachmentId, clusterStartAddress, clippedSize, cancellationToken) ?? [];
    }

    public async Task<Pes2021CalendarRecordSnapshot?> TryReadMatchRecordAsync(
        AttachmentId attachmentId,
        ulong address,
        int index,
        CancellationToken cancellationToken)
    {
        var bytes = await ReadBytesAsync(attachmentId, address, Pes2021AgendaProfile.MatchRecordStride, cancellationToken);
        if (bytes is null || bytes.Length < Pes2021AgendaProfile.MatchRecordStride)
        {
            return null;
        }

        var competitionCode = BinaryPrimitives.ReadUInt16LittleEndian(bytes.AsSpan(0x00, sizeof(ushort)));
        var roundValue = bytes[0x02];
        var year = BinaryPrimitives.ReadUInt16LittleEndian(bytes.AsSpan(0x04, sizeof(ushort)));
        var month = bytes[0x06];
        var day = bytes[0x07];
        var homeId = BinaryPrimitives.ReadUInt16LittleEndian(bytes.AsSpan(0x10, sizeof(ushort)));
        var homeLiga = BinaryPrimitives.ReadUInt16LittleEndian(bytes.AsSpan(0x12, sizeof(ushort)));
        var awayId = BinaryPrimitives.ReadUInt16LittleEndian(bytes.AsSpan(0x14, sizeof(ushort)));
        var awayLiga = BinaryPrimitives.ReadUInt16LittleEndian(bytes.AsSpan(0x16, sizeof(ushort)));
        var homeScore = bytes[0x18];
        var awayScore = bytes[0x1B];
        var competitionName = Pes2021CalendarHelpers.GetCompetitionName(competitionCode);

        return new Pes2021CalendarRecordSnapshot(
            index,
            address,
            competitionCode,
            competitionName,
            roundValue,
            year,
            month,
            day,
            homeId,
            homeLiga,
            awayId,
            awayLiga,
            homeScore,
            awayScore,
            homeId == 65535 || awayId == 65535,
            Pes2021CalendarHelpers.BuildEventId(index, competitionCode, year, month, day, roundValue, homeId, awayId, homeLiga));
    }

    public static (IReadOnlyList<ushort>? Items, bool TerminatorFound) ReadDailyCalendarItemsFromBlock(byte[] block)
    {
        var items = new List<ushort>();
        var itemsBase = Pes2021AgendaProfile.DailyItemsStart;
        var terminatorFound = false;
        var maxItems = DailyMaxItems;

        for (var itemIndex = 0; itemIndex < maxItems; itemIndex++)
        {
            var offset = itemsBase + (itemIndex * sizeof(ushort));
            if (offset + sizeof(ushort) > block.Length)
            {
                return (null, false);
            }

            var value = BinaryPrimitives.ReadUInt16LittleEndian(block.AsSpan(offset, sizeof(ushort)));
            if (value == 0xFFFF)
            {
                terminatorFound = true;
                break;
            }

            items.Add(value);
        }

        return (items, terminatorFound);
    }

    public static dailyHeaderState EvaluateDailyCalendarHeader(byte[] block)
    {
        var validSlots = 0;
        var sawTerminator = false;

        for (var slotIndex = 0; slotIndex < Pes2021AgendaProfile.DailyHeaderMaxEvents; slotIndex++)
        {
            var slotOffset = slotIndex * Pes2021AgendaProfile.DailyHeaderEventSize;
            if (slotOffset + Pes2021AgendaProfile.DailyHeaderEventSize > block.Length)
            {
                return new dailyHeaderState(false, "unreadable");
            }

            var year = BinaryPrimitives.ReadUInt16LittleEndian(block.AsSpan(slotOffset, sizeof(ushort)));
            if (year == 0xFFFF)
            {
                sawTerminator = true;
                break;
            }

            var month = block[slotOffset + 0x02];
            var day = block[slotOffset + 0x03];
            if (year < 2020 || year > 2040 || month is < 1 or > 12 || day is < 1 or > 31)
            {
                return new dailyHeaderState(false, $"slot_{slotIndex}_invalid");
            }

            validSlots++;
        }

        if (validSlots == 0 && !sawTerminator)
        {
            return new dailyHeaderState(false, "no_terminator");
        }

        return new dailyHeaderState(true, sawTerminator ? "terminator" : "valid_slots");
    }

    public static IReadOnlyList<Pes2021DailyCalendarHeaderEvent> ReadDailyHeaderEvents(byte[] block)
    {
        var events = new List<Pes2021DailyCalendarHeaderEvent>();
        for (var slotIndex = 0; slotIndex < Pes2021AgendaProfile.DailyHeaderMaxEvents; slotIndex++)
        {
            var slotOffset = slotIndex * Pes2021AgendaProfile.DailyHeaderEventSize;
            if (slotOffset + Pes2021AgendaProfile.DailyHeaderEventSize > block.Length)
            {
                break;
            }

            var year = BinaryPrimitives.ReadUInt16LittleEndian(block.AsSpan(slotOffset, sizeof(ushort)));
            if (year == 0xFFFF)
            {
                break;
            }

            var month = block[slotOffset + 0x02];
            var day = block[slotOffset + 0x03];
            var type = BinaryPrimitives.ReadUInt16LittleEndian(block.AsSpan(slotOffset + 0x04, sizeof(ushort)));
            var value = BinaryPrimitives.ReadInt16LittleEndian(block.AsSpan(slotOffset + 0x06, sizeof(short)));
            events.Add(new Pes2021DailyCalendarHeaderEvent(slotIndex, year, month, day, type, value));
        }

        return events;
    }

    public static bool IsPlausibleMatchRecord(Pes2021CalendarRecordSnapshot? record)
    {
        if (record is null)
        {
            return false;
        }

        return record.CompetitionCode is > 0 and <= Pes2021CalendarHelpers.MaxPlausibleCompetitionCode
            && record.Year is >= 2020 and <= 2040
            && record.Month is >= 1 and <= 12
            && record.Day is >= 1 and <= 31
            && record.Round is >= 0 and <= 80;
    }

    public static bool IsStrongMatchRecord(Pes2021CalendarRecordSnapshot? record)
    {
        if (!IsPlausibleMatchRecord(record))
        {
            return false;
        }

        return record!.HomeId is >= 0 and <= 5000
            && record.AwayId is >= 0 and <= 5000;
    }

    public static IReadOnlyList<MemoryRegionInfo> FilterRuntimeScanRegions(
        IReadOnlyList<MemoryRegionInfo> regions,
        ulong? startAddress,
        ulong? stopAddress)
    {
        var filtered = regions
            .Where(static region =>
                region.IsReadable
                && region.IsWritable
                && !region.IsExecutable
                && string.Equals(region.Type, "Private", StringComparison.OrdinalIgnoreCase))
            .Where(region =>
            {
                var regionStart = region.BaseAddress;
                var regionStop = checked(region.BaseAddress + region.RegionSize);
                if (startAddress.HasValue && regionStop <= startAddress.Value)
                {
                    return false;
                }

                if (stopAddress.HasValue && regionStart >= stopAddress.Value)
                {
                    return false;
                }

                return true;
            })
            .OrderBy(static region => region.BaseAddress)
            .ToArray();

        return filtered;
    }

    public async Task<IReadOnlyList<ulong>> ScanInt32InRegionAsync(
        AttachmentId attachmentId,
        MemoryRegionInfo region,
        int expectedValue,
        ulong? scanStartAddress,
        ulong? scanStopAddress,
        CancellationToken cancellationToken)
    {
        const int chunkSize = 64 * 1024;
        const int scanAlignment = sizeof(int);
        var expectedBytes = BitConverter.GetBytes(expectedValue);
        var matches = new List<ulong>();
        var overlap = expectedBytes.Length - 1;

        var regionStart = region.BaseAddress;
        var regionStop = checked(region.BaseAddress + region.RegionSize);
        var startOffset = scanStartAddress.HasValue ? Math.Max(regionStart, scanStartAddress.Value) - regionStart : 0UL;
        var stopOffset = scanStopAddress.HasValue ? Math.Min(regionStop, scanStopAddress.Value) - regionStart : region.RegionSize;
        if (startOffset >= stopOffset)
        {
            return matches;
        }

        var alignmentRemainder = startOffset % (ulong)scanAlignment;
        if (alignmentRemainder != 0)
        {
            startOffset += (ulong)scanAlignment - alignmentRemainder;
        }

        if (startOffset >= stopOffset)
        {
            return matches;
        }

        for (var cursor = startOffset; cursor < stopOffset; cursor += (ulong)chunkSize)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var remaining = stopOffset - cursor;
            var primaryLength = (int)Math.Min((ulong)chunkSize, remaining);
            var bytesToRead = (int)Math.Min((ulong)(chunkSize + overlap), remaining);
            var absoluteAddress = checked(region.BaseAddress + cursor);
            var buffer = await ReadBytesAsync(attachmentId, absoluteAddress, bytesToRead, cancellationToken);
            if (buffer is null || buffer.Length < expectedBytes.Length)
            {
                continue;
            }

            var scanLimit = Math.Min(primaryLength, buffer.Length - expectedBytes.Length + 1);
            for (var position = 0; position < scanLimit; position += scanAlignment)
            {
                if (buffer[position] != expectedBytes[0]
                    || buffer[position + 1] != expectedBytes[1]
                    || buffer[position + 2] != expectedBytes[2]
                    || buffer[position + 3] != expectedBytes[3])
                {
                    continue;
                }

                matches.Add(absoluteAddress + (ulong)position);
            }
        }

        return matches;
    }

    public static List<RuntimeClusterBuilder> BuildRuntimeClusters(
        IReadOnlyList<ulong> hits,
        IReadOnlyList<MemoryRegionInfo> regions,
        int clusterGap)
    {
        var clusters = new List<RuntimeClusterBuilder>();
        RuntimeClusterBuilder? current = null;

        foreach (var hit in hits)
        {
            var region = FindRegion(regions, hit);
            if (region is null)
            {
                continue;
            }

            if (current is null
                || current.Region.BaseAddress != region.BaseAddress
                || hit - current.EndAddress > (ulong)clusterGap)
            {
                current = new RuntimeClusterBuilder(region);
                clusters.Add(current);
            }

            current.Add(hit);
        }

        return clusters;
    }

    public static MemoryRegionInfo? FindRegion(IReadOnlyList<MemoryRegionInfo> regions, ulong address)
        => regions.FirstOrDefault(region =>
            region.BaseAddress <= address
            && checked(region.BaseAddress + region.RegionSize) > address);

    public static IReadOnlyList<int> DecodeInt32Preview(byte[] buffer)
    {
        if (buffer.Length < sizeof(int))
        {
            return [];
        }

        var count = Math.Min(buffer.Length / sizeof(int), 64);
        var values = new int[count];
        for (var index = 0; index < count; index++)
        {
            values[index] = BinaryPrimitives.ReadInt32LittleEndian(buffer.AsSpan(index * sizeof(int), sizeof(int)));
        }

        return values;
    }

    private static int ClipReadSizeToRegion(
        ulong regionBaseAddress,
        ulong regionSize,
        ulong readAddress,
        int requestedSize)
    {
        if (requestedSize <= 0)
        {
            return 0;
        }

        var regionStop = checked(regionBaseAddress + regionSize);
        if (readAddress >= regionStop)
        {
            return 0;
        }

        var remainingBytes = regionStop - readAddress;
        return (int)Math.Min((ulong)requestedSize, remainingBytes);
    }

    public async Task<IReadOnlyList<Pes2021RuntimeCalendarPreviewRecord>> DecodeRuntimePreviewRecordsAsync(
        AttachmentId attachmentId,
        ulong? baseAddress,
        IReadOnlyList<int> previewValues,
        CancellationToken cancellationToken)
    {
        if (previewValues.Count == 0)
        {
            return [];
        }

        var results = new List<Pes2021RuntimeCalendarPreviewRecord>(previewValues.Count);
        foreach (var value in previewValues.Take(32))
        {
            cancellationToken.ThrowIfCancellationRequested();

            if (baseAddress is null || value < 0 || value >= 13014)
            {
                results.Add(new Pes2021RuntimeCalendarPreviewRecord(value, false, null));
                continue;
            }

            var record = await TryReadMatchRecordAsync(
                attachmentId,
                baseAddress.Value + (ulong)(value * Pes2021AgendaProfile.MatchRecordStride),
                value,
                cancellationToken);

            if (IsPlausibleMatchRecord(record))
            {
                results.Add(new Pes2021RuntimeCalendarPreviewRecord(value, true, record));
                continue;
            }

            results.Add(new Pes2021RuntimeCalendarPreviewRecord(value, false, null));
        }

        return results;
    }
}

public sealed class RuntimeClusterBuilder(MemoryRegionInfo region)
{
    public MemoryRegionInfo Region { get; } = region;

    public List<ulong> Addresses { get; } = [];

    public ulong StartAddress => Addresses[0];

    public ulong EndAddress => Addresses[^1];

    public int TypicalStride
    {
        get
        {
            if (Addresses.Count < 2)
            {
                return 0;
            }

            return Addresses
                .Zip(Addresses.Skip(1), static (left, right) => checked((int)(right - left)))
                .GroupBy(static delta => delta)
                .OrderByDescending(group => group.Count())
                .ThenBy(group => group.Key)
                .Select(group => group.Key)
                .FirstOrDefault();
        }
    }

    public void Add(ulong address) => Addresses.Add(address);
}
