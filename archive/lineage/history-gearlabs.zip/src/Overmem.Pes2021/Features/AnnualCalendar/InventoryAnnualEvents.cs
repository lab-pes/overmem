using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Overmem.Abstractions.Processes;
using Overmem.Application;
using Overmem.Application.Pes2021.Features.DailyCalendar;
using Overmem.Application.Pes2021.Features.MatchCalendar;
using Overmem.Application.Pes2021.Shared;

namespace Overmem.Application.Pes2021.Features.AnnualCalendar;

public sealed class InventoryAnnualEventsHandler(
    Pes2021AddressResolver addressResolver,
    FindMatchCalendarBaseHandler findMatchBase,
    FindDailyCalendarBaseByDateHandler findDailyBase,
    SummarizeMatchCalendarHandler summarizeMatchCalendar,
    DumpDailyCalendarDayHandler dumpDailyDay)
{
    public async Task<Pes2021AnnualCalendarEventInventoryReport> HandleAsync(
        AttachmentId attachmentId,
        int year,
        ulong? matchBaseAddress = null,
        ulong? dailyBaseAddress = null,
        CancellationToken cancellationToken = default)
    {
        var resolvedMatchBase = await addressResolver.ResolveMatchBaseAddressAsync(
            attachmentId,
            matchBaseAddress,
            (id, ct) => findMatchBase.HandleAsync(id, cancellationToken: ct),
            cancellationToken);

        var resolveddailyBase = await addressResolver.ResolveDailyBaseAddressAsync(
            attachmentId,
            year,
            9,
            22,
            dailyBaseAddress,
            (id, y, m, d, ct) => findDailyBase.HandleAsync(id, y, m, d, cancellationToken: ct),
            cancellationToken);

        var summary = await summarizeMatchCalendar.HandleAsync(attachmentId, resolvedMatchBase, cancellationToken: cancellationToken);
        var matchCounts = summary.Dates.ToDictionary(
            static item => item.Date,
            static item => item.MatchCount,
            StringComparer.Ordinal);

        var days = new List<Pes2021AnnualCalendarEventEntry>();
        var startDate = new DateOnly(year, 1, 1);
        for (var offset = 0; offset < Pes2021AgendaProfile.DailyDayCount; offset++)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var date = startDate.AddDays(offset);
            var previousDate = date.AddDays(-1);
            var nextDate = date.AddDays(1);
            var dateKey = $"{date:yyyy-MM-dd}";
            var previousDateKey = $"{previousDate:yyyy-MM-dd}";
            var nextDateKey = $"{nextDate:yyyy-MM-dd}";
            var mainMatchCount = matchCounts.TryGetValue(dateKey, out var currentMatches) ? currentMatches : 0;
            var previousDayMainMatchCount = matchCounts.TryGetValue(previousDateKey, out var previousMatches) ? previousMatches : 0;
            var nextDayMainMatchCount = matchCounts.TryGetValue(nextDateKey, out var nextMatches) ? nextMatches : 0;

            var daily = await dumpDailyDay.HandleAsync(
                attachmentId,
                date.Year,
                date.Month,
                date.Day,
                resolveddailyBase,
                cancellationToken);

            var headerTypes = daily.HeaderEvents
                .Select(item => item.Type)
                .Distinct()
                .OrderBy(static value => value)
                .ToArray();

            var (semanticEventKey, semanticEventConfidence, semanticReasons) = Pes2021CalendarHelpers.ClassifySemanticEvent(
                date.Year,
                date.Month,
                date.Day,
                headerTypes,
                daily.Count,
                clusterCount: 0,
                variantKey: "inventory_only");

            if (semanticEventKey == "unknown_event"
                && mainMatchCount > 0
                && daily.Count == 0
                && daily.Items.Count == 0
                && headerTypes.Any(static value => value == 0x000D)
                && headerTypes.Any(static value => value == 0x003F))
            {
                semanticEventKey = "libertadores_round_of_16_first_leg_placeholder_candidate";
                semanticEventConfidence = "medium";
                semanticReasons =
                [
                    "matched_inventory_only_libertadores_round_of_16_first_leg_placeholder_signature",
                    $"main_match_count={mainMatchCount}",
                    $"header_types={string.Join(",", headerTypes.Select(static value => $"0x{value:X4}"))}"
                ];
            }

            if (semanticEventKey == "unknown_event"
                && mainMatchCount == 0
                && daily.Count == 0
                && daily.Items.Count == 0
                && (headerTypes.Length == 0 || headerTypes.All(static value => value == 0x003F)))
            {
                continue;
            }
            var (inventoryPatternKey, inventoryPatternConfidence, inventoryPatternReasons) = Pes2021CalendarHelpers.ClassifyInventoryPattern(
                headerTypes,
                daily.Count,
                daily.Items.Count,
                mainMatchCount,
                previousDayMainMatchCount,
                nextDayMainMatchCount,
                semanticEventKey);

            var (sourceRole, visibility, stopState) = Pes2021CalendarHelpers.BuildInventoryDisposition(
                mainMatchCount,
                daily.Count,
                daily.Items.Count,
                headerTypes.Length,
                semanticEventKey,
                inventoryPatternKey);
            var dayRole = Pes2021CalendarHelpers.BuildInventoryDayRole(
                mainMatchCount,
                semanticEventKey,
                inventoryPatternKey);

            days.Add(new Pes2021AnnualCalendarEventEntry(
                $"{date:yyyy-MM-dd}",
                daily.DayIndex,
                mainMatchCount,
                previousDayMainMatchCount,
                nextDayMainMatchCount,
                daily.Count,
                daily.Items.Count,
                headerTypes,
                semanticEventKey,
                semanticEventConfidence,
                semanticReasons,
                inventoryPatternKey,
                inventoryPatternConfidence,
                dayRole,
                sourceRole,
                visibility,
                stopState,
                inventoryPatternReasons));
        }

        return new Pes2021AnnualCalendarEventInventoryReport(
            attachmentId.Value,
            year,
            resolvedMatchBase,
            resolveddailyBase,
            days.Count,
            days
                .OrderBy(static item => item.Date, StringComparer.Ordinal)
                .ToArray());
    }
}
