using System.Threading;
using System.Threading.Tasks;
using Overmem.Application.Pes2021;

namespace Overmem.Application.Pes2021.Features.AnnualCalendar;

public sealed class GetGuideHandler
{
    public Task<Pes2021AgendaGuide> HandleAsync(string? cheatTablePath = null, CancellationToken cancellationToken = default)
    {
        return Task.FromResult(Pes2021AgendaProfile.LoadGuide(cheatTablePath));
    }
}
