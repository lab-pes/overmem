using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Overmem.Abstractions.Processes;
using Overmem.Application.Pes2021.Shared;

namespace Overmem.Application.Pes2021.Features.MatchCalendar;

public sealed class CompareMatchCalendarDatesHandler(
    DumpMatchCalendarDateHandler dumpMatchDate,
    Pes2021AddressResolver addressResolver,
    FindMatchCalendarBaseHandler findMatchBase)
{
    public async Task<Pes2021MatchCalendarComparisonReport> HandleAsync(
        AttachmentId attachmentId,
        int firstYear,
        int firstMonth,
        int firstDay,
        int secondYear,
        int secondMonth,
        int secondDay,
        ulong? baseAddress = null,
        int maxRecs = 13014,
        CancellationToken cancellationToken = default)
    {
        var resolvedBase = await addressResolver.ResolveMatchBaseAddressAsync(
            attachmentId,
            baseAddress,
            (id, ct) => findMatchBase.HandleAsync(id, cancellationToken: ct),
            cancellationToken);

        var firstDate = await dumpMatchDate.HandleAsync(attachmentId, firstYear, firstMonth, firstDay, resolvedBase, maxRecs, cancellationToken);
        var secondDate = await dumpMatchDate.HandleAsync(attachmentId, secondYear, secondMonth, secondDay, resolvedBase, maxRecs, cancellationToken);

        var comparisons = firstDate.Competitions
            .Concat(secondDate.Competitions)
            .GroupBy(item => item.CompetitionCode)
            .Select(group =>
            {
                var first = firstDate.Competitions.FirstOrDefault(item => item.CompetitionCode == group.Key);
                var second = secondDate.Competitions.FirstOrDefault(item => item.CompetitionCode == group.Key);
                var competitionName = Pes2021CalendarHelpers.ResolveComparisonCompetitionName(first, second);

                return new Pes2021CompetitionDateComparison(
                    group.Key,
                    competitionName,
                    first?.MatchCount ?? 0,
                    first?.Rounds ?? string.Empty,
                    second?.MatchCount ?? 0,
                    second?.Rounds ?? string.Empty);
            })
            .OrderBy(item => item.CompetitionCode)
            .ToArray();

        return new Pes2021MatchCalendarComparisonReport(
            resolvedBase,
            firstDate,
            secondDate,
            comparisons);
    }
}
