using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Overmem.Abstractions.Processes;
using Overmem.Application.Pes2021.Shared;

namespace Overmem.Application.Pes2021.Features.MatchCalendar;

public sealed class SummarizeMatchCalendarHandler(
    Pes2021MemoryReader memoryReader,
    Pes2021AddressResolver addressResolver,
    FindMatchCalendarBaseHandler findMatchBase)
{
    public async Task<Pes2021CalendarSummary> HandleAsync(
        AttachmentId attachmentId,
        ulong? baseAddress = null,
        int maxRecs = 13014,
        CancellationToken cancellationToken = default)
    {
        var resolvedBase = await addressResolver.ResolveMatchBaseAddressAsync(
            attachmentId,
            baseAddress,
            (id, ct) => findMatchBase.HandleAsync(id, cancellationToken: ct),
            cancellationToken);

        var dates = new Dictionary<string, SummaryBuilder>(StringComparer.Ordinal);
        var totalMatches = 0;

        for (var index = 0; index < maxRecs; index++)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var record = await memoryReader.TryReadMatchRecordAsync(
                attachmentId,
                resolvedBase + (ulong)(index * Pes2021AgendaProfile.MatchRecordStride),
                index,
                cancellationToken);

            if (record is null || !Pes2021MemoryReader.IsPlausibleMatchRecord(record))
            {
                continue;
            }

            totalMatches++;
            var dateKey = Pes2021CalendarHelpers.FormatDateKey(record.Year, record.Month, record.Day);
            var builder = Pes2021CalendarHelpers.GetOrCreateSummaryBuilder(dates, dateKey, record.Year, record.Month, record.Day);
            builder.MatchCount++;
            builder.Competitions.Add(record.CompetitionCode);
        }

        var entries = dates
            .OrderBy(pair => pair.Key, StringComparer.Ordinal)
            .Select(pair => new Pes2021CalendarSummaryEntry(
                pair.Value.Date,
                pair.Value.MatchCount,
                pair.Value.Competitions.Count))
            .ToArray();

        return new Pes2021CalendarSummary(
            resolvedBase,
            entries.Length,
            totalMatches,
            entries);
    }
}
