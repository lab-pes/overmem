using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Overmem.Abstractions.Memory;
using Overmem.Abstractions.Processes;
using Overmem.Application;
using Overmem.Application.Pes2021.Shared;

namespace Overmem.Application.Pes2021.Features.MatchCalendar;

public sealed class FindMatchCalendarBaseHandler(
    ProcessMemoryApplicationService memoryService,
    Pes2021MemoryReader memoryReader,
    Pes2021AddressResolver addressResolver)
{
    private sealed record SearchPatternSpec(string Name, string Pattern, long[] Adjustments);

    public async Task<Pes2021CalendarBaseResult> HandleAsync(
        AttachmentId attachmentId,
        int? year = null,
        int? month = null,
        int? day = null,
        int? roundValue = null,
        int? competitionCode = null,
        string? moduleName = null,
        int maxResults = 100,
        CancellationToken cancellationToken = default)
    {
        maxResults = Math.Max(1, maxResults);
        var years = year.HasValue ? [year.Value] : Pes2021AgendaProfile.SeasonAnchorYears;
        var targetMonth = month ?? 2;
        var targetDay = day ?? 1;
        var targetRound = roundValue ?? 1;
        var targetCompetitionCode = competitionCode ?? 29;
        Pes2021CalendarBaseResult? best = null;

        foreach (var anchorYear in years)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var result = await FindBaseForDateAsync(
                attachmentId,
                anchorYear,
                targetMonth,
                targetDay,
                targetRound,
                targetCompetitionCode,
                moduleName,
                maxResults,
                cancellationToken);

            if (result is not null)
            {
                best = result;
                break;
            }
        }

        if (best is null)
        {
            throw new InvalidOperationException("No validated Master League calendar base was found for the PES 2021 agenda.");
        }

        addressResolver.BaseCache[attachmentId] = best;
        return best;
    }

    private async Task<Pes2021CalendarBaseResult?> FindBaseForDateAsync(
        AttachmentId attachmentId,
        int year,
        int month,
        int day,
        int roundValue,
        int competitionCode,
        string? moduleName,
        int maxResults,
        CancellationToken cancellationToken)
    {
        var patterns = new[]
        {
            new SearchPatternSpec(
                "specific",
                Pes2021CalendarHelpers.BuildMatchDatePattern(year, month, day, roundValue, competitionCode),
                new long[] { 0 }),
            new SearchPatternSpec(
                "generic",
                Pes2021CalendarHelpers.BuildMatchDateOnlyPattern(year, month, day),
                new long[] { -4, 0 }),
        };

        foreach (var pattern in patterns)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var scanResult = await memoryService.ScanPatternAsync(
                new PatternScanRequest(attachmentId, pattern.Pattern, moduleName, maxResults),
                cancellationToken);

            if (scanResult.Addresses.Count == 0)
            {
                continue;
            }

            var candidates = new List<Pes2021CalendarBaseCandidate>();
            foreach (var matchAddress in scanResult.Addresses)
            {
                cancellationToken.ThrowIfCancellationRequested();

                foreach (var adjustment in pattern.Adjustments)
                {
                    if (adjustment < 0 && matchAddress < unchecked((ulong)(-adjustment)))
                    {
                        continue;
                    }

                    var candidateBaseAddress = adjustment >= 0
                        ? matchAddress + unchecked((ulong)adjustment)
                        : matchAddress - unchecked((ulong)(-adjustment));

                    var validationScore = await ValidateBaseAsync(attachmentId, candidateBaseAddress, 10, cancellationToken);
                    var strongScore = await CountStrongRecordsAsync(attachmentId, candidateBaseAddress, 10, cancellationToken);
                    var clusterSpan = await CountClusterSpanAsync(attachmentId, candidateBaseAddress, 256, cancellationToken);
                    candidates.Add(new Pes2021CalendarBaseCandidate(
                        matchAddress,
                        candidateBaseAddress,
                        validationScore,
                        validationScore,
                        strongScore,
                        clusterSpan,
                        roundValue,
                        false));
                }
            }

            var bestCandidate = candidates
                .OrderByDescending(candidate => candidate.ValidationScore)
                .ThenByDescending(candidate => candidate.DetailScore1)
                .ThenByDescending(candidate => candidate.DetailScore2)
                .ThenBy(candidate => candidate.CandidateBaseAddress)
                .FirstOrDefault();

            if (bestCandidate is null || bestCandidate.ValidationScore < 5)
            {
                continue;
            }

            var normalizedBase = await NormalizeClusterStartAsync(attachmentId, bestCandidate.CandidateBaseAddress, 512, cancellationToken);
            var anchorIndex = normalizedBase <= bestCandidate.CandidateBaseAddress
                ? checked((int)((bestCandidate.CandidateBaseAddress - normalizedBase) / (ulong)Pes2021AgendaProfile.MatchRecordStride))
                : 0;

            return new Pes2021CalendarBaseResult(
                attachmentId.Value,
                Pes2021CalendarLayout.Match,
                bestCandidate.HitAddress,
                bestCandidate.CandidateBaseAddress,
                normalizedBase,
                anchorIndex,
                bestCandidate.Score,
                bestCandidate.ValidationScore,
                pattern.Pattern,
                pattern.Name,
                year,
                competitionCode,
                roundValue,
                candidates
                    .OrderByDescending(candidate => candidate.ValidationScore)
                    .ThenByDescending(candidate => candidate.DetailScore1)
                    .ThenByDescending(candidate => candidate.DetailScore2)
                    .ThenBy(candidate => candidate.CandidateBaseAddress)
                    .Take(10)
                    .ToArray());
        }

        return null;
    }

    private async Task<int> ValidateBaseAsync(AttachmentId attachmentId, ulong baseAddress, int sampleCount, CancellationToken cancellationToken)
    {
        var score = 0;
        for (var index = 0; index < sampleCount; index++)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var record = await memoryReader.TryReadMatchRecordAsync(attachmentId, baseAddress + (ulong)(index * Pes2021AgendaProfile.MatchRecordStride), index, cancellationToken);
            if (record is null || !Pes2021MemoryReader.IsPlausibleMatchRecord(record))
            {
                break;
            }

            score++;
        }

        return score;
    }

    private async Task<int> CountStrongRecordsAsync(AttachmentId attachmentId, ulong baseAddress, int sampleCount, CancellationToken cancellationToken)
    {
        var score = 0;
        for (var index = 0; index < sampleCount; index++)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var record = await memoryReader.TryReadMatchRecordAsync(attachmentId, baseAddress + (ulong)(index * Pes2021AgendaProfile.MatchRecordStride), index, cancellationToken);
            if (record is null || !Pes2021MemoryReader.IsStrongMatchRecord(record))
            {
                break;
            }

            score++;
        }

        return score;
    }

    private async Task<int> CountClusterSpanAsync(AttachmentId attachmentId, ulong baseAddress, int maxSteps, CancellationToken cancellationToken)
    {
        var backward = 0;
        var forward = 0;

        var cursor = baseAddress >= (ulong)Pes2021AgendaProfile.MatchRecordStride
            ? baseAddress - (ulong)Pes2021AgendaProfile.MatchRecordStride
            : 0;

        while (backward < maxSteps && cursor > 0)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var record = await memoryReader.TryReadMatchRecordAsync(attachmentId, cursor, -1, cancellationToken);
            if (record is null || !Pes2021MemoryReader.IsPlausibleMatchRecord(record) || !await HasForwardPlausibleRunAsync(attachmentId, cursor, 4, 3, cancellationToken))
            {
                break;
            }

            backward++;
            if (cursor < (ulong)Pes2021AgendaProfile.MatchRecordStride)
            {
                break;
            }

            cursor -= (ulong)Pes2021AgendaProfile.MatchRecordStride;
        }

        cursor = baseAddress + (ulong)Pes2021AgendaProfile.MatchRecordStride;
        while (forward < maxSteps)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var record = await memoryReader.TryReadMatchRecordAsync(attachmentId, cursor, -1, cancellationToken);
            if (record is null || !Pes2021MemoryReader.IsPlausibleMatchRecord(record) || !await HasForwardPlausibleRunAsync(attachmentId, cursor, 4, 3, cancellationToken))
            {
                break;
            }

            forward++;
            cursor += (ulong)Pes2021AgendaProfile.MatchRecordStride;
        }

        return backward + 1 + forward;
    }

    private async Task<ulong> NormalizeClusterStartAsync(AttachmentId attachmentId, ulong baseAddress, int maxSteps, CancellationToken cancellationToken)
    {
        var startBase = baseAddress;
        var steps = 0;
        var cursor = baseAddress >= (ulong)Pes2021AgendaProfile.MatchRecordStride
            ? baseAddress - (ulong)Pes2021AgendaProfile.MatchRecordStride
            : 0;

        while (steps < maxSteps && cursor > 0)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var record = await memoryReader.TryReadMatchRecordAsync(attachmentId, cursor, -1, cancellationToken);
            if (record is null || !Pes2021MemoryReader.IsPlausibleMatchRecord(record) || !await HasForwardPlausibleRunAsync(attachmentId, cursor, 4, 3, cancellationToken))
            {
                break;
            }

            startBase = cursor;
            steps++;
            if (cursor < (ulong)Pes2021AgendaProfile.MatchRecordStride)
            {
                break;
            }

            cursor -= (ulong)Pes2021AgendaProfile.MatchRecordStride;
        }

        return startBase;
    }

    private async Task<bool> HasForwardPlausibleRunAsync(AttachmentId attachmentId, ulong baseAddress, int runLength, int minScore, CancellationToken cancellationToken)
    {
        var score = 0;
        for (var index = 0; index < runLength; index++)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var record = await memoryReader.TryReadMatchRecordAsync(attachmentId, baseAddress + (ulong)(index * Pes2021AgendaProfile.MatchRecordStride), index, cancellationToken);
            if (record is null || !Pes2021MemoryReader.IsPlausibleMatchRecord(record))
            {
                break;
            }

            score++;
        }

        return score >= minScore;
    }
}
