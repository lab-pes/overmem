using System;
using System.Buffers.Binary;
using System.Threading;
using System.Threading.Tasks;
using Overmem.Abstractions.Processes;
using Overmem.Application.Pes2021.Shared;

namespace Overmem.Application.Pes2021.Features.DailyCalendar;

public sealed class DumpDailyCalendarDayHandler(
    Pes2021MemoryReader memoryReader,
    Pes2021AddressResolver addressResolver,
    FindDailyCalendarBaseByDateHandler findDailyBase)
{
    public async Task<Pes2021DailyCalendarReport> HandleAsync(
        AttachmentId attachmentId,
        int year,
        int month,
        int day,
        ulong? baseAddress = null,
        CancellationToken cancellationToken = default)
    {
        var resolvedBase = await addressResolver.ResolveDailyBaseAddressAsync(
            attachmentId,
            year,
            month,
            day,
            baseAddress,
            (id, y, m, d, ct) => findDailyBase.HandleAsync(id, y, m, d, cancellationToken: ct),
            cancellationToken);

        var dayIndex = Pes2021CalendarHelpers.ComputeDailyDayIndex(year, month, day);
        var dayBase = resolvedBase + ((ulong)dayIndex * (ulong)Pes2021AgendaProfile.DailyDayStride);
        var block = await memoryReader.ReadBytesAsync(attachmentId, dayBase, Pes2021AgendaProfile.DailyDayStride, cancellationToken);
        if (block is null || block.Length < Pes2021AgendaProfile.DailyDayStride)
        {
            throw new InvalidOperationException($"The daily-calendar day block for {year:D4}-{month:D2}-{day:D2} could not be read.");
        }

        var count = BinaryPrimitives.ReadUInt32LittleEndian(block.AsSpan(Pes2021AgendaProfile.DailyCountOffset, sizeof(uint)));
        var headerEvents = Pes2021MemoryReader.ReadDailyHeaderEvents(block);
        var (items, _) = Pes2021MemoryReader.ReadDailyCalendarItemsFromBlock(block);

        return new Pes2021DailyCalendarReport(
            resolvedBase,
            dayIndex,
            year,
            month,
            day,
            count,
            "daily-backed",
            count > 0 || (items?.Count ?? 0) > 0 || headerEvents.Count > 0 ? "visible" : "hidden",
            "unknown",
            headerEvents,
            items ?? []);
    }
}
