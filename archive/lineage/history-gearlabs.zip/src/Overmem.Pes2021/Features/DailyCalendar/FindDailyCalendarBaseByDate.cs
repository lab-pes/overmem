using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Overmem.Abstractions.Memory;
using Overmem.Abstractions.Processes;
using Overmem.Application;
using Overmem.Application.Pes2021.Shared;

namespace Overmem.Application.Pes2021.Features.DailyCalendar;

public sealed class FindDailyCalendarBaseByDateHandler(
    ProcessMemoryApplicationService memoryService,
    Pes2021DailyCalendarScorer scorer,
    Pes2021AddressResolver addressResolver)
{
    public async Task<Pes2021CalendarBaseResult> HandleAsync(
        AttachmentId attachmentId,
        int year,
        int month,
        int day,
        string? moduleName = null,
        int maxResults = 256,
        CancellationToken cancellationToken = default)
    {
        maxResults = Math.Max(1, maxResults);
        var dayIndex = Pes2021CalendarHelpers.ComputeDailyDayIndex(year, month, day);
        var pattern = Pes2021CalendarHelpers.BuildDailyDatePattern(year, month, day);
        var scanResult = await memoryService.ScanPatternAsync(
            new PatternScanRequest(attachmentId, pattern, moduleName, maxResults),
            cancellationToken);

        if (scanResult.Addresses.Count == 0)
        {
            throw new InvalidOperationException($"No daily-calendar date hit was found for {year:D4}-{month:D2}-{day:D2}.");
        }

        var candidates = new List<Pes2021CalendarBaseCandidate>();
        foreach (var hitAddress in scanResult.Addresses)
        {
            cancellationToken.ThrowIfCancellationRequested();

            for (var slotIndex = 0; slotIndex < Pes2021AgendaProfile.DailyHeaderMaxEvents; slotIndex++)
            {
                var adjustment = checked((ulong)slotIndex * (ulong)Pes2021AgendaProfile.DailyHeaderEventSize);
                if (hitAddress < adjustment + ((ulong)dayIndex * (ulong)Pes2021AgendaProfile.DailyDayStride))
                {
                    continue;
                }

                var candidateBaseAddress = hitAddress
                    - ((ulong)dayIndex * (ulong)Pes2021AgendaProfile.DailyDayStride)
                    - adjustment;

                var scoreResult = await scorer.ScoreDailyCalendarBaseAsync(
                    attachmentId,
                    candidateBaseAddress,
                    null,
                    cancellationToken);

                var report = scoreResult.Report;
                candidates.Add(new Pes2021CalendarBaseCandidate(
                    hitAddress,
                    candidateBaseAddress,
                    report.Score,
                    report.Score,
                    report.MatchedCounts,
                    report.HeaderDays,
                    slotIndex,
                    report.SpecialDayOk));
            }
        }

        var best = candidates
            .OrderByDescending(candidate => candidate.Score)
            .ThenByDescending(candidate => candidate.DetailScore1)
            .ThenByDescending(candidate => candidate.DetailScore2)
            .ThenBy(candidate => candidate.CandidateBaseAddress)
            .FirstOrDefault();

        if (best is null)
        {
            throw new InvalidOperationException("No daily-calendar base candidate could be evaluated.");
        }

        var result = new Pes2021CalendarBaseResult(
            attachmentId.Value,
            Pes2021CalendarLayout.Daily,
            best.HitAddress,
            best.CandidateBaseAddress,
            best.CandidateBaseAddress,
            0,
            best.Score,
            best.ValidationScore,
            pattern,
            "Pattern",
            year,
            dayIndex,
            best.RoundValueOrSlotIndex,
            candidates
                .OrderByDescending(candidate => candidate.Score)
                .ThenByDescending(candidate => candidate.DetailScore1)
                .ThenByDescending(candidate => candidate.DetailScore2)
                .ThenBy(candidate => candidate.CandidateBaseAddress)
                .Take(32)
                .ToArray());

        addressResolver.DailyBaseCache[attachmentId] = result;
        return result;
    }
}
