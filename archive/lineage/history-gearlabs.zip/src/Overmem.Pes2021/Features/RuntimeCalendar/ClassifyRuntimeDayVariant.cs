using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Overmem.Abstractions.Processes;
using Overmem.Application;
using Overmem.Application.Pes2021.Features.DailyCalendar;
using Overmem.Application.Pes2021.Shared;

namespace Overmem.Application.Pes2021.Features.RuntimeCalendar;

public sealed class ClassifyRuntimeDayVariantHandler(
    DumpDailyCalendarDayHandler dumpDailyHandler,
    DumpRuntimeDayPayloadFamilyHandler dumpFamilyHandler)
{
    public async Task<Pes2021RuntimeCalendarVariantReport> HandleAsync(
        AttachmentId attachmentId,
        int year,
        int month,
        int day,
        ulong? startAddress = null,
        ulong? stopAddress = null,
        ulong? dailyBaseAddress = null,
        ulong? matchBaseAddress = null,
        int[]? preferredStrides = null,
        int minHitCount = 3,
        int clusterGap = 0x1000,
        int previewBytes = 0x100,
        CancellationToken cancellationToken = default)
    {
        var daily = await dumpDailyHandler.HandleAsync(
            attachmentId,
            year,
            month,
            day,
            dailyBaseAddress,
            cancellationToken);

        var family = await dumpFamilyHandler.HandleAsync(
            attachmentId,
            year,
            month,
            day,
            startAddress,
            stopAddress,
            matchBaseAddress,
            preferredStrides,
            minHitCount,
            clusterGap,
            previewBytes,
            cancellationToken);

        var currentDate = new DateOnly(year, month, day);
        var previousDate = currentDate.AddDays(-1);
        var nextDate = currentDate.AddDays(1);

        var previousFamily = await dumpFamilyHandler.HandleAsync(
            attachmentId,
            previousDate.Year,
            previousDate.Month,
            previousDate.Day,
            startAddress,
            stopAddress,
            matchBaseAddress,
            preferredStrides,
            minHitCount,
            clusterGap,
            previewBytes,
            cancellationToken);

        var nextFamily = await dumpFamilyHandler.HandleAsync(
            attachmentId,
            nextDate.Year,
            nextDate.Month,
            nextDate.Day,
            startAddress,
            stopAddress,
            matchBaseAddress,
            preferredStrides,
            minHitCount,
            clusterGap,
            previewBytes,
            cancellationToken);

        var temporalComparison = CompareRuntimeDayPayloadFamilyHandler.BuildRuntimeDayPayloadFamilyComparisonReport(
            attachmentId.Value,
            previousFamily,
            family,
            nextFamily);

        var temporalSummary = BuildTemporalComparisonSummary(temporalComparison);

        var dominantStrides = family.Clusters
            .GroupBy(static cluster => cluster.TypicalStride)
            .OrderByDescending(group => group.Count())
            .ThenBy(group => group.Key)
            .Select(group => group.Key)
            .Take(8)
            .ToArray();

        var headerTypes = daily.HeaderEvents
            .Select(item => item.Type)
            .Distinct()
            .OrderBy(static value => value)
            .ToArray();

        var hasSpecial472Family = family.Clusters.Any(static cluster => cluster.TypicalStride >= 470 && cluster.TypicalStride <= 474);
        var only528LikeClusters = family.Clusters.All(static cluster => cluster.TypicalStride >= 520 && cluster.TypicalStride <= 536);
        var reasons = new List<string>
        {
            $"daily_count={daily.Count}",
            $"daily_items={daily.Items.Count}",
            $"cluster_count={family.ClusterCount}",
            $"total_hits={family.TotalHits}",
            $"dominant_strides={string.Join(",", dominantStrides)}",
            $"temporal_prev_matches={temporalSummary.PreviousMatchedClusterCount}",
            $"temporal_next_matches={temporalSummary.NextMatchedClusterCount}",
            $"temporal_stable_clusters={temporalSummary.StableClusterCount}",
            $"temporal_isolated_clusters={temporalSummary.IsolatedClusterCount}",
        };

        string variantKey;
        string confidence;

        if (hasSpecial472Family && daily.Count == 0 && family.ClusterCount <= 5)
        {
            variantKey = "placeholder_special_runtime";
            confidence = "high";
            reasons.Add("detected_small_472_family_with_empty_daily_day");
        }
        else if (daily.Count == 0 && family.ClusterCount == 1 && only528LikeClusters)
        {
            variantKey = "no_games_runtime";
            confidence = "medium";
            reasons.Add("single_528_like_family_with_empty_daily_day");
        }
        else if (daily.Count > 0 && daily.Count <= 8 && family.ClusterCount == 1 && only528LikeClusters)
        {
            variantKey = "placeholder_organized_runtime";
            confidence = "medium";
            reasons.Add("small_daily_payload_with_single_organized_528_family");
        }
        else if (daily.Count > 8 && family.ClusterCount <= 4 && only528LikeClusters)
        {
            variantKey = "agenda_defined_organized_runtime";
            confidence = "medium";
            reasons.Add("non_empty_daily_payload_with_small_organized_528_family");
        }
        else if (daily.Count > 0 && family.ClusterCount >= 20)
        {
            variantKey = "agenda_defined_noisy_runtime";
            confidence = "medium";
            reasons.Add("non_empty_daily_payload_with_heavy_multi_cluster_runtime_noise");
        }
        else
        {
            variantKey = "unknown_runtime";
            confidence = "low";
            reasons.Add("runtime_shape_did_not_match_current_heuristics");
        }

        if (headerTypes.Contains((ushort)0x0009))
        {
            reasons.Add("daily_header_contains_0x0009_variant_marker");
        }

        var (semanticEventKey, semanticEventConfidence, semanticReasons) = Pes2021CalendarHelpers.ClassifySemanticEvent(
            year,
            month,
            day,
            headerTypes,
            daily.Count,
            family.ClusterCount,
            variantKey);

        return new Pes2021RuntimeCalendarVariantReport(
            attachmentId.Value,
            family.DayIndex,
            family.Year,
            family.Month,
            family.Day,
            variantKey,
            confidence,
            semanticEventKey,
            semanticEventConfidence,
            daily.Count,
            daily.Items.Count,
            headerTypes,
            family.TotalHits,
            family.ClusterCount,
            dominantStrides,
            hasSpecial472Family,
            temporalSummary,
            daily.Count > 0 || daily.Items.Count > 0 ? "daily-backed" : "runtime-projected",
            family.ClusterCount > 0 || daily.Count > 0 || daily.Items.Count > 0 || headerTypes.Length > 0 ? "visible" : "projected",
            semanticEventKey != "unknown_event" ? "stop" : variantKey != "unknown_runtime" ? "candidate" : "no-stop",
            semanticReasons,
            reasons);
    }

    private static Pes2021RuntimeCalendarTemporalComparisonSummary BuildTemporalComparisonSummary(
        Pes2021RuntimeCalendarFamilyComparisonReport comparison)
    {
        var previousMatchedClusterCount = comparison.Clusters.Count(static cluster => cluster.PreviousClusterStartAddress.HasValue);
        var nextMatchedClusterCount = comparison.Clusters.Count(static cluster => cluster.NextClusterStartAddress.HasValue);
        var stableClusterCount = comparison.Clusters.Count(static cluster => cluster.PreviousClusterStartAddress.HasValue && cluster.NextClusterStartAddress.HasValue);
        var isolatedClusterCount = comparison.Clusters.Count(static cluster => !cluster.PreviousClusterStartAddress.HasValue && !cluster.NextClusterStartAddress.HasValue);
        var previousPreviewOverlapMatchCount = comparison.Clusters.Count(static cluster => string.Equals(cluster.PreviousMatchStrategy, "preview-overlap", StringComparison.Ordinal));
        var nextPreviewOverlapMatchCount = comparison.Clusters.Count(static cluster => string.Equals(cluster.NextMatchStrategy, "preview-overlap", StringComparison.Ordinal));
        var previousFallbackMatchCount = comparison.Clusters.Count(static cluster => string.Equals(cluster.PreviousMatchStrategy, "stride-ordinal-fallback", StringComparison.Ordinal));
        var nextFallbackMatchCount = comparison.Clusters.Count(static cluster => string.Equals(cluster.NextMatchStrategy, "stride-ordinal-fallback", StringComparison.Ordinal));

        return new Pes2021RuntimeCalendarTemporalComparisonSummary(
            comparison.Clusters.Count,
            previousMatchedClusterCount,
            nextMatchedClusterCount,
            stableClusterCount,
            isolatedClusterCount,
            previousPreviewOverlapMatchCount,
            nextPreviewOverlapMatchCount,
            previousFallbackMatchCount,
            nextFallbackMatchCount);
    }
}
