using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Overmem.Abstractions.Processes;
using Overmem.Application;
using Overmem.Application.Pes2021.Shared;

namespace Overmem.Application.Pes2021.Features.RuntimeCalendar;

public sealed class DumpRuntimeDayPayloadClusterDetailHandler(
    DumpRuntimeDayPayloadFamilyHandler familyHandler,
    Pes2021MemoryReader memoryReader)
{
    public async Task<Pes2021RuntimeCalendarClusterDetailReport> HandleAsync(
        AttachmentId attachmentId,
        int year,
        int month,
        int day,
        int clusterOrdinal,
        ulong? startAddress = null,
        ulong? stopAddress = null,
        ulong? matchBaseAddress = null,
        int[]? preferredStrides = null,
        int minHitCount = 3,
        int clusterGap = 0x1000,
        int previewBytes = 0x100,
        int intsBeforeHit = 8,
        int intsAfterHit = 24,
        CancellationToken cancellationToken = default)
    {
        intsBeforeHit = Math.Max(0, intsBeforeHit);
        intsAfterHit = Math.Max(1, intsAfterHit);

        var family = await familyHandler.HandleAsync(
            attachmentId,
            year,
            month,
            day,
            startAddress,
            stopAddress,
            matchBaseAddress,
            preferredStrides,
            minHitCount,
            clusterGap,
            previewBytes,
            cancellationToken);

        if (clusterOrdinal < 0 || clusterOrdinal >= family.Clusters.Count)
        {
            throw new ArgumentOutOfRangeException(nameof(clusterOrdinal), $"The cluster ordinal {clusterOrdinal} is outside the available range 0..{family.Clusters.Count - 1}.");
        }

        var cluster = family.Clusters[clusterOrdinal];
        var hitWindows = new List<Pes2021RuntimeCalendarHitWindowReport>(cluster.SampleAddresses.Count);
        foreach (var hitAddress in cluster.SampleAddresses)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var bytesBefore = intsBeforeHit * sizeof(int);
            var readAddress = hitAddress >= (ulong)bytesBefore ? hitAddress - (ulong)bytesBefore : hitAddress;
            var relativeBase = hitAddress >= (ulong)bytesBefore ? -bytesBefore : 0;
            var totalBytes = (intsBeforeHit + intsAfterHit) * sizeof(int);
            var buffer = await memoryReader.ReadBytesAsync(attachmentId, readAddress, totalBytes, cancellationToken) ?? [];
            var values = new List<Pes2021RuntimeCalendarHitWindowEntry>(buffer.Length / sizeof(int));

            for (var index = 0; index <= buffer.Length - sizeof(int); index += sizeof(int))
            {
                values.Add(new Pes2021RuntimeCalendarHitWindowEntry(
                    relativeBase + index,
                    BinaryPrimitives.ReadInt32LittleEndian(buffer.AsSpan(index, sizeof(int)))));
            }

            hitWindows.Add(new Pes2021RuntimeCalendarHitWindowReport(hitAddress, values));
        }

        return new Pes2021RuntimeCalendarClusterDetailReport(
            attachmentId.Value,
            family.DayIndex,
            family.Year,
            family.Month,
            family.Day,
            clusterOrdinal,
            cluster.TypicalStride,
            cluster.ClusterStartAddress,
            cluster.ClusterEndAddress,
            cluster.RegionBaseAddress,
            cluster.RegionSize,
            cluster.SampleAddresses,
            cluster.PreviewInt32,
            cluster.PreviewRecords,
            hitWindows);
    }
}
