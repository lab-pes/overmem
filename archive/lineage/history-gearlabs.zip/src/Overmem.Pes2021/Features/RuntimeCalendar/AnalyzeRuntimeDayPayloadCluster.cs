using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Overmem.Abstractions.Processes;
using Overmem.Application;

namespace Overmem.Application.Pes2021.Features.RuntimeCalendar;

public sealed class AnalyzeRuntimeDayPayloadClusterHandler(
    DumpRuntimeDayPayloadClusterDetailHandler detailHandler)
{
    public async Task<Pes2021RuntimeCalendarClusterSignatureReport> HandleAsync(
        AttachmentId attachmentId,
        int year,
        int month,
        int day,
        int clusterOrdinal,
        ulong? startAddress = null,
        ulong? stopAddress = null,
        ulong? matchBaseAddress = null,
        int[]? preferredStrides = null,
        int minHitCount = 3,
        int clusterGap = 0x1000,
        int previewBytes = 0x100,
        int intsBeforeHit = 8,
        int intsAfterHit = 24,
        CancellationToken cancellationToken = default)
    {
        var detail = await detailHandler.HandleAsync(
            attachmentId,
            year,
            month,
            day,
            clusterOrdinal,
            startAddress,
            stopAddress,
            matchBaseAddress,
            preferredStrides,
            minHitCount,
            clusterGap,
            previewBytes,
            intsBeforeHit,
            intsAfterHit,
            cancellationToken);

        var commonAnchorPrefix = detail.HitWindows.Count == 0
            ? []
            : detail.HitWindows
                .Select(window => (IReadOnlyList<int>)window.Values.Where(entry => entry.RelativeOffset >= 0).Select(entry => entry.Value).ToArray())
                .Aggregate((left, right) => IntersectOrderedPrefix(left, right));

        var unresolvedPreviewValues = detail.PreviewRecords
            .Where(record => !record.Resolved)
            .Select(record => record.Value)
            .Distinct()
            .OrderBy(static value => value)
            .ToArray();

        var hitSignatures = detail.HitWindows
            .Select(window =>
            {
                var ordered = window.Values
                    .Where(entry => entry.RelativeOffset >= 0)
                    .OrderBy(entry => entry.RelativeOffset)
                    .Select(entry => entry.Value)
                    .ToArray();
                var anchorValues = ordered.Take(commonAnchorPrefix.Count).ToArray();
                var tailValues = ordered.Skip(anchorValues.Length).ToArray();
                return new Pes2021RuntimeCalendarHitSignature(
                    window.HitAddress,
                    anchorValues,
                    tailValues,
                    BuildSequenceRuns(tailValues));
            })
            .ToArray();

        var frequentTailValues = hitSignatures
            .SelectMany(signature => signature.TailValues.Distinct())
            .GroupBy(static value => value)
            .Select(group => new Pes2021RuntimeCalendarValueFrequency(group.Key, group.Count()))
            .OrderByDescending(item => item.Count)
            .ThenBy(item => item.Value)
            .ToArray();

        return new Pes2021RuntimeCalendarClusterSignatureReport(
            attachmentId.Value,
            detail.DayIndex,
            detail.Year,
            detail.Month,
            detail.Day,
            detail.ClusterOrdinal,
            detail.TypicalStride,
            detail.ClusterStartAddress,
            detail.ClusterEndAddress,
            commonAnchorPrefix,
            unresolvedPreviewValues,
            frequentTailValues,
            hitSignatures);
    }

    private static IReadOnlyList<int> IntersectOrderedPrefix(IReadOnlyList<int> left, IReadOnlyList<int> right)
    {
        var count = Math.Min(left.Count, right.Count);
        var values = new List<int>(count);
        for (var index = 0; index < count; index++)
        {
            if (left[index] != right[index])
            {
                break;
            }

            values.Add(left[index]);
        }

        return values;
    }

    private static IReadOnlyList<Pes2021RuntimeCalendarSequenceRun> BuildSequenceRuns(IReadOnlyList<int> values)
    {
        if (values.Count == 0)
        {
            return [];
        }

        var runs = new List<Pes2021RuntimeCalendarSequenceRun>();
        var current = new List<int> { values[0] };

        for (var index = 1; index < values.Count; index++)
        {
            var value = values[index];
            if (value == current[^1] + 1)
            {
                current.Add(value);
                continue;
            }

            runs.Add(new Pes2021RuntimeCalendarSequenceRun(current[0], current[^1], current.Count, current.ToArray()));
            current = [value];
        }

        runs.Add(new Pes2021RuntimeCalendarSequenceRun(current[0], current[^1], current.Count, current.ToArray()));
        return runs;
    }
}
