# Guia de Integração MCP - Overmem

Este documento descreve como configurar e utilizar o servidor MCP (Model Context Protocol) do **Overmem** em clientes compatíveis, utilizando o executável compilado em modo **Release**.

---

## 1. Localização do Executável (Release)

O binário compilado em modo Release está localizado em:
`D:\git\gearlabs\overmem\src\Overmem.McpServer\bin\Release\net8.0\Overmem.McpServer.exe`

---

## 2. Configuração nos Clientes MCP

Como o servidor utiliza o transporte **Stdio (Standard I/O)**, a integração é feita apontando diretamente para o executável gerado.

### A. Cursor (Configurações do Editor)
1. Abra o **Cursor**.
2. Vá em **Settings** > **Features** > **MCP**.
3. Clique em **+ Add New MCP Server**.
4. Configure com os seguintes dados:
   - **Name**: `overmem`
   - **Type**: `stdio`
   - **Command**: `D:\git\gearlabs\overmem\src\Overmem.McpServer\bin\Release\net8.0\Overmem.McpServer.exe`

### B. Claude Desktop
Adicione a configuração abaixo ao seu arquivo `claude_desktop_config.json` (geralmente localizado em `%APPDATA%\Claude\claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "overmem": {
      "command": "D:\\git\\gearlabs\\overmem\\src\\Overmem.McpServer\\bin\\Release\\net8.0\\Overmem.McpServer.exe"
    }
  }
}
```

### C. VS Code (Extensão MCP)
Se você utiliza a extensão MCP oficial no VS Code, adicione o seguinte ao seu arquivo `.vscode/mcp.json`:

```json
{
  "servers": {
    "overmem": {
      "type": "stdio",
      "command": "D:\\git\\gearlabs\\overmem\\src\\Overmem.McpServer\\bin\\Release\\net8.0\\Overmem.McpServer.exe"
    }
  }
}
```

---

## 3. Superfície de Ferramentas (Tool Surface) Exposta

Ao inicializar, o Overmem disponibiliza as seguintes ferramentas para o modelo de IA:

### Ferramentas de Processo e Memória Geral:
- `attach_process`: Conecta ao processo (ex: `PES2021.exe`).
- `detach_process`: Desconecta do processo.
- `list_regions`: Lista as regiões de memória virtuais do processo anexado.
- `read_memory`: Realiza leitura tipada de memória.
- `write_memory`: Realiza escrita tipada de memória.
- `resolve_pointer`: Resolve uma cadeia de ponteiros a partir de um endereço base.
- `pattern_scan`: Varre a memória do processo buscando padrões de bytes com suporte a curingas (`??`).
- `start_value_search` / `refine_value_search`: Inicializa e refina sessões de busca de valores na memória (estilo Cheat Engine).
- `freeze_value` / `unfreeze_value`: Congela/descongela endereços específicos com valores definidos.

### Ferramentas Específicas do PES 2021:
- `pes2021_agenda_guide`: Retorna as referências, offsets e prioridades recomendadas do PES 2021.
- `pes2021_find_calendar_base`: Encontra e valida o endereço base do calendário do Master League.
- `pes2021_calendar_summary`: Resume a agenda do PES 2021 por datas e competições.
- `pes2021_dump_daily_calendar_day`: Descarrega os eventos e itens de um dia específico do calendário secundário/diário.
- `pes2021_find_daily_calendar_base_by_date`: Encontra a base do calendário diário varrendo datas visíveis nos cabeçalhos.
- `pes2021_classify_runtime_day_variant`: Classifica o comportamento/tipo de parada de um dia a nível de tempo de execução.
- `pes2021_inventory_annual_events`: Gera um inventário anual com todos os eventos e dias especiais do calendário.

---

## 4. Fluxo de Trabalho Recomendado via MCP

1. **Anexar ao Processo**: Chame `attach_process` passando o nome do executável `PES2021` (ou o PID).
2. **Localizar Calendário**: Chame `pes2021_find_calendar_base` para mapear o endereço base ativo do Master League na memória.
3. **Explorar a Agenda**: Use `pes2021_inventory_annual_events` para obter o panorama anual de eventos e depois `pes2021_classify_runtime_day_variant` nos dias específicos sob investigação.
