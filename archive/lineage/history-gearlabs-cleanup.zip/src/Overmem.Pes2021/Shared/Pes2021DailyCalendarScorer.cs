using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Overmem.Abstractions.Processes;
using Overmem.Application.Pes2021.Shared;

namespace Overmem.Application.Pes2021.Shared;

public sealed class Pes2021DailyCalendarScorer(Pes2021MemoryReader memoryReader)
{
    public async Task<Pes2021dailyScoreResult> ScoreDailyCalendarBaseAsync(
        AttachmentId attachmentId,
        ulong baseAddress,
        IReadOnlyList<int>? sampleDays,
        CancellationToken cancellationToken)
    {
        var days = sampleDays is { Count: > 0 }
            ? sampleDays
            : Pes2021AgendaProfile.DailySampleDays;

        var details = new Pes2021dailyScoreBuilder(baseAddress, days);
        var score = 0;

        foreach (var dayIndex in days)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var dayBase = baseAddress + ((ulong)dayIndex * (ulong)Pes2021AgendaProfile.DailyDayStride);
            var block = await memoryReader.ReadBytesAsync(attachmentId, dayBase, Pes2021AgendaProfile.DailyDayStride, cancellationToken);
            var summary = new Pes2021DailyDaySummary(dayIndex, null, null, false, "n/a");

            if (block is null || block.Length < Pes2021AgendaProfile.DailyDayStride)
            {
                details.Issues.Add($"day[{dayIndex}] unreadable");
                details.DaySummaries.Add(summary);
                continue;
            }

            var count = BinaryPrimitives.ReadUInt32LittleEndian(block.AsSpan(Pes2021AgendaProfile.DailyCountOffset, sizeof(uint)));
            summary = summary with { Count = count };

            if (dayIndex == Pes2021AgendaProfile.DailyDayCount - 1)
            {
                if (count == 0xFFFFFFFF)
                {
                    details.SpecialDayOk = true;
                    score += 4;
                }
                else
                {
                    details.Issues.Add($"day[{dayIndex}] expected 0xFFFFFFFF, got 0x{count:X}");
                }

                details.DaySummaries.Add(summary);
                continue;
            }

            if (count <= (uint)Pes2021MemoryReader.DailyMaxItems)
            {
                details.PlausibleCounts++;
                score++;
            }
            else
            {
                details.Issues.Add($"day[{dayIndex}] count=0x{count:X} above max={Pes2021MemoryReader.DailyMaxItems}");
            }

            var (items, terminatorFound) = Pes2021MemoryReader.ReadDailyCalendarItemsFromBlock(block);
            summary = summary with
            {
                ItemCount = items?.Count,
                TerminatorFound = terminatorFound,
            };

            if (items is not null)
            {
                if (terminatorFound)
                {
                    details.TerminatorDays++;
                    score++;
                }
                else
                {
                    details.Issues.Add($"day[{dayIndex}] missing 0xFFFF terminator");
                }

                if (count == (uint)items.Count)
                {
                    details.MatchedCounts++;
                    score += 2;
                }
                else
                {
                    details.Issues.Add($"day[{dayIndex}] count=0x{count:X} differs from items={items.Count}");
                }
            }
            else
            {
                details.Issues.Add($"day[{dayIndex}] unreadable items");
            }

            var headerState = Pes2021MemoryReader.EvaluateDailyCalendarHeader(block);
            summary = summary with { HeaderState = headerState.State };
            if (headerState.Ok)
            {
                details.HeaderDays++;
                score++;
            }
            else
            {
                details.Issues.Add($"day[{dayIndex}] header={headerState.State}");
            }

            details.DaySummaries.Add(summary);
        }

        var report = new Pes2021DailyCalendarCandidateReport(
            baseAddress,
            score,
            details.PlausibleCounts,
            details.MatchedCounts,
            details.TerminatorDays,
            details.HeaderDays,
            details.SpecialDayOk,
            details.DaySummaries.ToArray(),
            details.Issues.ToArray());

        return new Pes2021dailyScoreResult(score, report);
    }

    public static int CompareDailyReports(Pes2021DailyCalendarCandidateReport left, Pes2021DailyCalendarCandidateReport right)
    {
        if (left.Score != right.Score)
        {
            return right.Score.CompareTo(left.Score);
        }

        return left.BaseAddress.CompareTo(right.BaseAddress);
    }
}

public sealed record Pes2021dailyScoreResult(int Score, Pes2021DailyCalendarCandidateReport Report);

public sealed class Pes2021dailyScoreBuilder(ulong baseAddress, IReadOnlyList<int> sampleDays)
{
    public ulong BaseAddress { get; } = baseAddress;
    public IReadOnlyList<int> SampleDays { get; } = sampleDays;
    public int PlausibleCounts { get; set; }
    public int MatchedCounts { get; set; }
    public int TerminatorDays { get; set; }
    public int HeaderDays { get; set; }
    public bool SpecialDayOk { get; set; }
    public List<Pes2021DailyDaySummary> DaySummaries { get; } = [];
    public List<string> Issues { get; } = [];
}
