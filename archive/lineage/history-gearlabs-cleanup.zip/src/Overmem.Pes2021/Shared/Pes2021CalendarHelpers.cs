using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace Overmem.Application.Pes2021.Shared;

internal static class Pes2021CalendarHelpers
{
    public const int MaxPlausibleCompetitionCode = 0x3FFF;

    private static readonly Lazy<IReadOnlyDictionary<int, string>> CompetitionMap = new(
        () => Pes2021AgendaProfile.LoadCompetitionMap());

    public static string GetCompetitionName(int competitionCode)
    {
        var map = CompetitionMap.Value;
        return map.TryGetValue(competitionCode, out var name) ? name : "DESCONHECIDA";
    }

    public static string ResolveComparisonCompetitionName(
        Pes2021CompetitionDateSummary? first,
        Pes2021CompetitionDateSummary? second)
    {
        if (first is not null && !string.Equals(first.CompetitionName, "DESCONHECIDA", StringComparison.OrdinalIgnoreCase))
        {
            return first.CompetitionName;
        }

        if (second is not null && !string.Equals(second.CompetitionName, "DESCONHECIDA", StringComparison.OrdinalIgnoreCase))
        {
            return second.CompetitionName;
        }

        return first?.CompetitionName
            ?? second?.CompetitionName
            ?? "DESCONHECIDA";
    }

    public static string BuildMatchDatePattern(int year, int month, int day, int roundValue, int competitionCode)
        => string.Format(
            CultureInfo.InvariantCulture,
            "{0:X2} {1:X2} {2:X2} ?? {3:X2} {4:X2} {5:X2} {6:X2}",
            competitionCode & 0xFF,
            (competitionCode >> 8) & 0xFF,
            roundValue & 0xFF,
            year & 0xFF,
            (year >> 8) & 0xFF,
            month & 0xFF,
            day & 0xFF);

    public static string BuildMatchDateOnlyPattern(int year, int month, int day)
        => string.Format(
            CultureInfo.InvariantCulture,
            "?? ?? ?? ?? {0:X2} {1:X2} {2:X2} {3:X2}",
            year & 0xFF,
            (year >> 8) & 0xFF,
            month & 0xFF,
            day & 0xFF);

    public static string BuildDailyDatePattern(int year, int month, int day)
        => string.Format(
            CultureInfo.InvariantCulture,
            "{0:X2} {1:X2} {2:X2} {3:X2}",
            year & 0xFF,
            (year >> 8) & 0xFF,
            month & 0xFF,
            day & 0xFF);

    public static string BuildInt32Pattern(int value)
    {
        var bytes = BitConverter.GetBytes(value);
        return string.Format(
            CultureInfo.InvariantCulture,
            "{0:X2} {1:X2} {2:X2} {3:X2}",
            bytes[0],
            bytes[1],
            bytes[2],
            bytes[3]);
    }

    public static string FormatDateKey(int year, int month, int day)
        => string.Format(CultureInfo.InvariantCulture, "{0:D4}{1:D2}{2:D2}", year, month, day);

    public static int ComputeDailyDayIndex(int year, int month, int day)
    {
        var matchDate = new DateOnly(year, month, day);
        var seasonStart = new DateOnly(year, 1, 1);
        var dayIndex = matchDate.DayNumber - seasonStart.DayNumber;
        if (dayIndex < 0 || dayIndex >= Pes2021AgendaProfile.DailyDayCount)
        {
            throw new ArgumentOutOfRangeException(nameof(day), $"The date {year:D4}-{month:D2}-{day:D2} falls outside the supported daily-calendar range.");
        }

        return dayIndex;
    }

    public static string FormatRounds(HashSet<int> rounds)
    {
        if (rounds.Count == 0)
        {
            return "-";
        }

        var ordered = rounds.OrderBy(value => value).ToArray();
        if (ordered.Length == 1)
        {
            return ordered[0].ToString(CultureInfo.InvariantCulture);
        }

        return string.Format(CultureInfo.InvariantCulture, "{0}-{1}", ordered[0], ordered[^1]);
    }

    public static CompetitionBuilder GetOrCreateBuilder(
        Dictionary<int, CompetitionBuilder> competitionCounts,
        int competitionCode,
        string competitionName)
    {
        if (competitionCounts.TryGetValue(competitionCode, out var builder))
        {
            return builder;
        }

        builder = new CompetitionBuilder(competitionCode, competitionName);
        competitionCounts[competitionCode] = builder;
        return builder;
    }

    public static SummaryBuilder GetOrCreateSummaryBuilder(
        Dictionary<string, SummaryBuilder> summaries,
        string dateKey,
        int year,
        int month,
        int day)
    {
        if (summaries.TryGetValue(dateKey, out var builder))
        {
            return builder;
        }

        builder = new SummaryBuilder(string.Format(CultureInfo.InvariantCulture, "{0:D4}-{1:D2}-{2:D2}", year, month, day));
        summaries[dateKey] = builder;
        return builder;
    }

    public static string BuildEventId(
        int index,
        int competitionCode,
        int year,
        int month,
        int day,
        int roundValue,
        int homeId,
        int awayId,
        int homeLiga)
    {
        return string.Format(
            CultureInfo.InvariantCulture,
            "{0}|{1}|{2:D4}{3:D2}{4:D2}|{5}|{6}|{7}|{8}",
            index,
            competitionCode,
            year,
            month,
            day,
            roundValue,
            homeId,
            awayId,
            homeLiga);
    }

    public static (string SemanticEventKey, string SemanticEventConfidence, IReadOnlyList<string> Reasons) ClassifySemanticEvent(
        int year,
        int month,
        int day,
        IReadOnlyList<ushort> headerTypes,
        uint dailyCount,
        int clusterCount,
        string variantKey)
    {
        var reasons = new List<string>();
        var headerKey = string.Join(",", headerTypes.Select(static value => $"0x{value:X4}"));
        var headerSet = headerTypes.ToHashSet();

        if (IsKnownCallupDate(year, month, day))
        {
            reasons.Add("matched_confirmed_national_team_callup_date");
            reasons.Add($"variant={variantKey}");
            return ("national_team_callup", "high", reasons);
        }

        if (year == 2026 && month == 1 && day == 1)
        {
            reasons.Add("matched_confirmed_transfer_window_start_date");
            reasons.Add($"header_types={headerKey}");
            return ("transfer_window_start", "high", reasons);
        }

        if (year == 2026 && month == 7 && day == 1)
        {
            reasons.Add("matched_confirmed_transfer_window_start_date");
            reasons.Add($"header_types={headerKey}");
            return ("transfer_window_start", "high", reasons);
        }

        if (year == 2026 && month == 1 && day == 31)
        {
            reasons.Add("matched_confirmed_transfer_window_end_date");
            reasons.Add($"header_types={headerKey}");
            return ("transfer_window_end", "high", reasons);
        }

        if (year == 2026 && month == 8 && day == 31)
        {
            reasons.Add("matched_confirmed_transfer_window_end_date");
            reasons.Add($"header_types={headerKey}");
            return ("transfer_window_end", "high", reasons);
        }

        if (year == 2026 && month == 6 && day == 30)
        {
            reasons.Add("matched_confirmed_coach_offer_response_deadline");
            reasons.Add($"header_types={headerKey}");
            return ("coach_offer_response_deadline", "high", reasons);
        }

        if (year == 2026 && month == 12 && day == 29)
        {
            reasons.Add("matched_confirmed_asian_best_player_award_announcement");
            reasons.Add($"header_types={headerKey}");
            return ("asian_best_player_award_announcement", "high", reasons);
        }

        if (year == 2026 && month == 12 && day == 30)
        {
            reasons.Add("matched_confirmed_south_america_best_player_award_announcement");
            reasons.Add($"header_types={headerKey}");
            return ("south_america_best_player_award_announcement", "high", reasons);
        }

        if (year == 2026 && month == 12 && day == 31)
        {
            reasons.Add("matched_confirmed_last_day_of_season");
            reasons.Add($"header_types={headerKey}");
            return ("last_day_of_season", "high", reasons);
        }

        if (year == 2026 && month == 6 && day == 13)
        {
            reasons.Add("matched_confirmed_libertadores_round_of_16_first_leg_placeholder");
            reasons.Add($"header_types={headerKey}");
            return ("libertadores_round_of_16_first_leg_placeholder", "high", reasons);
        }

        if (year == 2026 && month == 3 && day == 19)
        {
            reasons.Add("matched_confirmed_libertadores_group_stage_matchday_2_followup");
            reasons.Add($"header_types={headerKey}");
            return ("libertadores_group_stage_matchday_2_followup", "high", reasons);
        }

        if (year == 2026 && month == 4 && day == 16)
        {
            reasons.Add("matched_confirmed_libertadores_group_stage_matchday_4_followup");
            reasons.Add($"header_types={headerKey}");
            return ("libertadores_group_stage_matchday_4_followup", "high", reasons);
        }

        if (year == 2026 && month == 6 && day == 26)
        {
            reasons.Add("matched_confirmed_club_ranking_update");
            reasons.Add($"header_types={headerKey}");
            return ("club_ranking_update", "high", reasons);
        }

        if (year == 2026 && month == 8 && day == 26)
        {
            reasons.Add("matched_confirmed_europe_best_player_award_prelude");
            reasons.Add($"header_types={headerKey}");
            return ("europe_best_player_award_prelude", "high", reasons);
        }

        if (year == 2026 && month == 8 && day == 27)
        {
            reasons.Add("matched_confirmed_europe_best_player_award_announcement");
            reasons.Add($"header_types={headerKey}");
            return ("europe_best_player_award_announcement", "high", reasons);
        }

        if (year == 2026 && month == 12 && day == 10)
        {
            reasons.Add("matched_confirmed_hidden_competition_projection_source_marker");
            reasons.Add($"header_types={headerKey}");
            return ("hidden_competition_projection_source_marker", "high", reasons);
        }

        if (year == 2026 && month == 12 && day == 12)
        {
            reasons.Add("matched_confirmed_hidden_competition_projection_source_marker");
            reasons.Add($"header_types={headerKey}");
            return ("hidden_competition_projection_source_marker", "high", reasons);
        }

        if (year == 2026 && month == 12 && day == 2)
        {
            reasons.Add("matched_confirmed_world_best_player_award_announcement");
            reasons.Add($"header_types={headerKey}");
            return ("world_best_player_award_announcement", "high", reasons);
        }

        if (HasHeaderSignature(headerSet, 0x0025, 0x003F))
        {
            reasons.Add("matched_libertadores_group_stage_matchday_2_followup_header_signature");
            reasons.Add($"variant={variantKey}");
            return ("libertadores_group_stage_matchday_2_followup_candidate", "medium", reasons);
        }

        if (HasHeaderSignature(headerSet, 0x0027, 0x003F))
        {
            reasons.Add("matched_libertadores_group_stage_matchday_4_followup_header_signature");
            reasons.Add($"variant={variantKey}");
            return ("libertadores_group_stage_matchday_4_followup_candidate", "medium", reasons);
        }

        if (HasHeaderSignature(headerSet, 0x0001, 0x0009, 0x003C, 0x003E) || HasHeaderSignature(headerSet, 0x0009, 0x003B))
        {
            reasons.Add("matched_transfer_window_start_header_signature");
            reasons.Add($"cluster_count={clusterCount}");
            return ("transfer_window_start_candidate", "medium", reasons);
        }

        if (HasHeaderSignature(headerSet, 0x0009, 0x000B) || HasHeaderSignature(headerSet, 0x0009, 0x000A))
        {
            reasons.Add("matched_transfer_window_end_header_signature");
            reasons.Add($"daily_count={dailyCount}");
            return ("transfer_window_end_candidate", "medium", reasons);
        }

        if (HasHeaderSignature(headerSet, 0x0004) || HasHeaderSignature(headerSet, 0x0007))
        {
            reasons.Add("matched_transfer_window_boundary_prelude_signature");
            return ("transfer_window_boundary_prelude_candidate", "medium", reasons);
        }

        if (HasHeaderSignature(headerSet, 0x000F, 0x0010, 0x0018))
        {
            reasons.Add("matched_midyear_admin_boundary_signature");
            return ("midyear_admin_boundary_candidate", "medium", reasons);
        }

        if (HasHeaderSignature(headerSet, 0x0020, 0x002C)
            || (HasHeaderSignature(headerSet, 0x000D) && !HasHeaderSignature(headerSet, 0x003F))
            || HasHeaderSignature(headerSet, 0x000E, 0x0011, 0x001A))
        {
            reasons.Add("matched_season_rollover_boundary_signature");
            return ("season_rollover_boundary_candidate", "medium", reasons);
        }

        return ("unknown_event", "low", []);
    }

    public static bool IsKnownCallupDate(int year, int month, int day)
        => year == 2026
            && ((month, day) == (3, 16)
                || (month, day) == (5, 26)
                || (month, day) == (6, 23)
                || (month, day) == (8, 21)
                || (month, day) == (9, 22)
                || (month, day) == (10, 30));

    public static bool HasHeaderSignature(HashSet<ushort> headerSet, params ushort[] requiredTypes)
        => requiredTypes.All(headerSet.Contains);

    public static (string InventoryPatternKey, string InventoryPatternConfidence, IReadOnlyList<string> Reasons) ClassifyInventoryPattern(
        IReadOnlyList<ushort> headerTypes,
        uint dailyCount,
        int dailyItemCount,
        int mainMatchCount,
        int previousDayMainMatchCount,
        int nextDayMainMatchCount,
        string semanticEventKey)
    {
        if (semanticEventKey != "unknown_event")
        {
            return ("known_semantic_event", "high", [$"semantic={semanticEventKey}"]);
        }

        var reasons = new List<string>
        {
            $"main={mainMatchCount}",
            $"prev={previousDayMainMatchCount}",
            $"next={nextDayMainMatchCount}",
            $"daily_count={dailyCount}",
            $"daily_items={dailyItemCount}",
            $"headers={string.Join(",", headerTypes.Select(static value => $"0x{value:X4}"))}",
        };

        if (headerTypes.Count == 0 && dailyCount > 0 && dailyItemCount > 0 && nextDayMainMatchCount > 0)
        {
            reasons.Add("daily_payload_points_to_next_day_schedule_without_header_markers");
            return ("next_day_schedule_bridge_candidate", "medium", reasons);
        }

        if (headerTypes.Count == 0 && dailyCount > 0 && dailyItemCount > 0 && nextDayMainMatchCount == 0 && previousDayMainMatchCount == 0)
        {
            reasons.Add("standalone_daily_payload_without_neighbor_matches");
            return ("standalone_daily_payload_candidate", "medium", reasons);
        }

        if (headerTypes.Count == 0 && dailyCount > 0 && dailyItemCount > 0 && previousDayMainMatchCount > 0 && nextDayMainMatchCount == 0)
        {
            reasons.Add("daily_payload_after_previous_day_match_block");
            return ("post_match_followup_payload_candidate", "medium", reasons);
        }

        if (headerTypes.Count > 0 && headerTypes.All(static value => value == 0x003F) && dailyCount > 0 && nextDayMainMatchCount > 0)
        {
            reasons.Add("0x003F_only_header_with_next_day_schedule_bridge");
            return ("placeholder_bridge_candidate", "medium", reasons);
        }

        if (headerTypes.Any(static value => value == 0x000D)
            && headerTypes.Any(static value => value == 0x003F)
            && dailyCount == 0
            && dailyItemCount == 0)
        {
            reasons.Add("0x000D_plus_0x003F_signature_is_shared_between_midyear_and_year_end_markers");
            return ("ambiguous_0x000D_0x003F_marker_candidate", "medium", reasons);
        }

        if (headerTypes.Count > 0 && headerTypes.Any(static value => value != 0x003F))
        {
            reasons.Add("rare_non_003F_header_marker_present");
            return ("rare_header_marker_candidate", "medium", reasons);
        }

        if (headerTypes.Count > 0 && headerTypes.All(static value => value == 0x003F) && dailyCount == 0 && dailyItemCount == 0)
        {
            reasons.Add("pure_0x003F_marker_without_local_payload");
            return ("pure_placeholder_marker_candidate", "medium", reasons);
        }

        return ("unknown_inventory_pattern", "low", reasons);
    }

    public static (string SourceRole, string Visibility, string StopState) BuildInventoryDisposition(
        int mainMatchCount,
        uint dailyCount,
        int dailyItemCount,
        int headerCount,
        string semanticEventKey,
        string inventoryPatternKey)
    {
        var sourceRole = dailyCount > 0 || dailyItemCount > 0 || headerCount > 0
            ? "daily-backed"
            : mainMatchCount > 0
                ? "match-backed"
                : "runtime-projected";

        var visibility = mainMatchCount > 0
            || dailyCount > 0
            || dailyItemCount > 0
            || headerCount > 0
            || semanticEventKey != "unknown_event"
            ? "visible"
            : "projected";

        var stopState = semanticEventKey != "unknown_event"
            ? "stop"
            : mainMatchCount > 0
                ? "no-stop"
                : inventoryPatternKey != "unknown_inventory_pattern"
                    ? "candidate"
                    : "no-stop";

        return (sourceRole, visibility, stopState);
    }

    public static string BuildInventoryDayRole(
        int mainMatchCount,
        string semanticEventKey,
        string inventoryPatternKey)
    {
        if (mainMatchCount > 0 && semanticEventKey != "unknown_event")
        {
            return "mixed-match-and-semantic-day";
        }

        if (mainMatchCount > 0)
        {
            return "calendar-match-day";
        }

        if (semanticEventKey != "unknown_event")
        {
            return "semantic-event-day";
        }

        if (inventoryPatternKey != "unknown_inventory_pattern")
        {
            return "calendar-marker-day";
        }

        return "unclassified-day";
    }
}

internal sealed record CompetitionBuilder(int CompetitionCode, string CompetitionName)
{
    public int MatchCount { get; set; }
    public HashSet<int> Rounds { get; } = new();
}

internal sealed record SummaryBuilder(string Date)
{
    public int MatchCount { get; set; }
    public HashSet<int> Competitions { get; } = new();
}
