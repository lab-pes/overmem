using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;
using Overmem.Abstractions.Processes;

namespace Overmem.Application.Pes2021.Shared;

public sealed class Pes2021AddressResolver
{
    public ConcurrentDictionary<AttachmentId, Pes2021CalendarBaseResult> BaseCache { get; } = new();
    public ConcurrentDictionary<AttachmentId, Pes2021CalendarBaseResult> DailyBaseCache { get; } = new();

    public async Task<ulong> ResolveMatchBaseAddressAsync(
        AttachmentId attachmentId,
        ulong? baseAddress,
        Func<AttachmentId, CancellationToken, Task<Pes2021CalendarBaseResult>> findBaseFallback,
        CancellationToken cancellationToken)
    {
        if (baseAddress is > 0)
        {
            return baseAddress.Value;
        }

        if (BaseCache.TryGetValue(attachmentId, out var cached))
        {
            return cached.NormalizedBaseAddress;
        }

        var result = await findBaseFallback(attachmentId, cancellationToken);
        return result.NormalizedBaseAddress;
    }

    public async Task<ulong> ResolveDailyBaseAddressAsync(
        AttachmentId attachmentId,
        int year,
        int month,
        int day,
        ulong? baseAddress,
        Func<AttachmentId, int, int, int, CancellationToken, Task<Pes2021CalendarBaseResult>> findDailyBaseFallback,
        CancellationToken cancellationToken)
    {
        if (baseAddress is > 0)
        {
            return baseAddress.Value;
        }

        var dayIndex = Pes2021CalendarHelpers.ComputeDailyDayIndex(year, month, day);
        if (DailyBaseCache.TryGetValue(attachmentId, out var cached)
            && cached.AnchorYear == year
            && cached.CompetitionCodeOrDayIndex == dayIndex)
        {
            return cached.NormalizedBaseAddress;
        }

        var result = await findDailyBaseFallback(attachmentId, year, month, day, cancellationToken);
        return result.NormalizedBaseAddress;
    }
}
