using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Overmem.Abstractions.Processes;
using Overmem.Application.Pes2021.Shared;

namespace Overmem.Application.Pes2021.Features.MatchCalendar;

public sealed class DumpMatchCalendarDateHandler(
    Pes2021MemoryReader memoryReader,
    Pes2021AddressResolver addressResolver,
    FindMatchCalendarBaseHandler findMatchBase)
{
    public async Task<Pes2021MatchCalendarReport> HandleAsync(
        AttachmentId attachmentId,
        int year,
        int month,
        int day,
        ulong? baseAddress = null,
        int maxRecs = 13014,
        CancellationToken cancellationToken = default)
    {
        var resolvedBase = await addressResolver.ResolveMatchBaseAddressAsync(
            attachmentId,
            baseAddress,
            (id, ct) => findMatchBase.HandleAsync(id, cancellationToken: ct),
            cancellationToken);

        var targetKey = Pes2021CalendarHelpers.FormatDateKey(year, month, day);
        var matches = new List<Pes2021CalendarRecordSnapshot>();
        var competitionCounts = new Dictionary<int, CompetitionBuilder>();

        for (var index = 0; index < maxRecs; index++)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var record = await memoryReader.TryReadMatchRecordAsync(
                attachmentId,
                resolvedBase + (ulong)(index * Pes2021AgendaProfile.MatchRecordStride),
                index,
                cancellationToken);

            if (record is null || !Pes2021MemoryReader.IsPlausibleMatchRecord(record))
            {
                continue;
            }

            if (Pes2021CalendarHelpers.FormatDateKey(record.Year, record.Month, record.Day) != targetKey)
            {
                continue;
            }

            matches.Add(record);
            var builder = Pes2021CalendarHelpers.GetOrCreateBuilder(competitionCounts, record.CompetitionCode, record.CompetitionName);
            builder.MatchCount++;
            builder.Rounds.Add(record.Round);
        }

        var competitions = competitionCounts.Values
            .Select(builder => new Pes2021CompetitionDateSummary(
                builder.CompetitionCode,
                builder.CompetitionName,
                builder.MatchCount,
                Pes2021CalendarHelpers.FormatRounds(builder.Rounds)))
            .OrderBy(item => item.CompetitionCode)
            .ToArray();

        var orderedMatches = matches
            .OrderBy(match => match.CompetitionCode)
            .ThenBy(match => match.Round)
            .ThenBy(match => match.Index)
            .ToArray();

        return new Pes2021MatchCalendarReport(
            resolvedBase,
            year,
            month,
            day,
            competitions.Length,
            orderedMatches.Length,
            "match-backed",
            "visible",
            "unknown",
            competitions,
            orderedMatches);
    }
}
