using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Overmem.Abstractions.Processes;
using Overmem.Application;
using Overmem.Application.Pes2021.Shared;

namespace Overmem.Application.Pes2021.Features.RuntimeCalendar;

public sealed class ScanRuntimeDayIndexClustersHandler(
    ProcessMemoryApplicationService memoryService,
    Pes2021MemoryReader memoryReader)
{
    public async Task<Pes2021RuntimeCalendarScanReport> HandleAsync(
        AttachmentId attachmentId,
        int year,
        int month,
        int day,
        int maxResults = 5000,
        int clusterGap = 0x1000,
        int previewBytes = 0x100,
        CancellationToken cancellationToken = default)
    {
        maxResults = Math.Max(1, maxResults);
        clusterGap = Math.Max(1, clusterGap);
        previewBytes = Math.Clamp(previewBytes, 16, 0x800);

        var dayIndex = Pes2021CalendarHelpers.ComputeDailyDayIndex(year, month, day);
        var regions = await memoryService.ListRegionsAsync(attachmentId, cancellationToken);
        var scanRegions = regions
            .Where(static region => region.IsReadable && region.RegionSize >= sizeof(int))
            .OrderBy(static region => region.BaseAddress)
            .ToArray();

        var hits = new List<ulong>();
        foreach (var region in scanRegions)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var remainingHits = maxResults - hits.Count;
            if (remainingHits <= 0)
            {
                break;
            }

            var regionHits = await memoryReader.ScanInt32InRegionAsync(attachmentId, region, dayIndex, null, null, cancellationToken);
            if (regionHits.Count == 0)
            {
                continue;
            }

            hits.AddRange(regionHits.Take(remainingHits));
        }

        hits.Sort();
        var clusters = Pes2021MemoryReader.BuildRuntimeClusters(hits, regions, clusterGap);
        var reports = new List<Pes2021RuntimeCalendarClusterReport>(clusters.Count);

        foreach (var cluster in clusters)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var previewBytesBuffer = await memoryReader.ReadClusterPreviewBytesAsync(
                attachmentId,
                cluster.StartAddress,
                cluster.Region.BaseAddress,
                cluster.Region.RegionSize,
                previewBytes,
                cancellationToken);

            reports.Add(new Pes2021RuntimeCalendarClusterReport(
                cluster.StartAddress,
                cluster.EndAddress,
                cluster.Region.BaseAddress,
                cluster.Region.RegionSize,
                cluster.Region.Type,
                cluster.Region.Protection,
                cluster.Region.IsWritable,
                cluster.Region.IsExecutable,
                cluster.Addresses.Count,
                cluster.TypicalStride,
                cluster.Addresses.Take(16).ToArray(),
                Pes2021MemoryReader.DecodeInt32Preview(previewBytesBuffer)));
        }

        var orderedReports = reports
            .OrderByDescending(report => report.HitCount)
            .ThenByDescending(report => report.RegionIsWritable && !report.RegionIsExecutable && string.Equals(report.RegionType, "Private", StringComparison.OrdinalIgnoreCase))
            .ThenBy(report => report.ClusterStartAddress)
            .ToArray();

        return new Pes2021RuntimeCalendarScanReport(
            attachmentId.Value,
            dayIndex,
            year,
            month,
            day,
            Pes2021CalendarHelpers.BuildInt32Pattern(dayIndex),
            hits.Count,
            orderedReports.Length,
            orderedReports);
    }
}
