using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Overmem.Abstractions.Processes;
using Overmem.Application;

namespace Overmem.Application.Pes2021.Features.RuntimeCalendar;

public sealed class CompareRuntimeDayPayloadFamilyHandler(
    DumpRuntimeDayPayloadFamilyHandler dumpFamilyHandler)
{
    public async Task<Pes2021RuntimeCalendarFamilyComparisonReport> HandleAsync(
        AttachmentId attachmentId,
        int year,
        int month,
        int day,
        ulong? startAddress = null,
        ulong? stopAddress = null,
        ulong? matchBaseAddress = null,
        int[]? preferredStrides = null,
        int minHitCount = 3,
        int clusterGap = 0x1000,
        int previewBytes = 0x100,
        CancellationToken cancellationToken = default)
    {
        var currentDate = new DateOnly(year, month, day);
        var previousDate = currentDate.AddDays(-1);
        var nextDate = currentDate.AddDays(1);

        var previous = await dumpFamilyHandler.HandleAsync(
            attachmentId,
            previousDate.Year,
            previousDate.Month,
            previousDate.Day,
            startAddress,
            stopAddress,
            matchBaseAddress,
            preferredStrides,
            minHitCount,
            clusterGap,
            previewBytes,
            cancellationToken);

        var current = await dumpFamilyHandler.HandleAsync(
            attachmentId,
            currentDate.Year,
            currentDate.Month,
            currentDate.Day,
            startAddress,
            stopAddress,
            matchBaseAddress,
            preferredStrides,
            minHitCount,
            clusterGap,
            previewBytes,
            cancellationToken);

        var next = await dumpFamilyHandler.HandleAsync(
            attachmentId,
            nextDate.Year,
            nextDate.Month,
            nextDate.Day,
            startAddress,
            stopAddress,
            matchBaseAddress,
            preferredStrides,
            minHitCount,
            clusterGap,
            previewBytes,
            cancellationToken);

        return BuildRuntimeDayPayloadFamilyComparisonReport(attachmentId.Value, previous, current, next);
    }

    internal static Pes2021RuntimeCalendarFamilyComparisonReport BuildRuntimeDayPayloadFamilyComparisonReport(
        Guid attachmentId,
        Pes2021RuntimeCalendarFamilyReport previous,
        Pes2021RuntimeCalendarFamilyReport current,
        Pes2021RuntimeCalendarFamilyReport next)
    {
        var previousMatches = MatchClustersByPreviewSimilarity(current.Clusters, previous.Clusters);
        var nextMatches = MatchClustersByPreviewSimilarity(current.Clusters, next.Clusters);
        var diffs = new List<Pes2021RuntimeCalendarFamilyClusterDiffReport>(current.Clusters.Count);

        for (var clusterOrdinal = 0; clusterOrdinal < current.Clusters.Count; clusterOrdinal++)
        {
            var currentCluster = current.Clusters[clusterOrdinal];
            previousMatches.TryGetValue(clusterOrdinal, out var previousMatch);
            nextMatches.TryGetValue(clusterOrdinal, out var nextMatch);
            var previousCluster = previousMatch?.Cluster;
            var nextCluster = nextMatch?.Cluster;

            diffs.Add(new Pes2021RuntimeCalendarFamilyClusterDiffReport(
                clusterOrdinal,
                currentCluster.TypicalStride,
                previousCluster?.ClusterStartAddress,
                currentCluster.ClusterStartAddress,
                nextCluster?.ClusterStartAddress,
                previousCluster?.PreviewInt32 ?? [],
                currentCluster.PreviewInt32,
                nextCluster?.PreviewInt32 ?? [],
                BuildValueDiff(currentCluster.PreviewRecords, previousCluster?.PreviewInt32),
                BuildValueDiff(previousCluster?.PreviewRecords ?? [], currentCluster.PreviewInt32),
                BuildValueDiff(currentCluster.PreviewRecords, nextCluster?.PreviewInt32),
                BuildValueDiff(nextCluster?.PreviewRecords ?? [], currentCluster.PreviewInt32),
                previousMatch?.Strategy ?? "unmatched",
                previousMatch?.SharedPreviewValueCount ?? 0,
                nextMatch?.Strategy ?? "unmatched",
                nextMatch?.SharedPreviewValueCount ?? 0));
        }

        return new Pes2021RuntimeCalendarFamilyComparisonReport(
            attachmentId,
            new Pes2021RuntimeCalendarDayMarker(previous.DayIndex, previous.Year, previous.Month, previous.Day),
            new Pes2021RuntimeCalendarDayMarker(current.DayIndex, current.Year, current.Month, current.Day),
            new Pes2021RuntimeCalendarDayMarker(next.DayIndex, next.Year, next.Month, next.Day),
            current.ScanStartAddress,
            current.ScanStopAddress,
            current.PreferredStrides,
            diffs);
    }

    private static Dictionary<int, ClusterMatch> MatchClustersByPreviewSimilarity(
        IReadOnlyList<Pes2021RuntimeCalendarFamilyClusterReport> currentClusters,
        IReadOnlyList<Pes2021RuntimeCalendarFamilyClusterReport> candidateClusters)
    {
        var matches = new Dictionary<int, ClusterMatch>();
        var currentGroups = currentClusters
            .Select((cluster, index) => new IndexedCluster(index, cluster))
            .GroupBy(static item => item.Cluster.TypicalStride)
            .ToDictionary(
                static group => group.Key,
                static group => group.OrderBy(item => item.Cluster.ClusterStartAddress).ToArray());

        var candidateGroups = candidateClusters
            .Select((cluster, index) => new IndexedCluster(index, cluster))
            .GroupBy(static item => item.Cluster.TypicalStride)
            .ToDictionary(
                static group => group.Key,
                static group => group.OrderBy(item => item.Cluster.ClusterStartAddress).ToArray());

        foreach (var (stride, strideCurrentClusters) in currentGroups)
        {
            if (!candidateGroups.TryGetValue(stride, out var strideCandidateClusters))
            {
                continue;
            }

            var usedCurrent = new HashSet<int>();
            var usedCandidate = new HashSet<int>();
            var candidates = new List<ClusterMatchCandidate>(strideCurrentClusters.Length * strideCandidateClusters.Length);
            foreach (var currentCluster in strideCurrentClusters)
            {
                foreach (var candidateCluster in strideCandidateClusters)
                {
                    var sharedPreviewValueCount = CountSharedPreviewValues(currentCluster.Cluster.PreviewInt32, candidateCluster.Cluster.PreviewInt32);
                    if (sharedPreviewValueCount == 0)
                    {
                        continue;
                    }

                    candidates.Add(new ClusterMatchCandidate(
                        currentCluster.Index,
                        candidateCluster.Index,
                        sharedPreviewValueCount,
                        Math.Abs(currentCluster.Cluster.HitCount - candidateCluster.Cluster.HitCount)));
                }
            }

            foreach (var candidate in candidates
                .OrderByDescending(item => item.SharedPreviewValueCount)
                .ThenBy(item => item.HitCountDelta)
                .ThenBy(item => currentClusters[item.CurrentClusterIndex].ClusterStartAddress)
                .ThenBy(item => candidateClusters[item.CandidateClusterIndex].ClusterStartAddress))
            {
                if (!usedCurrent.Add(candidate.CurrentClusterIndex) || !usedCandidate.Add(candidate.CandidateClusterIndex))
                {
                    continue;
                }

                matches[candidate.CurrentClusterIndex] = new ClusterMatch(
                    candidateClusters[candidate.CandidateClusterIndex],
                    "preview-overlap",
                    candidate.SharedPreviewValueCount);
            }

            var remainingCurrent = strideCurrentClusters
                .Where(item => !usedCurrent.Contains(item.Index))
                .OrderBy(item => item.Cluster.ClusterStartAddress)
                .ToArray();
            var remainingCandidate = strideCandidateClusters
                .Where(item => !usedCandidate.Contains(item.Index))
                .OrderBy(item => item.Cluster.ClusterStartAddress)
                .ToArray();

            var fallbackCount = Math.Min(remainingCurrent.Length, remainingCandidate.Length);
            for (var index = 0; index < fallbackCount; index++)
            {
                var currentCluster = remainingCurrent[index];
                var candidateCluster = remainingCandidate[index];
                matches[currentCluster.Index] = new ClusterMatch(candidateCluster.Cluster, "stride-ordinal-fallback", 0);
            }
        }

        return matches;
    }

    private static int CountSharedPreviewValues(
        IReadOnlyList<int> left,
        IReadOnlyList<int> right)
    {
        if (left.Count == 0 || right.Count == 0)
        {
            return 0;
        }

        var shared = left.Distinct().ToHashSet();
        shared.IntersectWith(right);
        return shared.Count;
    }

    private static IReadOnlyList<Pes2021RuntimeCalendarValueDiff> BuildValueDiff(
        IReadOnlyList<Pes2021RuntimeCalendarPreviewRecord> source,
        IReadOnlyList<int>? excludeValues)
    {
        var exclude = excludeValues is null ? [] : excludeValues.ToHashSet();
        return source
            .Where(item => !exclude.Contains(item.Value))
            .GroupBy(item => item.Value)
            .Select(group =>
            {
                var first = group.First();
                return new Pes2021RuntimeCalendarValueDiff(first.Value, first.Resolved, first.Record);
            })
            .OrderBy(item => item.Value)
            .ToArray();
    }

    private sealed record IndexedCluster(int Index, Pes2021RuntimeCalendarFamilyClusterReport Cluster);

    private sealed record ClusterMatch(
        Pes2021RuntimeCalendarFamilyClusterReport Cluster,
        string Strategy,
        int SharedPreviewValueCount);

    private sealed record ClusterMatchCandidate(
        int CurrentClusterIndex,
        int CandidateClusterIndex,
        int SharedPreviewValueCount,
        int HitCountDelta);
}
