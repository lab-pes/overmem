using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Overmem.Abstractions.Processes;
using Overmem.Application;
using Overmem.Application.Pes2021.Features.MatchCalendar;
using Overmem.Application.Pes2021.Shared;

namespace Overmem.Application.Pes2021.Features.RuntimeCalendar;

public sealed class DumpRuntimeDayPayloadFamilyHandler(
    ProcessMemoryApplicationService memoryService,
    Pes2021MemoryReader memoryReader,
    Pes2021AddressResolver addressResolver,
    FindMatchCalendarBaseHandler findMatchBase)
{
    public async Task<Pes2021RuntimeCalendarFamilyReport> HandleAsync(
        AttachmentId attachmentId,
        int year,
        int month,
        int day,
        ulong? startAddress = null,
        ulong? stopAddress = null,
        ulong? matchBaseAddress = null,
        int[]? preferredStrides = null,
        int minHitCount = 3,
        int clusterGap = 0x1000,
        int previewBytes = 0x100,
        CancellationToken cancellationToken = default)
    {
        minHitCount = Math.Max(1, minHitCount);
        clusterGap = Math.Max(1, clusterGap);
        previewBytes = Math.Clamp(previewBytes, 16, 0x800);

        var dayIndex = Pes2021CalendarHelpers.ComputeDailyDayIndex(year, month, day);
        var strideSet = (preferredStrides is { Length: > 0 } ? preferredStrides : [472, 528])
            .Where(static value => value > 0)
            .Distinct()
            .OrderBy(static value => value)
            .ToArray();

        var regions = await memoryService.ListRegionsAsync(attachmentId, cancellationToken);
        var scanRegions = Pes2021MemoryReader.FilterRuntimeScanRegions(regions, startAddress, stopAddress).ToArray();
        if (scanRegions.Length == 0)
        {
            throw new InvalidOperationException("No readable private runtime regions matched the requested scan window.");
        }

        var hits = new List<ulong>();
        var effectiveStarts = new List<ulong>(scanRegions.Length);
        var effectiveStops = new List<ulong>(scanRegions.Length);
        foreach (var region in scanRegions)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var regionStart = region.BaseAddress;
            var regionStop = checked(region.BaseAddress + region.RegionSize);
            var effectiveStart = startAddress.HasValue ? Math.Max(regionStart, startAddress.Value) : regionStart;
            var effectiveStop = stopAddress.HasValue ? Math.Min(regionStop, stopAddress.Value) : regionStop;
            if (effectiveStop <= effectiveStart)
            {
                continue;
            }

            effectiveStarts.Add(effectiveStart);
            effectiveStops.Add(effectiveStop);

            var regionHits = await memoryReader.ScanInt32InRegionAsync(attachmentId, region, dayIndex, effectiveStart, effectiveStop, cancellationToken);
            hits.AddRange(regionHits);
        }

        hits.Sort();
        var clusters = Pes2021MemoryReader.BuildRuntimeClusters(hits, scanRegions, clusterGap);
        var filteredClusters = clusters
            .Where(cluster => cluster.Addresses.Count >= minHitCount)
            .ToArray();

        if (strideSet.Length > 0)
        {
            var preferredClusters = filteredClusters
                .Where(cluster => strideSet.Contains(cluster.TypicalStride))
                .ToArray();
            if (preferredClusters.Length > 0)
            {
                filteredClusters = preferredClusters;
            }
        }

        var resolvedBase = matchBaseAddress;
        if (resolvedBase is null)
        {
            try
            {
                resolvedBase = await addressResolver.ResolveMatchBaseAddressAsync(
                    attachmentId,
                    null,
                    (id, ct) => findMatchBase.HandleAsync(id, cancellationToken: ct),
                    cancellationToken);
            }
            catch
            {
                resolvedBase = null;
            }
        }

        var reports = new List<Pes2021RuntimeCalendarFamilyClusterReport>(filteredClusters.Length);
        foreach (var cluster in filteredClusters)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var previewBytesBuffer = await memoryReader.ReadClusterPreviewBytesAsync(
                attachmentId,
                cluster.StartAddress,
                cluster.Region.BaseAddress,
                cluster.Region.RegionSize,
                previewBytes,
                cancellationToken);
            var previewValues = Pes2021MemoryReader.DecodeInt32Preview(previewBytesBuffer);
            var previewRecords = await memoryReader.DecodeRuntimePreviewRecordsAsync(attachmentId, resolvedBase, previewValues, cancellationToken);

            reports.Add(new Pes2021RuntimeCalendarFamilyClusterReport(
                cluster.StartAddress,
                cluster.EndAddress,
                cluster.Region.BaseAddress,
                cluster.Region.RegionSize,
                cluster.Region.Type,
                cluster.Region.Protection,
                cluster.Region.IsWritable,
                cluster.Region.IsExecutable,
                cluster.Addresses.Count,
                cluster.TypicalStride,
                cluster.Addresses.Take(16).ToArray(),
                previewValues,
                previewRecords));
        }

        var orderedReports = reports
            .OrderByDescending(report => strideSet.Contains(report.TypicalStride))
            .ThenByDescending(report => report.HitCount)
            .ThenBy(report => report.ClusterStartAddress)
            .ToArray();

        return new Pes2021RuntimeCalendarFamilyReport(
            attachmentId.Value,
            dayIndex,
            year,
            month,
            day,
            effectiveStarts.Count == 0 ? 0UL : effectiveStarts.Min(),
            effectiveStops.Count == 0 ? 0UL : effectiveStops.Max(),
            hits.Count,
            orderedReports.Length,
            strideSet,
            orderedReports);
    }
}
