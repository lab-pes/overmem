using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Overmem.Abstractions.Processes;
using Overmem.Application.Pes2021.Shared;

namespace Overmem.Application.Pes2021.Features.DailyCalendar;

public sealed class InspectDailyCalendarCandidateHandler(Pes2021DailyCalendarScorer scorer)
{
    public async Task<Pes2021DailyCalendarCandidateReport> HandleAsync(
        AttachmentId attachmentId,
        ulong baseValue,
        IReadOnlyList<int>? sampleDays = null,
        CancellationToken cancellationToken = default)
    {
        var result = await scorer.ScoreDailyCalendarBaseAsync(attachmentId, baseValue, sampleDays, cancellationToken);
        return result.Report;
    }
}
