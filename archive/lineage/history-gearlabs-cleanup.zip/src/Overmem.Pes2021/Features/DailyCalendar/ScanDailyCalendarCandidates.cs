using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Overmem.Abstractions.Processes;
using Overmem.Application.Pes2021.Shared;

namespace Overmem.Application.Pes2021.Features.DailyCalendar;

public sealed class ScanDailyCalendarCandidatesHandler(Pes2021DailyCalendarScorer scorer)
{
    public async Task<IReadOnlyList<Pes2021DailyCalendarCandidateReport>> HandleAsync(
        AttachmentId attachmentId,
        ulong startValue,
        ulong stopValue,
        ulong step = 0x10,
        int maxResults = 10,
        IReadOnlyList<int>? sampleDays = null,
        CancellationToken cancellationToken = default)
    {
        if (startValue > stopValue)
        {
            throw new ArgumentException("The scan start address must be less than or equal to the stop address.", nameof(startValue));
        }

        if (step == 0)
        {
            throw new ArgumentOutOfRangeException(nameof(step), "The scan step must be greater than zero.");
        }

        maxResults = Math.Max(1, maxResults);
        var results = new List<Pes2021DailyCalendarCandidateReport>();
        var scanned = 0;

        for (var address = startValue; address <= stopValue; address += step)
        {
            cancellationToken.ThrowIfCancellationRequested();
            scanned++;

            var score = await scorer.ScoreDailyCalendarBaseAsync(attachmentId, address, sampleDays, cancellationToken);
            if (score.Score >= Pes2021AgendaProfile.DailyScoreThreshold)
            {
                results.Add(score.Report);
                results.Sort(Pes2021DailyCalendarScorer.CompareDailyReports);
                if (results.Count > maxResults)
                {
                    results.RemoveAt(results.Count - 1);
                }
            }

            if (address + step < address)
            {
                break;
            }

            if (scanned % 256 == 0)
            {
                await Task.Yield();
            }
        }

        return results;
    }
}
