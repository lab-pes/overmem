using Microsoft.Extensions.DependencyInjection;
using Overmem.Application.Pes2021;
using Overmem.Application.Pes2021.Features.AnnualCalendar;
using Overmem.Application.Pes2021.Features.DailyCalendar;
using Overmem.Application.Pes2021.Features.MatchCalendar;
using Overmem.Application.Pes2021.Features.RuntimeCalendar;
using Overmem.Application.Pes2021.Shared;

namespace Microsoft.Extensions.DependencyInjection;

public static class Pes2021ServiceCollectionExtensions
{
    public static IServiceCollection AddPes2021Services(this IServiceCollection services)
    {
        // Register shared infrastructure
        services.AddSingleton<Pes2021MemoryReader>();
        services.AddSingleton<Pes2021DailyCalendarScorer>();
        services.AddSingleton<Pes2021AddressResolver>();

        // Register handlers
        services.AddSingleton<GetGuideHandler>();
        services.AddSingleton<FindMatchCalendarBaseHandler>();
        services.AddSingleton<DumpMatchCalendarDateHandler>();
        services.AddSingleton<CompareMatchCalendarDatesHandler>();
        services.AddSingleton<SummarizeMatchCalendarHandler>();

        services.AddSingleton<InspectDailyCalendarCandidateHandler>();
        services.AddSingleton<ScanDailyCalendarCandidatesHandler>();
        services.AddSingleton<FindDailyCalendarBaseByDateHandler>();
        services.AddSingleton<DumpDailyCalendarDayHandler>();

        services.AddSingleton<ScanRuntimeDayIndexClustersHandler>();
        services.AddSingleton<DumpRuntimeDayPayloadFamilyHandler>();
        services.AddSingleton<CompareRuntimeDayPayloadFamilyHandler>();
        services.AddSingleton<DumpRuntimeDayPayloadClusterDetailHandler>();
        services.AddSingleton<AnalyzeRuntimeDayPayloadClusterHandler>();
        services.AddSingleton<ClassifyRuntimeDayVariantHandler>();

        services.AddSingleton<InventoryAnnualEventsHandler>();

        // Register facade
        services.AddSingleton(sp => new Pes2021AgendaService(
            sp.GetRequiredService<GetGuideHandler>(),
            sp.GetRequiredService<FindMatchCalendarBaseHandler>(),
            sp.GetRequiredService<DumpMatchCalendarDateHandler>(),
            sp.GetRequiredService<CompareMatchCalendarDatesHandler>(),
            sp.GetRequiredService<SummarizeMatchCalendarHandler>(),
            sp.GetRequiredService<InspectDailyCalendarCandidateHandler>(),
            sp.GetRequiredService<ScanDailyCalendarCandidatesHandler>(),
            sp.GetRequiredService<FindDailyCalendarBaseByDateHandler>(),
            sp.GetRequiredService<DumpDailyCalendarDayHandler>(),
            sp.GetRequiredService<ScanRuntimeDayIndexClustersHandler>(),
            sp.GetRequiredService<DumpRuntimeDayPayloadFamilyHandler>(),
            sp.GetRequiredService<CompareRuntimeDayPayloadFamilyHandler>(),
            sp.GetRequiredService<DumpRuntimeDayPayloadClusterDetailHandler>(),
            sp.GetRequiredService<AnalyzeRuntimeDayPayloadClusterHandler>(),
            sp.GetRequiredService<ClassifyRuntimeDayVariantHandler>(),
            sp.GetRequiredService<InventoryAnnualEventsHandler>()
        ));

        return services;
    }
}
