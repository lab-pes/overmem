using System.Globalization;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace Overmem.Application.Pes2021;

internal static class Pes2021AgendaProfile
{
    internal const int MatchRecordStride = 0x254;
    internal const int DailyDayStride = 0x2C4;
    internal const int DailyDayCount = 365;
    internal const int DailyHeaderMaxEvents = 17;
    internal const int DailyHeaderEventSize = 8;
    internal const int DailyItemsStart = 0x8C;
    internal const int DailyItemsEnd = 0x2B8;
    internal const int DailyCountOffset = 0x2BC;
    internal const int DailyScoreThreshold = 20;

    internal static readonly int[] SeasonAnchorYears = [2026, 2025, 2027, 2024, 2028, 2023, 2029];

    internal static readonly int[] DailySampleDays = [0, 1, 31, 90, 181, 270, 363, 364];

    private static readonly string DocumentsPath = GetDocumentsPath();

    private static string GetDocumentsPath()
    {
        try
        {
            return Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        }
        catch
        {
            return @"C:\";
        }
    }

    internal static readonly string[] DefaultCheatTablePaths =
    [
        Path.Combine(DocumentsPath, "#PC", "PES 2021 - wILL- v0.0.1.CT"),
        Path.Combine(DocumentsPath, "PES 2021 - wILL- v0.0.1.CT")
    ];

    internal static readonly string[] DefaultCompetitionMapPaths =
    [
        Path.Combine(DocumentsPath, "My Cheat Tables", "input", "map_competitions-from-edit.txt"),
        Path.Combine(DocumentsPath, "map_competitions-from-edit.txt")
    ];

    internal static Pes2021AgendaGuide LoadGuide(string? cheatTablePath = null)
    {
        var resolvedCheatTablePath = ResolveFirstExistingPath(cheatTablePath, DefaultCheatTablePaths);
        if (resolvedCheatTablePath is null)
        {
            return new Pes2021AgendaGuide(
                CheatTablePath: cheatTablePath ?? DefaultCheatTablePaths[0],
                CheatTableFound: false,
                InspectorScriptPath: null,
                InspectorScriptFound: false,
                CompetitionMapPath: null,
                CompetitionMapFound: false,
                MatchRecordStride,
                DailyDayStride,
                DailyCountOffset,
                DailyItemsStart,
                DailyItemsEnd,
                DailyHeaderMaxEvents,
                DailyHeaderEventSize,
                DailyScoreThreshold,
                SeasonAnchorYears,
                DailySampleDays,
                []);
        }

        var ctText = File.ReadAllText(resolvedCheatTablePath);
        var cheatTable = XDocument.Parse(ctText, LoadOptions.PreserveWhitespace | LoadOptions.SetLineInfo);
        var bootstrapScript = cheatTable.Root?.Element("LuaScript")?.Value ?? string.Empty;
        var inspectorScriptPath = ExtractFirstMatch(bootstrapScript, @"local\s+inspectorFile\s*=\s*'(?<path>[^']+)'");
        var inspectorScriptFound = inspectorScriptPath is not null && File.Exists(inspectorScriptPath);
        var inspectorScriptText = inspectorScriptFound && inspectorScriptPath is not null
            ? File.ReadAllText(inspectorScriptPath)
            : bootstrapScript;

        var competitionMapPath = TryResolveCompetitionMapPath(inspectorScriptPath);
        var competitionMapFound = competitionMapPath is not null && File.Exists(competitionMapPath);

        return new Pes2021AgendaGuide(
            CheatTablePath: resolvedCheatTablePath,
            CheatTableFound: true,
            InspectorScriptPath: inspectorScriptPath,
            InspectorScriptFound: inspectorScriptFound,
            CompetitionMapPath: competitionMapPath,
            CompetitionMapFound: competitionMapFound,
            MatchRecordStride: ExtractInt(inspectorScriptText, @"local\s+RECORD_SZ\s*=\s*0x(?<value>[0-9A-Fa-f]+)", MatchRecordStride, hex: true),
            DailyDayStride: ExtractInt(inspectorScriptText, @"local\s+daily_DAY_STRIDE\s*=\s*0x(?<value>[0-9A-Fa-f]+)", DailyDayStride, hex: true),
            DailyCountOffset: ExtractInt(inspectorScriptText, @"local\s+daily_COUNT_OFFSET\s*=\s*0x(?<value>[0-9A-Fa-f]+)", DailyCountOffset, hex: true),
            DailyItemsStart: ExtractInt(inspectorScriptText, @"local\s+daily_ITEMS_START\s*=\s*0x(?<value>[0-9A-Fa-f]+)", DailyItemsStart, hex: true),
            DailyItemsEnd: ExtractInt(inspectorScriptText, @"local\s+daily_ITEMS_END\s*=\s*0x(?<value>[0-9A-Fa-f]+)", DailyItemsEnd, hex: true),
            DailyHeaderMaxEvents: ExtractInt(inspectorScriptText, @"local\s+daily_HEADER_MAX_EVENTS\s*=\s*(?<value>\d+)", DailyHeaderMaxEvents),
            DailyHeaderEventSize: ExtractInt(inspectorScriptText, @"local\s+daily_HEADER_EVENT_SIZE\s*=\s*(?<value>\d+)", DailyHeaderEventSize),
            DailyScoreThreshold: ExtractInt(inspectorScriptText, @"local\s+daily_SCORE_THRESHOLD\s*=\s*(?<value>\d+)", DailyScoreThreshold),
            SeasonAnchorYears: ExtractIntList(inspectorScriptText, @"local\s+seasonAnchorYears\s*=\s*\{(?<values>[^}]*)\}", SeasonAnchorYears),
            DailySampleDays: ExtractIntList(inspectorScriptText, @"local\s+daily_SAMPLE_DAYS\s*=\s*\{(?<values>[^}]*)\}", DailySampleDays),
            References: ExtractReferences(cheatTable));
    }

    internal static string ResolveCompetitionMapPath(string? inspectorScriptPath)
    {
        var path = TryResolveCompetitionMapPath(inspectorScriptPath);
        if (path is not null)
        {
            return path;
        }

        return DefaultCompetitionMapPaths[0];
    }

    internal static string? TryResolveCompetitionMapPath(string? inspectorScriptPath)
    {
        if (string.IsNullOrWhiteSpace(inspectorScriptPath) || !File.Exists(inspectorScriptPath))
        {
            return null;
        }

        var script = File.ReadAllText(inspectorScriptPath);
        var repoDir = ExtractFirstMatch(script, @"local\s+REPO_DIR\s*=\s*""(?<path>[^""]+)""");
        if (!string.IsNullOrWhiteSpace(repoDir))
        {
            return Path.Combine(repoDir, "input", "map_competitions-from-edit.txt");
        }

        var directPath = ExtractFirstMatch(script, @"local\s+COMP_MAP_FILE\s*=\s*""(?<path>[^""]+)""");
        if (!string.IsNullOrWhiteSpace(directPath))
        {
            return directPath;
        }

        return null;
    }

    internal static IReadOnlyDictionary<int, string> LoadCompetitionMap(string? mapPath = null)
    {
        var map = new Dictionary<int, string>();

        var resolvedPath = ResolveFirstExistingPath(mapPath, DefaultCompetitionMapPaths);
        if (resolvedPath is not null)
        {
            MergeCsvCompetitionMap(map, resolvedPath);
        }

        return map;
    }

    private static void MergeCsvCompetitionMap(Dictionary<int, string> map, string path)
    {
        foreach (var rawLine in File.ReadLines(path))
        {
            var line = rawLine.Trim();
            if (line.Length == 0)
            {
                continue;
            }

            if (line.StartsWith("#", StringComparison.Ordinal) || line.StartsWith(";", StringComparison.Ordinal))
            {
                continue;
            }

            var match = Regex.Match(line, @"^\s*(?<code>-?\d+)\s*,\s*(?<label>[^#]+?)\s*(?:#.*)?$");
            if (!match.Success)
            {
                continue;
            }

            if (!int.TryParse(match.Groups["code"].Value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var code))
            {
                continue;
            }

            var label = match.Groups["label"].Value.Trim();
            if (label.Length == 0 || map.ContainsKey(code))
            {
                continue;
            }

            map[code] = label;
        }
    }

    private static IReadOnlyList<Pes2021CalendarReference> ExtractReferences(XDocument cheatTable)
    {
        var rootEntries = cheatTable.Root?.Element("CheatEntries");
        if (rootEntries is null)
        {
            return [];
        }

        var references = new List<Pes2021CalendarReference>();
        foreach (var group in rootEntries.Elements("CheatEntry"))
        {
            var description = ReadText(group, "Description");
            CollectReferences(group, description ?? string.Empty, references);
        }

        return references;
    }

    private static void CollectReferences(XElement entry, string scope, List<Pes2021CalendarReference> references)
    {
        var description = ReadText(entry, "Description")?.Trim('"');
        var address = ReadText(entry, "Address");
        var variableType = ReadText(entry, "VariableType");
        var offsets = ReadOffsets(entry);

        if (description is not null && IsRelevantReference(description))
        {
            references.Add(new Pes2021CalendarReference(scope, description, address, variableType, offsets));
        }

        var childEntries = entry.Element("CheatEntries");
        if (childEntries is null)
        {
            return;
        }

        var nextScope = description is not null && description.Length > 0 ? description : scope;
        foreach (var child in childEntries.Elements("CheatEntry"))
        {
            CollectReferences(child, nextScope, references);
        }
    }

    private static bool IsRelevantGroup(string? description)
    {
        if (string.IsNullOrWhiteSpace(description))
        {
            return false;
        }

        var value = description.Trim('"').ToLowerInvariant();
        return value.Contains("calendar")
            || value.Contains("agenda")
            || value.Contains("schedule")
            || value.Contains("fixture")
            || value.Contains("ml calendar")
            || value.Contains("r3-checks");
    }

    private static bool IsRelevantReference(string description)
    {
        var value = description.ToLowerInvariant();
        return value.Contains("calendar")
            || value.Contains("agenda")
            || value.Contains("schedule")
            || value.Contains("fixture")
            || value.Contains("competition code")
            || value.Contains("round")
            || value.Contains("year")
            || value.Contains("month")
            || value.Contains("day")
            || value.Contains("home id")
            || value.Contains("away id")
            || value.Contains("score")
            || value.Contains("record index")
            || value.Contains("record addr")
            || value.Contains("next record")
            || value.Contains("sig-");
    }

    private static IReadOnlyList<int> ReadOffsets(XElement entry)
    {
        var offsets = new List<int>();
        var offsetsElement = entry.Element("Offsets");
        if (offsetsElement is null)
        {
            return offsets;
        }

        foreach (var offsetElement in offsetsElement.Elements("Offset"))
        {
            var text = offsetElement.Value.Trim();
            if (text.Length == 0)
            {
                continue;
            }

            if (int.TryParse(text, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var offset))
            {
                offsets.Add(offset);
            }
        }

        return offsets;
    }

    private static string? ReadText(XElement element, string childName)
        => element.Element(childName)?.Value;

    private static string NormalizeLuaPath(string path)
        => path.Replace(@"\\", @"\");

    private static string? ResolveFirstExistingPath(string? preferredPath, IReadOnlyList<string> fallbackPaths)
    {
        if (!string.IsNullOrWhiteSpace(preferredPath) && File.Exists(preferredPath))
        {
            return preferredPath;
        }

        foreach (var fallback in fallbackPaths)
        {
            if (File.Exists(fallback))
            {
                return fallback;
            }
        }

        return null;
    }

    private static string? ExtractFirstMatch(string input, string pattern)
    {
        if (string.IsNullOrWhiteSpace(input))
        {
            return null;
        }

        var match = Regex.Match(input, pattern);
        if (!match.Success)
        {
            return null;
        }

        return NormalizeLuaPath(match.Groups["path"].Value);
    }

    private static int ExtractInt(string input, string pattern, int fallback, bool hex = false)
    {
        var match = Regex.Match(input, pattern);
        if (!match.Success)
        {
            return fallback;
        }

        var valueText = match.Groups["value"].Value;
        return int.TryParse(
            valueText,
            hex ? NumberStyles.HexNumber : NumberStyles.Integer,
            CultureInfo.InvariantCulture,
            out var value)
            ? value
            : fallback;
    }

    private static IReadOnlyList<int> ExtractIntList(string input, string pattern, IReadOnlyList<int> fallback)
    {
        var match = Regex.Match(input, pattern, RegexOptions.Singleline);
        if (!match.Success)
        {
            return fallback;
        }

        var valueText = match.Groups["values"].Value;
        var values = new List<int>();
        foreach (Match numberMatch in Regex.Matches(valueText, @"-?\d+"))
        {
            if (int.TryParse(numberMatch.Value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var value))
            {
                values.Add(value);
            }
        }

        return values.Count > 0 ? values : fallback;
    }
}
