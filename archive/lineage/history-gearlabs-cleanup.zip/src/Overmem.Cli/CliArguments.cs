using Overmem.Abstractions.Memory;
using Overmem.Abstractions.Processes;

namespace Overmem.Cli;

public abstract record CliCommand;

public sealed record HelpCliCommand : CliCommand;

public sealed record ListModulesCliCommand(ProcessSelector Selector) : CliCommand;

public sealed record ListRegionsCliCommand(ProcessSelector Selector) : CliCommand;

public sealed record ReadCliCommand(ProcessSelector Selector, ulong Address, MemoryValueKind ValueKind, int Size) : CliCommand;

public sealed record WriteCliCommand(ProcessSelector Selector, ulong Address, MemoryValueKind ValueKind, string Value, int Size) : CliCommand;

public sealed record ScanPatternCliCommand(ProcessSelector Selector, string Pattern, string? ModuleName, int MaxResults) : CliCommand;

public sealed record ResolvePointerCliCommand(ProcessSelector Selector, ulong BaseAddress, long[] Offsets) : CliCommand;

public sealed record ResolveModulePointerCliCommand(ProcessSelector Selector, string ModuleName, long BaseOffset, long[] Offsets) : CliCommand;

public sealed record LoadTableCliCommand(string FilePath) : CliCommand;

public sealed record SaveTableCliCommand(string SourceFilePath, string DestinationFilePath) : CliCommand;

public sealed record RefreshTableCliCommand(ProcessSelector Selector, string FilePath) : CliCommand;

public sealed record ScanValueCliCommand(ProcessSelector Selector, MemoryValueKind ValueKind, string Value, int Size, int Alignment, int MaxResults) : CliCommand;

public sealed record DiscoverPointersCliCommand(ProcessSelector Selector, ulong TargetAddress, int MaxDepth, long MaxOffset, int Alignment, int MaxResults, string? BaseModuleName, bool RevalidateCandidates) : CliCommand;

public sealed record Pes2021FindCalendarBaseCliCommand(
    ProcessSelector Selector,
    int? Year,
    int? Month,
    int? Day,
    int? RoundValue,
    int? CompetitionCode,
    string? ModuleName,
    int MaxResults) : CliCommand;

public sealed record Pes2021DumpCalendarDateCliCommand(
    ProcessSelector Selector,
    int Year,
    int Month,
    int Day,
    ulong? BaseAddress,
    int MaxRecords) : CliCommand;

public sealed record Pes2021CompareCalendarDatesCliCommand(
    ProcessSelector Selector,
    int FirstYear,
    int FirstMonth,
    int FirstDay,
    int SecondYear,
    int SecondMonth,
    int SecondDay,
    ulong? BaseAddress,
    int MaxRecords) : CliCommand;

public sealed record Pes2021CalendarSummaryCliCommand(
    ProcessSelector Selector,
    ulong? BaseAddress,
    int MaxRecords) : CliCommand;

public sealed record Pes2021InventoryAnnualEventsCliCommand(
    ProcessSelector Selector,
    int Year,
    ulong? matchBaseAddress,
    ulong? dailyBaseAddress) : CliCommand;

public sealed record Pes2021FinddailyCalendarBaseByDateCliCommand(
    ProcessSelector Selector,
    int Year,
    int Month,
    int Day,
    string? ModuleName,
    int MaxResults) : CliCommand;

public sealed record Pes2021DumpdailyCalendarDayCliCommand(
    ProcessSelector Selector,
    int Year,
    int Month,
    int Day,
    ulong? BaseAddress) : CliCommand;

public sealed record Pes2021ScanRuntimeDayIndexClustersCliCommand(
    ProcessSelector Selector,
    int Year,
    int Month,
    int Day,
    int MaxResults,
    int ClusterGap,
    int PreviewBytes) : CliCommand;

public sealed record Pes2021DumpRuntimeDayPayloadFamilyCliCommand(
    ProcessSelector Selector,
    int Year,
    int Month,
    int Day,
    ulong? StartAddress,
    ulong? StopAddress,
    ulong? matchBaseAddress,
    int[] PreferredStrides,
    int MinHitCount,
    int ClusterGap,
    int PreviewBytes) : CliCommand;

public sealed record Pes2021CompareRuntimeDayPayloadFamilyCliCommand(
    ProcessSelector Selector,
    int Year,
    int Month,
    int Day,
    ulong? StartAddress,
    ulong? StopAddress,
    ulong? matchBaseAddress,
    int[] PreferredStrides,
    int MinHitCount,
    int ClusterGap,
    int PreviewBytes) : CliCommand;

public sealed record Pes2021DumpRuntimeDayPayloadClusterDetailCliCommand(
    ProcessSelector Selector,
    int Year,
    int Month,
    int Day,
    int ClusterOrdinal,
    ulong? StartAddress,
    ulong? StopAddress,
    ulong? matchBaseAddress,
    int[] PreferredStrides,
    int MinHitCount,
    int ClusterGap,
    int PreviewBytes,
    int IntsBeforeHit,
    int IntsAfterHit) : CliCommand;

public sealed record Pes2021AnalyzeRuntimeDayPayloadClusterCliCommand(
    ProcessSelector Selector,
    int Year,
    int Month,
    int Day,
    int ClusterOrdinal,
    ulong? StartAddress,
    ulong? StopAddress,
    ulong? matchBaseAddress,
    int[] PreferredStrides,
    int MinHitCount,
    int ClusterGap,
    int PreviewBytes,
    int IntsBeforeHit,
    int IntsAfterHit) : CliCommand;

public sealed record Pes2021ClassifyRuntimeDayVariantCliCommand(
    ProcessSelector Selector,
    int Year,
    int Month,
    int Day,
    ulong? StartAddress,
    ulong? StopAddress,
    ulong? dailyBaseAddress,
    ulong? matchBaseAddress,
    int[] PreferredStrides,
    int MinHitCount,
    int ClusterGap,
    int PreviewBytes) : CliCommand;

public static class CliArgumentParser
{
    public static CliCommand Parse(string[] args)
    {
        if (args.Length == 0 || args[0] is "help" or "--help" or "-h")
        {
            return new HelpCliCommand();
        }

        var commandName = args[0];
        var options = ParseOptions(args[1..]);

        return commandName switch
        {
            "modules" => new ListModulesCliCommand(ParseSelector(options)),
            "regions" => new ListRegionsCliCommand(ParseSelector(options)),
            "read" => new ReadCliCommand(
                ParseSelector(options),
                ParseUnsignedLong(GetRequiredOption(options, "address")),
                Enum.Parse<MemoryValueKind>(GetRequiredOption(options, "value-kind"), ignoreCase: true),
                ParseInt32(GetOptionalOption(options, "size") ?? "0")),
            "write" => new WriteCliCommand(
                ParseSelector(options),
                ParseUnsignedLong(GetRequiredOption(options, "address")),
                Enum.Parse<MemoryValueKind>(GetRequiredOption(options, "value-kind"), ignoreCase: true),
                GetRequiredOption(options, "value"),
                ParseInt32(GetOptionalOption(options, "size") ?? "0")),
            "scan-pattern" => new ScanPatternCliCommand(
                ParseSelector(options),
                GetRequiredOption(options, "pattern"),
                GetOptionalOption(options, "module-name"),
                ParseInt32(GetOptionalOption(options, "max-results") ?? "100")),
            "resolve-pointer" => new ResolvePointerCliCommand(
                ParseSelector(options),
                ParseUnsignedLong(GetRequiredOption(options, "base-address")),
                ParseOffsets(GetOptionalOption(options, "offsets"))),
            "resolve-module-pointer" => new ResolveModulePointerCliCommand(
                ParseSelector(options),
                GetRequiredOption(options, "module-name"),
                ParseInt64(GetOptionalOption(options, "base-offset") ?? "0"),
                ParseOffsets(GetOptionalOption(options, "offsets"))),
            "table-load" => new LoadTableCliCommand(GetRequiredOption(options, "file")),
            "table-save" => new SaveTableCliCommand(
                GetRequiredOption(options, "source-file"),
                GetRequiredOption(options, "destination-file")),
            "table-refresh" => new RefreshTableCliCommand(ParseSelector(options), GetRequiredOption(options, "file")),
            "scan-value" => new ScanValueCliCommand(
                ParseSelector(options),
                Enum.Parse<MemoryValueKind>(GetRequiredOption(options, "value-kind"), ignoreCase: true),
                GetRequiredOption(options, "value"),
                ParseInt32(GetOptionalOption(options, "size") ?? "0"),
                ParseInt32(GetOptionalOption(options, "alignment") ?? "1"),
                ParseInt32(GetOptionalOption(options, "max-results") ?? "1000")),
            "discover-pointers" => new DiscoverPointersCliCommand(
                ParseSelector(options),
                ParseUnsignedLong(GetRequiredOption(options, "target-address")),
                ParseInt32(GetOptionalOption(options, "max-depth") ?? "2"),
                ParseInt64(GetOptionalOption(options, "max-offset") ?? "0"),
                ParseInt32(GetOptionalOption(options, "alignment") ?? "0"),
                ParseInt32(GetOptionalOption(options, "max-results") ?? "100"),
                GetOptionalOption(options, "base-module-name"),
                !options.ContainsKey("skip-revalidation")),
            "pes2021-find-calendar-base" => new Pes2021FindCalendarBaseCliCommand(
                ParseSelector(options),
                ParseOptionalInt32(GetOptionalOption(options, "year")),
                ParseOptionalInt32(GetOptionalOption(options, "month")),
                ParseOptionalInt32(GetOptionalOption(options, "day")),
                ParseOptionalInt32(GetOptionalOption(options, "round")),
                ParseOptionalInt32(GetOptionalOption(options, "competition-code")),
                GetOptionalOption(options, "module-name"),
                ParseInt32(GetOptionalOption(options, "max-results") ?? "100")),
            "pes2021-dump-calendar-date" => new Pes2021DumpCalendarDateCliCommand(
                ParseSelector(options),
                ParseInt32(GetRequiredOption(options, "year")),
                ParseInt32(GetRequiredOption(options, "month")),
                ParseInt32(GetRequiredOption(options, "day")),
                ParseOptionalUnsignedLong(GetOptionalOption(options, "base-address")),
                ParseInt32(GetOptionalOption(options, "max-records") ?? "13014")),
            "pes2021-compare-calendar-dates" => new Pes2021CompareCalendarDatesCliCommand(
                ParseSelector(options),
                ParseInt32(GetRequiredOption(options, "first-year")),
                ParseInt32(GetRequiredOption(options, "first-month")),
                ParseInt32(GetRequiredOption(options, "first-day")),
                ParseInt32(GetRequiredOption(options, "second-year")),
                ParseInt32(GetRequiredOption(options, "second-month")),
                ParseInt32(GetRequiredOption(options, "second-day")),
                ParseOptionalUnsignedLong(GetOptionalOption(options, "base-address")),
                ParseInt32(GetOptionalOption(options, "max-records") ?? "13014")),
            "pes2021-calendar-summary" => new Pes2021CalendarSummaryCliCommand(
                ParseSelector(options),
                ParseOptionalUnsignedLong(GetOptionalOption(options, "base-address")),
                ParseInt32(GetOptionalOption(options, "max-records") ?? "13014")),
            "pes2021-inventory-annual-events" => new Pes2021InventoryAnnualEventsCliCommand(
                ParseSelector(options),
                ParseInt32(GetRequiredOption(options, "year")),
                ParseOptionalUnsignedLong(GetOptionalOption(options, "calendar-base-address")),
                ParseOptionalUnsignedLong(GetOptionalOption(options, "daily-base-address"))),
            "pes2021-find-daily-calendar-base-by-date" => new Pes2021FinddailyCalendarBaseByDateCliCommand(
                ParseSelector(options),
                ParseInt32(GetRequiredOption(options, "year")),
                ParseInt32(GetRequiredOption(options, "month")),
                ParseInt32(GetRequiredOption(options, "day")),
                GetOptionalOption(options, "module-name"),
                ParseInt32(GetOptionalOption(options, "max-results") ?? "256")),
            "pes2021-dump-daily-calendar-day" => new Pes2021DumpdailyCalendarDayCliCommand(
                ParseSelector(options),
                ParseInt32(GetRequiredOption(options, "year")),
                ParseInt32(GetRequiredOption(options, "month")),
                ParseInt32(GetRequiredOption(options, "day")),
                ParseOptionalUnsignedLong(GetOptionalOption(options, "base-address"))),
            "pes2021-scan-runtime-day-index-clusters" => new Pes2021ScanRuntimeDayIndexClustersCliCommand(
                ParseSelector(options),
                ParseInt32(GetRequiredOption(options, "year")),
                ParseInt32(GetRequiredOption(options, "month")),
                ParseInt32(GetRequiredOption(options, "day")),
                ParseInt32(GetOptionalOption(options, "max-results") ?? "5000"),
                ParseInt32(GetOptionalOption(options, "cluster-gap") ?? "4096"),
                ParseInt32(GetOptionalOption(options, "preview-bytes") ?? "256")),
            "pes2021-dump-runtime-day-payload-family" => new Pes2021DumpRuntimeDayPayloadFamilyCliCommand(
                ParseSelector(options),
                ParseInt32(GetRequiredOption(options, "year")),
                ParseInt32(GetRequiredOption(options, "month")),
                ParseInt32(GetRequiredOption(options, "day")),
                ParseOptionalUnsignedLong(GetOptionalOption(options, "start-address")),
                ParseOptionalUnsignedLong(GetOptionalOption(options, "stop-address")),
                ParseOptionalUnsignedLong(GetOptionalOption(options, "calendar-base-address")),
                ParseInt32List(GetOptionalOption(options, "preferred-strides")),
                ParseInt32(GetOptionalOption(options, "min-hit-count") ?? "3"),
                ParseInt32(GetOptionalOption(options, "cluster-gap") ?? "4096"),
                ParseInt32(GetOptionalOption(options, "preview-bytes") ?? "256")),
            "pes2021-compare-runtime-day-payload-family" => new Pes2021CompareRuntimeDayPayloadFamilyCliCommand(
                ParseSelector(options),
                ParseInt32(GetRequiredOption(options, "year")),
                ParseInt32(GetRequiredOption(options, "month")),
                ParseInt32(GetRequiredOption(options, "day")),
                ParseOptionalUnsignedLong(GetOptionalOption(options, "start-address")),
                ParseOptionalUnsignedLong(GetOptionalOption(options, "stop-address")),
                ParseOptionalUnsignedLong(GetOptionalOption(options, "calendar-base-address")),
                ParseInt32List(GetOptionalOption(options, "preferred-strides")),
                ParseInt32(GetOptionalOption(options, "min-hit-count") ?? "3"),
                ParseInt32(GetOptionalOption(options, "cluster-gap") ?? "4096"),
                ParseInt32(GetOptionalOption(options, "preview-bytes") ?? "256")),
            "pes2021-dump-runtime-day-payload-cluster-detail" => new Pes2021DumpRuntimeDayPayloadClusterDetailCliCommand(
                ParseSelector(options),
                ParseInt32(GetRequiredOption(options, "year")),
                ParseInt32(GetRequiredOption(options, "month")),
                ParseInt32(GetRequiredOption(options, "day")),
                ParseInt32(GetRequiredOption(options, "cluster-ordinal")),
                ParseOptionalUnsignedLong(GetOptionalOption(options, "start-address")),
                ParseOptionalUnsignedLong(GetOptionalOption(options, "stop-address")),
                ParseOptionalUnsignedLong(GetOptionalOption(options, "calendar-base-address")),
                ParseInt32List(GetOptionalOption(options, "preferred-strides")),
                ParseInt32(GetOptionalOption(options, "min-hit-count") ?? "3"),
                ParseInt32(GetOptionalOption(options, "cluster-gap") ?? "4096"),
                ParseInt32(GetOptionalOption(options, "preview-bytes") ?? "256"),
                ParseInt32(GetOptionalOption(options, "ints-before-hit") ?? "8"),
                ParseInt32(GetOptionalOption(options, "ints-after-hit") ?? "24")),
            "pes2021-analyze-runtime-day-payload-cluster" => new Pes2021AnalyzeRuntimeDayPayloadClusterCliCommand(
                ParseSelector(options),
                ParseInt32(GetRequiredOption(options, "year")),
                ParseInt32(GetRequiredOption(options, "month")),
                ParseInt32(GetRequiredOption(options, "day")),
                ParseInt32(GetRequiredOption(options, "cluster-ordinal")),
                ParseOptionalUnsignedLong(GetOptionalOption(options, "start-address")),
                ParseOptionalUnsignedLong(GetOptionalOption(options, "stop-address")),
                ParseOptionalUnsignedLong(GetOptionalOption(options, "calendar-base-address")),
                ParseInt32List(GetOptionalOption(options, "preferred-strides")),
                ParseInt32(GetOptionalOption(options, "min-hit-count") ?? "3"),
                ParseInt32(GetOptionalOption(options, "cluster-gap") ?? "4096"),
                ParseInt32(GetOptionalOption(options, "preview-bytes") ?? "256"),
                ParseInt32(GetOptionalOption(options, "ints-before-hit") ?? "8"),
                ParseInt32(GetOptionalOption(options, "ints-after-hit") ?? "24")),
            "pes2021-classify-runtime-day-variant" => new Pes2021ClassifyRuntimeDayVariantCliCommand(
                ParseSelector(options),
                ParseInt32(GetRequiredOption(options, "year")),
                ParseInt32(GetRequiredOption(options, "month")),
                ParseInt32(GetRequiredOption(options, "day")),
                ParseOptionalUnsignedLong(GetOptionalOption(options, "start-address")),
                ParseOptionalUnsignedLong(GetOptionalOption(options, "stop-address")),
                ParseOptionalUnsignedLong(GetOptionalOption(options, "daily-base-address")),
                ParseOptionalUnsignedLong(GetOptionalOption(options, "calendar-base-address")),
                ParseInt32List(GetOptionalOption(options, "preferred-strides")),
                ParseInt32(GetOptionalOption(options, "min-hit-count") ?? "3"),
                ParseInt32(GetOptionalOption(options, "cluster-gap") ?? "4096"),
                ParseInt32(GetOptionalOption(options, "preview-bytes") ?? "256")),
            _ => throw new ArgumentException($"Unknown command '{commandName}'.")
        };
    }

    private static Dictionary<string, string?> ParseOptions(string[] args)
    {
        var options = new Dictionary<string, string?>(StringComparer.OrdinalIgnoreCase);
        for (var index = 0; index < args.Length; index++)
        {
            var token = args[index];
            if (!token.StartsWith("--", StringComparison.Ordinal))
            {
                throw new ArgumentException($"Unexpected token '{token}'. Options must start with '--'.");
            }

            var optionName = token[2..];
            if (string.IsNullOrWhiteSpace(optionName))
            {
                throw new ArgumentException("Option names cannot be empty.");
            }

            if (index == args.Length - 1 || args[index + 1].StartsWith("--", StringComparison.Ordinal))
            {
                options[optionName] = null;
                continue;
            }

            options[optionName] = args[++index];
        }

        return options;
    }

    private static ProcessSelector ParseSelector(IReadOnlyDictionary<string, string?> options)
    {
        var pidText = GetOptionalOption(options, "pid");
        var processName = GetOptionalOption(options, "name");
        int? pid = string.IsNullOrWhiteSpace(pidText) ? null : ParseInt32(pidText);

        var selector = new ProcessSelector(pid, processName);
        if (!selector.IsValid())
        {
            throw new ArgumentException("Specify either --pid or --name.");
        }

        return selector;
    }

    private static string GetRequiredOption(IReadOnlyDictionary<string, string?> options, string name)
        => GetOptionalOption(options, name) ?? throw new ArgumentException($"Missing required option '--{name}'.");

    private static string? GetOptionalOption(IReadOnlyDictionary<string, string?> options, string name, string? defaultValue = null)
        => options.TryGetValue(name, out var value) && value is not null ? value : defaultValue;

    private static int ParseInt32(string value)
        => value.StartsWith("0x", StringComparison.OrdinalIgnoreCase)
            ? Convert.ToInt32(value[2..], 16)
            : int.Parse(value, System.Globalization.CultureInfo.InvariantCulture);

    private static int? ParseOptionalInt32(string? value)
        => string.IsNullOrWhiteSpace(value) ? null : ParseInt32(value);

    private static long ParseInt64(string value)
        => value.StartsWith("0x", StringComparison.OrdinalIgnoreCase)
            ? Convert.ToInt64(value[2..], 16)
            : long.Parse(value, System.Globalization.CultureInfo.InvariantCulture);

    private static ulong ParseUnsignedLong(string value)
        => value.StartsWith("0x", StringComparison.OrdinalIgnoreCase)
            ? Convert.ToUInt64(value[2..], 16)
            : ulong.Parse(value, System.Globalization.CultureInfo.InvariantCulture);

    private static ulong? ParseOptionalUnsignedLong(string? value)
        => string.IsNullOrWhiteSpace(value) ? null : ParseUnsignedLong(value);

    private static long[] ParseOffsets(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return [];
        }

        return value.Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries)
            .Select(ParseInt64)
            .ToArray();
    }

    private static int[] ParseInt32List(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return [];
        }

        return value.Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries)
            .Select(ParseInt32)
            .ToArray();
    }
}