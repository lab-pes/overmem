# Overmem

Overmem is a Windows-only .NET 8 process memory platform focused on headless operation. The current repository scope is the backend surface only: shared contracts, application services, a Win32 provider, a one-shot CLI, and a local stdio MCP server. UI work is intentionally out of scope for now.

The project already covers a meaningful subset of Cheat Engine style workflows for process attachment, region/module inspection, typed reads and writes, pointer resolution, pattern scanning, freezing, exact value search, memory tables, and host runtime diagnostics. It does not yet cover the full Cheat Engine feature set.

## Status At A Glance

Ready now:

- Process attach and detach by PID or process name.
- Module listing and virtual memory region enumeration.
- Typed memory read and write for `Bytes`, `Int32`, `Int64`, `Float`, `Double`, `Utf8String`, and `Utf16String`.
- Pointer-chain resolution from an absolute base address.
- Pointer-chain resolution from a module-relative base address.
- Initial absolute pointer discovery with bounded depth and offset scanning.
- Pattern scanning with `??` wildcards.
- Freeze orchestration with automatic cleanup on detach.
- Exact value search sessions with `Exact`, `NotEqual`, `Changed`, `Unchanged`, `Increased`, `Decreased`, `IncreasedBy`, `DecreasedBy`, `ChangedBy`, and `Between` refinement.
- Unknown initial value search sessions: capture all aligned baseline values and narrow with `Changed`, `Unchanged`, `Increased`, `Decreased`, `Between`, etc.
- JSON-backed memory tables with on-demand refresh.
- Host runtime diagnostics for active attachments and recent operations.
- Headless execution through a local CLI.
- Host integration through a local stdio MCP server.

Partially ready:

- CLI value search supports exact one-shot scans only. Multi-step refinement is currently MCP-host only.
- Pointer discovery now supports optional base-module filtering and candidate revalidation, but pointer maps and large-scale ranking/revalidation workflows are not implemented yet.
- Value-search sessions are in-memory host state only. They are not persisted.
- Memory-table refresh is on demand only. There is no background refresh daemon.

Not implemented yet:

- Any UI surface.
- Cheat Engine `.CT` import and export.
- Full pointer scanner workflows with pointer maps, ranking, and revalidation.
- Advanced value search modes such as grouped searches. Unknown initial value, ranges, deltas, and inequality are already supported.
- Disassembly, instruction-level inspection, breakpoints, tracing, or debugger features.
- Code patching, injection, hooks, speedhack, or instrumentation workflows.
- Lua runtime and compatibility execution.
- Managed-runtime providers for Mono, .NET object inspection, or Java.
- Plugin system or extension model.
- Remote/distributed execution model.
- Kernel or privileged providers.

## Solution Layout

- `src/Overmem.Abstractions`: contracts shared by every layer.
- `src/Overmem.Application`: application-facing orchestration and validation.
- `src/Overmem.Runtime`: host-level runtime services such as attachment session tracking and recent-operation journals.
- `src/Overmem.Search`: exact value search sessions and refinement logic.
- `src/Overmem.Hosting`: shared dependency injection wiring for local hosts.
- `src/Overmem.Cli`: one-shot command-line host.
- `src/Overmem.Windows`: Win32-backed implementation of the process memory gateway.
- `src/Overmem.McpServer`: local stdio MCP host exposing the headless workflows.
- `tests/Overmem.TestTarget`: controlled process used by integration tests.
- `tests/Overmem.Tests`: unit and integration suite.

## Implemented Capability Surface

### Process and Runtime

- Attach to a process by PID or by name.
- Detach and release native handles.
- Track active attachments in long-lived hosts.
- Record recent host operations in a bounded in-memory journal.

### Memory Access

- List loaded modules.
- Enumerate virtual memory regions with readable, writable, and executable flags.
- Read typed values from absolute addresses.
- Write typed values to absolute addresses.
- Resolve pointer chains from absolute bases.
- Resolve pointer chains from module-relative bases.
- Scan readable regions for hex signatures with optional `??` wildcards.

### Pointer Discovery

- Discover absolute pointer candidates that can resolve to a known target address.
- Bound discovery by maximum depth.
- Bound discovery by maximum absolute offset per dereference.
- Annotate candidates with module-relative base information when the candidate base falls inside a loaded module.
- Optionally filter candidates by a required base module name.
- Optionally revalidate candidates by resolving the discovered pointer chain before returning it.
- Rank candidates by a heuristic score: revalidated > module-rooted > shorter chain > smaller offsets > aligned offsets.

### Freeze Workflows

- Freeze a value at an absolute address.
- Freeze a value resolved from an absolute-base pointer chain.
- Freeze a value resolved from a module-relative pointer chain.
- List active freezes.
- Cancel freezes explicitly.
- Stop freezes automatically when the owning attachment is detached.

### Value Search


### Pattern Format

- Exact pattern example: `DE AD BE EF 44 99`
- Wildcard pattern example: `DE AD ?? EF 44 99`

### Memory Table Document Format

Memory tables are stored as versioned JSON documents. The current schema version is `1.0`.

Main fields:

- `SchemaVersion`
- `Name`
- `Entries`

Each entry supports:

- `EntryId`
- `Name`
- `ValueKind`
- `AddressKind`: `Absolute`, `Pointer`, or `ModulePointer`
- `AbsoluteAddress`
- `BaseAddress`
- `ModuleName`
- `BaseOffset`
- `Offsets`
- `Size`
- `RefreshIntervalMs`
- `Freeze`: `{ "Value": "...", "IntervalMs": 25 }`

Example:

```json
{
        "SchemaVersion": "1.0",
        "Name": "Player Table",
        "Entries": [
                {
                        "EntryId": "health",
                        "Name": "Player Health",
                        "ValueKind": "Int32",
                        "AddressKind": "ModulePointer",
                        "ModuleName": "game.exe",
                        "BaseOffset": 1193046,
                        "Offsets": [16, 32, 8],
                        "Size": 0,
                        "RefreshIntervalMs": null,
                        "Freeze": {
                                "Value": "999",
                                "IntervalMs": 25
                        }
                }
        ]
}
```

## MCP Integration Guide

### Running The MCP Host Manually

Start the stdio MCP server:

```powershell
dotnet run --project src/Overmem.McpServer
```

The server uses stdio transport and keeps runtime state in process memory, including active attachments, freeze state, operation logs, and value-search sessions.

### Adding Overmem To VS Code MCP

This workspace already uses `.vscode/mcp.json` for MCP configuration. Add an `overmem` server entry alongside the existing ones:

```json
{
        "servers": {
                "overmem": {
                        "type": "stdio",
                        "command": "dotnet",
                        "args": [
                                "run",
                                "--project",
                                "D:\\git\\overmem\\src\\Overmem.McpServer"
                        ]
                }
        }
}
```

If you prefer a faster startup after building once, point to the compiled server executable instead of `dotnet run`.

### Integrating cheat-engine-mcp in this workspace

This workspace keeps a dedicated Cheat Engine bridge profile in `.vscode/cheat-engine-mcp.config.json`.

- `.vscode/mcp.json` points to `D:\git\official-cheat-engine\mcp\cheat-engine-mcp.ps1`.
- The `cheat-engine` entry sets `CE_MCP_CONFIG` to the workspace-specific config.
- Runtime logs are written to `%LOCALAPPDATA%\Overmem\logs\cheat-engine-mcp.log`.
- Log rotation is enabled by config (`maxLogSizeBytes`, `maxLogFiles`).

### MCP Tool Surface

Process tools:

- `attach_process`
- `detach_process`
- `list_modules`

Memory tools:

- `list_regions`
- `discover_pointers`
- `resolve_pointer`
- `resolve_module_pointer`
- `scan_pattern`
- `read_value`
- `write_value`

Freeze tools:

- `freeze_value_at_address`
- `freeze_value_at_pointer`
- `freeze_value_at_module_pointer`
- `unfreeze_value`
- `list_frozen_values`

Runtime tools:

- `list_active_attachments`
- `list_recent_operations`

Value-search tools:

- `start_value_search`
- `start_unknown_value_search`
- `refine_value_search`
- `list_value_search_sessions`
- `list_value_search_results`
- `close_value_search_session`

Memory-table tools:

- `load_memory_table`
- `save_memory_table`
- `refresh_memory_table`

### MCP Workflow Example

Typical workflow for a long-lived agent:

1. Call `attach_process` with `processId` or `processName`.
2. Use `list_modules`, `list_regions`, `read_value`, `resolve_pointer`, `discover_pointers`, or `scan_pattern` to discover targets.
3. If needed, start a long-lived value-search session with `start_value_search` and refine it with `refine_value_search` using `Exact`, `NotEqual`, `Changed`, `Unchanged`, `Increased`, `Decreased`, `IncreasedBy`, `DecreasedBy`, `ChangedBy`, or `Between` as appropriate. `Between` requires both `value` (lower bound) and `secondaryValue` (upper bound).
4. If needed, freeze a resolved address with one of the `freeze_value_*` tools.
5. Inspect host state with `list_active_attachments`, `list_recent_operations`, `list_frozen_values`, or `list_value_search_sessions`.
6. Persist or refresh tables with `load_memory_table`, `save_memory_table`, and `refresh_memory_table`.
7. End the session with `detach_process` and optionally `close_value_search_session`.

### MCP Operational Notes

- Long-lived workflows are best done through MCP because the host process retains in-memory state.
- Value-search sessions are lost when the MCP host stops.
- Active freezes are also host-local runtime state.
- The server is local and Windows-only.

## Constraints And Non-Goals

- Windows only.
- User mode only.
- No driver or kernel support.
- No anti-cheat bypass or protected-process bypass.
- No code injection, hook engine, or patching workflows yet.
- No UI in the current repository scope.
