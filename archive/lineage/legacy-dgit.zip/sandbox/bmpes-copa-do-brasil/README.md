# Sandbox BMPES Calendarios

Este diretório mantém um recorte mínimo, dentro do repositório, para reproduzir a superfície do `MOD 14.lua` do BMPES que já foi confirmada para calendários em memória.

## Conteúdo

1. `modules/MOD 14.lua`
   - recorte derivado do módulo ativo encontrado em `C:\Program Files (x86)\Steam\steamapps\common\eFootball PES 2021.bmpes\modules\MOD 14.lua`
   - preserva o unlock interno (`mod16`), a escrita do bloco do Brasileirão (`mod14`) e a escrita do bloco `ORIGINAL_21 -> COPA_DO_BRASIL` (`mod15`)
2. `sider.ini.snippet.txt`
   - linha mínima para carregar o módulo no Sider

## Dependências reais

O módulo reduzido não usa `require`, `dofile` ou outros arquivos Lua auxiliares.

As dependências reais para execução são apenas as superfícies padrão do Sider já fornecidas no runtime:

- `memory.search_process`
- `memory.read`
- `memory.write`
- `log`

## O que ficou fora de propósito

1. `modules/MOD 15.lua` standalone
   - no BMPES analisado, ele só altera regras de partida (`set_match_settings`)
   - não é dependência do patch da Copa do Brasil
2. `modules/MOD 16.lua` standalone
   - estava vazio na instalação analisada e o Sider o descartava
   - o `mod16` relevante já está embutido em `modules/MOD 14.lua`
3. `modules/FWC_____Calendarios.lua`
   - altera calendário da FWC/Copa do Mundo, não da Copa do Brasil
4. remaps auxiliares de país
   - os blocos `mod17` e `mod18` continuam fora do sandbox
   - eles não são a origem primária da troca do calendário da Copa do Brasil nem do bloco do Brasileirão
5. Copa Libertadores
   - ainda não há um bloco portado para Libertadores dentro deste arquivo
   - na instalação BMPES analisada, o owner do calendário da Libertadores não apareceu como uma escrita equivalente dentro do `MOD 14.lua`
6. entradas `data => mesma data` do round `54`
   - foram neutralizadas no `COPA_DO_BRASIL` do sandbox
   - o payload mantém o mesmo tamanho, mas as duas últimas trincas agora são zeradas em vez de reapontar para `2026-03-21` e `2026-03-28`

## Relação com a documentação

O racional da seleção deste sandbox está documentado em:

- `docs/pes2021-bmpes-copa-do-brasil-calendar-modules.md`

## Uso

1. copiar `modules/MOD 14.lua` para a pasta `modules` do Sider alvo
2. adicionar a linha do snippet ao `sider.ini`
3. acompanhar o `sider.log` para confirmar a sequência:
   - `Patch BMPES aplicado corretamente`
   - `Brasileirao aplicado`
   - `Copa do Brasil aplicada`

## Observação

Este sandbox preserva, sem otimização estrutural, a fatia do `MOD 14.lua` necessária para o bloco do Brasileirão e para a Copa do Brasil. A única divergência funcional deliberada em relação ao bloco BMPES completo é a neutralização das duas entradas finais `data => mesma data` do round `54` em `COPA_DO_BRASIL`. A superfície da Libertadores continua fora deste recorte.