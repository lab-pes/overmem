# BMPES: modulos que alteram o calendario da Copa do Brasil

## Escopo

Esta nota documenta a analise feita diretamente na instalacao:

- `C:\Program Files (x86)\Steam\steamapps\common\eFootball PES 2021.bmpes`

O objetivo foi identificar quais modulos realmente alteram o calendario da Copa do Brasil no runtime atual, separando:

- modulo ativo
- pre-requisito de unlock
- modulo com nome parecido mas funcao diferente
- pasta de dados presente no disco, mas nao montada no `livecpk`

## Evidencia usada

Foram cruzadas quatro superficies:

1. `sider.ini`
2. `modules/*.lua`
3. `sider.log`
4. roots `cpk.root` ativos e pastas de dados `pesdb`

## Resultado principal

No runtime atual, quem efetivamente altera o calendario da Copa do Brasil e `modules/MOD 14.lua`.

Esse arquivo contem um fluxo interno unico com quatro partes relevantes:

1. `mod16`
   - faz o unlock interno do patch BMPES
   - sem esse passo, os demais blocos nao executam
2. `mod14`
   - reescreve um bloco associado ao calendario do Brasileirao
3. `mod15`
   - reescreve o bloco `ORIGINAL_21` para `COPA_DO_BRASIL`
   - esta e a escrita diretamente ligada ao calendario da competicao `31`
4. `mod17/mod18`
   - fazem substituicoes auxiliares de ids/paises
   - nao sao a origem primaria do calendario da Copa do Brasil

Os pontos centrais dentro de `modules/MOD 14.lua` sao:

- `local COPA_DO_BRASIL =`
- `local function mod15(ctx)`
- `local addr = memory.search_process(ORIGINAL_21)`
- `memory.write(addr, COPA_DO_BRASIL)`
- `log("Copa do Brasil aplicada ✔")`

## Confirmacao em runtime

O `sider.ini` carrega explicitamente:

- `lua.module = "MOD 14.lua"`
- `lua.module = "MOD 15.lua"`
- `lua.module = "MOD 16.lua"`

Mas o `sider.log` mostra que o trabalho real da Copa acontece dentro de `MOD 14.lua`:

1. `Loading module: MOD 14.lua ...`
2. `Executando MOD 16.lua primeiro (obrigatorio)...`
3. `Patch BMPES aplicado corretamente`
4. `Executando MOD 14.lua...`
5. `Brasileirao aplicado`
6. `Executando MOD 15.lua...`
7. `Copa do Brasil aplicada`
8. `Modulo unico finalizado`

Ou seja: o arquivo `MOD 14.lua` concentra o unlock e a escrita do bloco da Copa do Brasil.

## Falsos positivos descartados

### `modules/MOD 15.lua`

Apesar do nome, esse arquivo standalone nao e o patch do calendario da Copa do Brasil.

Ele apenas registra `set_match_settings` e faz ajuste de regras de partida, com foco em:

- `options.substitutions = 5`

Ele aparece no log como modulo inicializado, mas seu papel e de regras de partida, nao de remapeamento de calendario.

### `modules/MOD 16.lua`

O arquivo standalone `modules/MOD 16.lua` esta vazio na instalacao analisada.

O `sider.log` confirma isso com:

- `PROBLEM: Lua module (MOD 16.lua) must return a table. Skipping it`

Portanto, o `MOD 16` relevante para a Copa nao e esse arquivo vazio, e sim a funcao interna `mod16` definida dentro de `modules/MOD 14.lua`.

### `modules/FWC_____Calendarios.lua`

Esse modulo tambem altera calendario em memoria, mas para a Copa do Mundo/FWC.

Os sinais disso sao:

- nomes internos `FWC_Calendario`
- estruturas `Group_Matchs`
- fluxo de `Round16`

Ele nao e a origem do calendario da Copa do Brasil.

## Pasta isolada `2026 MOD Copa do Brasil`

A instalacao contem a pasta:

- `2026 MOD Copa do Brasil`

Ela possui arquivos proprios em:

- `common\etc\pesdb\Competition.bin`
- `common\etc\pesdb\CompetitionRegulation.bin`

Esses arquivos nao sao identicos aos do banco ativo em:

- `BMPES\Servidor de Database\common\etc\pesdb\Competition.bin`
- `BMPES\Servidor de Database\common\etc\pesdb\CompetitionRegulation.bin`

Porem, no runtime observado, essa pasta isolada nao aparece montada nos `cpk.root` ativos do `sider.ini`.

O banco efetivamente montado e o `BMPES\Servidor de Database`, nao a pasta isolada `2026 MOD Copa do Brasil`.

Implicacao pratica:

- existe um conjunto de dados de Copa do Brasil no disco
- mas a alteracao ativa observada no jogo atual vem do patch em memoria de `modules/MOD 14.lua`
- nao ha evidencia, neste runtime, de que a pasta isolada da Copa esteja sendo usada diretamente para dirigir o calendario

## Decodificacao do bloco `COPA_DO_BRASIL`

O bloco literal `COPA_DO_BRASIL` em `modules/MOD 14.lua` tem `168` bytes.

Quando lido como `14` trincas `UInt32`, ele fica neste formato:

- campo `A`: alterna `0/1` e funciona como slot interno do par
- campo `B`: `dayOffset` real
- campo `C`: codigo de round/fase usado pelo calendario da competicao

O `dayOffset` usa como ancora `2026-01-01`.

Exemplo:

- `(0, 44, 46)` => slot `0`, data `2026-02-14`, round `46`
- `(0, 339, 53)` => slot `0`, data `2026-12-06`, round `53`

O bloco original e o bloco patchado ficam assim:

| Round code | Datas no bloco `ORIGINAL_21` | Datas no bloco `COPA_DO_BRASIL` | Materializacao observada |
| --- | --- | --- | --- |
| `46` | `2026-01-17`, `2026-01-21` | `2026-02-14`, `2026-02-27` | confirmada em `calendar-array-map-2026.json` |
| `47` | `2026-01-24`, `2026-02-01` | `2026-05-07`, `2026-05-13` | confirmada em `calendar-array-map-2026.json` |
| `48` | `2026-02-07`, `2026-02-14` | `2026-08-03`, `2026-08-08` | confirmada em `calendar-array-map-2026.json` |
| `51` | `2026-02-21`, `2026-02-28` | `2026-09-07`, `2026-09-19` | confirmada em `calendar-array-map-2026.json` |
| `52` | `2026-03-07`, `2026-03-14` | `2026-10-15`, `2026-10-21` | confirmada em `calendar-array-map-2026.json` |
| `53` | `2026-03-21`, `2026-03-28` | `2026-11-21`, `2026-12-06` | no mapa anual observado, so `2026-12-06` materializa com `1` jogo |
| `54` | `2026-03-21`, `2026-03-28` | `sem data`, `sem data` | nao aplicavel: o literal `COPA_DO_BRASIL` zera as duas entradas finais |

Leitura operacional dessa tabela:

1. o patch nao move apenas um jogo isolado; ele reescreve uma pequena tabela de datas por round code
2. os rounds `46`, `47`, `48`, `51` e `52` batem exatamente com a agenda observada da competicao `31`
3. o round `53` foi empurrado para `2026-11-21` e `2026-12-06`, mas no mapa anual observado so `2026-12-06` aparece materializado como partida da competicao `31`
4. o `54` nao foi preservado: o literal `COPA_DO_BRASIL` zera as duas entradas finais, entao ele nao faz parte das `12` datas ativas da troca

Em outras palavras, a opcao 1 decodificada mostra que o `MOD 14.lua` remapeia a Copa do Brasil para uma janela anual tardia:

- fevereiro: `46`
- maio: `47`
- agosto: `48`
- setembro: `51`
- outubro: `52`
- novembro/dezembro: `53`

e zera as duas entradas finais que antes carregavam o antigo `54`.

## Atualizacao com runtime limpo (2026-05-27)

As leituras posteriores no runtime limpo do `PES2021.exe`, sem o patch BMPES carregado, mudaram a interpretacao arquitetural desse bloco.

O ponto principal e este:

- o BMPES nao cria o `ORIGINAL_21`
- o `ORIGINAL_21` ja existe no jogo base, em `0x14299BEDC` (`RVA 0x299BEDC`)
- o patch `mod15` sobrescreve um trecho de uma zona compacta compartilhada por varias competicoes

Essa zona compacta tem duas familias de codificacao no mesmo bairro local:

- `slot-day-round`
- `day-round-slot`

No sweep ampliado da janela local (`7200` bytes), foram encontrados:

- `241` pares estruturados
- `97` `dayOffset`s distintos
- `143` pares com correspondencia de competicao no runtime limpo

Os maiores hits nessa zona nao sao da Copa do Brasil, e sim de uma superficie compartilhada de agenda:

- `52` / `JAPAO\J1 LEAGUE`: `39`
- `29` / `BRASIL\BRASILEIRO SERIE A`: `38`
- `163` / `BRASIL\BRASILEIRO SERIE B`: `38`
- `31` / `BRASIL\COPA DO BRASIL`: `11` no runtime limpo
- `126` / `COLOMBIA\COPA BETPLAY`: `11`
- `68` / `CHILE\COPA CHILE`: `7`

Isso significa que o `ORIGINAL_21` nao deve mais ser tratado como uma tabela exclusivamente da Copa do Brasil. No estado limpo validado, ele e apenas um recorte Copa-like dentro de uma infraestrutura compacta maior.

Os nomes das competicoes exigem uma ressalva adicional: o bloco compacto nao carrega `CompetitionName`, e o registro principal da agenda tambem nao. O que existe na memoria principal e o `CompetitionCode`; o nome e resolvido externamente por mapa. Para o ambiente atual do usuario, o mapa canonico e o `GOGOSZ\Menu Server\map_competitions.txt`.

### Competition codes da zona compacta sob Gogosz

| CompetitionCode | Nome no Gogosz | Datas no `PairMap` | Jogos no `PairMap` |
| --- | --- | ---: | ---: |
| `29` | `BRASIL\BRASILEIRO SERIE A` | `38` | `380` |
| `31` | `BRASIL\COPA DO BRASIL` | `11` | `77` |
| `52` | `JAPAO\J1 LEAGUE` | `38` | `390` |
| `54` | `URUGUAI\COPA AUF URUGUAY` | `4` | `15` |
| `55` | `JAPAO\JFA CHAMPIONSHIP` | `3` | `14` |
| `67` | `CHILE\CAMPEONATO BETSSON` | `2` | `16` |
| `68` | `CHILE\COPA CHILE` | `7` | `29` |
| `120` | `CHINA\CSL SUPERLEAGUE` | `2` | `24` |
| `126` | `COLOMBIA\COPA BETPLAY` | `10` | `39` |
| `127` | `CHINA\CFA CUP` | `2` | `10` |
| `162` | `ARABIA SAUDITA\SAUDI PRO LEAGUE` | `3` | `36` |
| `163` | `BRASIL\BRASILEIRO SERIE B` | `38` | `380` |
| `164` | `ARABIA SAUDITA\KINGS CUP` | `3` | `12` |
| `166` | `URUGUAI\PRIMEIRA DIVISAO` | `11` | `96` |
| `168` | `COLOMBIA\LIGA BETPLAY` | `19` | `190` |
| `169` | `COLOMBIA\LIGA BETPLAY` | `19` | `190` |

O artefato `docs/pes2021-original21-live-competition-map-2026-05-27.json` foi exportado antes dessa correcao de nomenclatura. Portanto, os seus `CompetitionCode` continuam validos, mas os `CompetitionName` antigos nao devem ser tratados como canonicos quando o runtime ativo for Gogosz.

Esse total de `11` para a competicao `31` vale apenas para o mapeamento do runtime limpo. Ele nao e a mesma coisa que a agenda-alvo do patch BMPES: o literal `COPA_DO_BRASIL` tem `12` datas ativas (`46`, `47`, `48`, `51`, `52`, `53`) e zera as duas entradas finais que antes carregavam o antigo `54`.

O recorte mais importante para a analise da Copa ficou assim no runtime limpo:

- o resolvedor atual atribuiu `31` a `dayOffset 16, 20, 23, 31, 37, 44, 51, 58, 65, 72, 79`
- `68` compartilha a mesma familia `slot-day-round` em `16, 20, 51, 58, 65, 72, 86`
- `126` aparece na familia espelhada `day-round-slot` em `46, 48, 111, 125, 149, 167, 251, 272, 305, 307`

Isso nao e a mesma coisa que a tabela-base codificada em `ORIGINAL_21`.

Quando o literal `ORIGINAL_21` e decodificado diretamente, ele contem `12` datas distintas para esse slice Copa-like:

- `2026-01-17`
- `2026-01-21`
- `2026-01-24`
- `2026-02-01`
- `2026-02-07`
- `2026-02-14`
- `2026-02-21`
- `2026-02-28`
- `2026-03-07`
- `2026-03-14`
- `2026-03-21`
- `2026-03-28`

alem de dois placeholders adicionais de `round 54` que repetem `2026-03-21` e `2026-03-28`.

Consequencia pratica para o tail do `ORIGINAL_21`:

- `2026-03-21` / `dayOffset 79` / `round 53` materializa `31`
- `2026-03-28` / `dayOffset 86` / `round 53` materializa `68`
- os pares `round 54` desse tail nao materializaram nenhuma competicao no runtime limpo observado

Isso nao invalida a leitura da tabela-base com `12` datas distintas. O que o runtime limpo mostrou foi apenas que a atribuicao heuristica por competicao no tail ficou divergente: `79|53` caiu em `31`, enquanto `86|53` caiu em `68`.

## Revalidacao do resolvedor

A decodificacao mecanica do slice foi revalidada a partir de uma leitura independente do literal `ORIGINAL_21` em `MOD 14.lua`.

Resultado:

- os `14` registros brutos do literal bateram `14/14` com o `PairMap` nos campos `slot`, `dayOffset`, `round` e `date`
- o risco remanescente do resolvedor nao esta no calculo desses campos
- o risco real esta na etapa heuristica de associacao por competicao

No sweep ampliado do `PairMap`, isso aparece de forma mensuravel:

- `241` pares totais
- `58` pares com mais de uma competicao materializada na mesma combinacao `date + round`
- `98` pares sem nenhuma competicao materializada no dump anual observado

No slice `ORIGINAL_21`, a ambiguidade fica concentrada assim:

- `16|46`, `20|46`, `51|51`, `58|51`, `65|52` e `72|52` aparecem tanto em `31` quanto em `68`
- `79|53` cai apenas em `31`
- `86|53` cai apenas em `68`
- as duas entradas finais zeradas do patch nao entram na conta das `12` datas ativas da Copa do Brasil

## Quem referencia essa zona

As buscas diretas de ownership em memoria ficaram negativas:

1. `discover-pointers` no inicio do run retornou `0` candidatos
2. `scan-value Int64` para o VA exato do `ORIGINAL_21` retornou `0` matches
3. `scan-value Int32` para o offset relativo `0x299BDBC` tambem retornou `0` matches

A explicacao veio da verificacao estatica do executavel:

- o bairro do `ORIGINAL_21` cai em `.idata`
- o `PES2021.exe` o alcanca via referencias RIP-relative na `.text`
- a navegacao e por codigo estatico do modulo, nao por ponteiros heap-like armazenados no processo

Tres funcoes pequenas imediatamente relevantes para o entorno do `ORIGINAL_21` foram validadas:

- `0x1589DCE-0x1589E07` -> bloco `0x299BEE0`
- `0x1589E6E-0x1589EA7` -> bloco `0x299BF90`
- `0x1589F0E-0x1589F47` -> bloco `0x299C020`

Elas seguem o mesmo padrao:

- carregam o inicio de um bloco compacto em `RBX`
- iteram em passos de `0x0C` bytes
- chamam o mesmo helper em `0x158B7C0`

No estado atual da investigacao, a melhor leitura e que esse bairro pertence a uma familia de blocos compactos de agenda, todos tratados como arrays homogeneos de entradas de `12` bytes.

## Documentacao complementar

Os achados novos do runtime limpo foram consolidados em:

- `docs/pes2021-original21-clean-runtime-compact-zone.md`
- `docs/pes2021-original21-live-competition-map-2026-05-27.json`

## Conclusao operacional

No estado atual da instalacao BMPES analisada:

1. o modulo responsavel pela alteracao ativa do calendario da Copa do Brasil e `modules/MOD 14.lua`
2. a escrita especifica da Copa esta no bloco interno `mod15`, que aplica `ORIGINAL_21 -> COPA_DO_BRASIL` sobre uma zona compacta preexistente do jogo base
3. a funcao interna `mod16` do mesmo arquivo atua como pre-requisito de unlock
4. `modules/MOD 15.lua` e `modules/MOD 16.lua` standalone nao sao a origem do patch do calendario da Copa
5. `modules/FWC_____Calendarios.lua` altera outro calendario, da FWC/Copa do Mundo
6. a pasta `2026 MOD Copa do Brasil` contem dados distintos, mas nao foi observada como root ativo de `livecpk` neste runtime

## Replica no repositório

Foi criado um sandbox de trabalho em:

- `sandbox/bmpes-copa-do-brasil/`

Conteúdo criado:

1. `sandbox/bmpes-copa-do-brasil/modules/MOD 14.lua`
   - recorte do módulo BMPES ativo observado na instalação analisada
   - agora preserva `mod16`, `mod14` e `mod15`
   - `mod14` reaplica o bloco do calendário do Brasileirão observado no `MOD 14.lua` original do BMPES
   - `mod15` continua sendo a escrita diretamente ligada ao bloco `ORIGINAL_21 -> COPA_DO_BRASIL`
2. `sandbox/bmpes-copa-do-brasil/sider.ini.snippet.txt`
   - linha mínima para carregar o módulo no Sider
3. `sandbox/bmpes-copa-do-brasil/README.md`
   - nota local com dependências reais, exclusões deliberadas e uso esperado

Critério dessa réplica:

- manter apenas a superfície do `MOD 14.lua` que já tem ownership confirmado para calendário no BMPES analisado
- preservar o bloco do Brasileirão porque ele mora no mesmo arquivo e já tem um `search_process -> write` inequívoco no original
- continuar deixando fora os remaps auxiliares de país (`mod17/mod18`)
- não arrastar `MOD 15.lua` standalone, `MOD 16.lua` standalone ou módulos FWC, porque eles não são dependências reais do patch ativo analisado

Observação:

- o arquivo completo do BMPES continua existindo apenas na instalação externa analisada
- o sandbox do repositório agora cobre Copa do Brasil e o bloco do Brasileirão do mesmo `MOD 14.lua`
- a superfície da Libertadores ainda não foi portada para esse arquivo, porque ela não apareceu como um bloco de calendário equivalente dentro do `MOD 14.lua` original
- a investigação live posterior encontrou a Libertadores em outro bloco compacto estático, irmão do bairro do `ORIGINAL_21`, e não dentro desta réplica do `MOD 14.lua`