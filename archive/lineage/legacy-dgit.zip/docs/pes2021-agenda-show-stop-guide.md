# Guia de análise: agenda anual e regra de `show + stop` no PES 2021

## Objetivo

O objetivo atual não é mais "achar datas especiais".

O objetivo é reconstruir a lógica pela qual o jogo:

1. reconhece que uma data tem um evento relevante
2. decide se essa data deve aparecer para o jogador
3. decide se a simulação deve parar nessa data

Em termos de negócio, queremos sair de:

- `raw marker`

para:

- `evento semântico`
- `data visível ao jogador`
- `stop-day real`

## O que já sabemos

Hoje faz mais sentido falar em um `calendar` único observado por superfícies
estruturais diferentes:

1. `fixture calendar array`
  - base de partidas e rodadas
  - aceita varias competicoes no mesmo dia

2. `day marker layer`
  - marcadores de dia, placeholders, headers e pontes de agenda

3. `runtime day payload`
  - a agenda efetivamente carregada para a tela e para o fluxo de avanço do tempo

Também já sabemos que essas superfícies não são equivalentes:

- há dias que existem semanticamente no `day marker layer`, mas não aparecem como partida materializada
- há dias que aparecem no `runtime day payload` por projeção/runtime
- há dias que já foram inferidos por heurística antiga, mas não têm materialização própria no save-side bruto

Exemplo importante:

- `2026-12-01`
  - jogo de campeonato materializado no calendario
  - tratar como `calendar-match-day`, nao como evento anual de premio
- `2026-12-02`
  - anuncio do premio de melhor jogador do mundo
  - pausa real e linha visivel confirmadas; normalizar como evento semantico especifico (`semantic-event-day`), nao como familia generica de dezembro
- `2026-12-05`
  - controle negativo para essa normalizacao
  - nao promover a stop-day sem linha/evento materializado
- `2026-12-11`, `2026-12-13`
  - controles negativos do heurístico antigo
  - tratá-los como falsos positivos até nova evidência

Bloco de fim de temporada agora validado manualmente na ML/UI:

- `2026-12-29`
  - `Anúncio do Prêmio de melhor jogador da Ásia`
- `2026-12-30`
  - `Anúncio do Prêmio de melhor da América do Sul`
- `2026-12-31`
  - `Último dia da temp.`

Isso transforma `29/12-31/12` em um bloco semântico ordenado e confirmado, não apenas em uma vizinhança conveniente de datas especiais.

## Princípio de trabalho

Toda análise deve respeitar a seguinte ordem de confiança:

1. `raw save-side evidence`
   - bytes, headers, counts, items, records

2. `cross-check with visible UI behavior`
   - aparece para o usuário?
   - para a simulação?

3. `runtime-only evidence`
   - clusters, caches, projeções, estado de navegação

4. `legacy reader heuristics`
   - só usar quando explicitamente marcadas como heurística

Se houver conflito entre:

- nome herdado do reader antigo
- dado bruto atual do save/processo

o dado bruto vence, e o nome herdado deve ser rebaixado para hipótese ou heurística legada.

## Perguntas que estamos tentando responder

A análise atual tenta responder, nesta ordem:

1. qual é a fonte bruta do evento?
2. esse evento é visível ao jogador?
3. esse evento para a simulação?
4. qual camada faz a projeção entre marker bruto e dia efetivo visível?
5. qual regra faz o motor decidir `show + stop`?

As saídas do serviço já expõem `source role`, `visibility`, `stop-state` e `dayRole`; use esses campos para separar `main-backed`, `secondary-backed`, `runtime-projected`, `calendar-match-day` e `semantic-event-day` em vez de inferir isso só pelo texto.

## Método de análise

### Etapa 1: validar a data no `fixture calendar array`

Pergunta:

- existe partida ou agenda materializada no `fixture array` para a data?

Ferramentas:

- `pes2021_dump_calendar_date`
- `pes2021_calendar_summary`

Resultado esperado:

- confirmar se a data existe como fixture/competição materializada

Leitura:

- se existir no `fixture array`, o dia já tem forte evidência de agenda objetiva
- se não existir, isso não encerra a análise; o dia pode viver no `day marker layer` ou no `runtime day payload`

### Etapa 2: validar a data no `day marker layer`

Pergunta:

- existe `DayEntry` real para a data?
- há headers?
- há `count/items`?

Ferramentas:

- `pes2021_find_secondary_calendar_base_by_date`
- `pes2021_dump_secondary_calendar_day`

Resultado esperado:

- identificar se a data tem:
  - header semântico
  - placeholder
  - bridge para `d+1`
  - payload de itens
  - nada

Leitura:

- `header + count/items`
  - dia fortemente materializado
- `header sem items`
  - marker semântico ou placeholder
- `nada`
  - provavelmente não é uma data bruta do `day marker layer`

### Etapa 3: classificar a semântica do dia

Pergunta:

- o dia já corresponde a um evento conhecido?

Ferramentas:

- `pes2021_inventory_annual_events`
- `pes2021_classify_runtime_day_variant`

Resultado esperado:

- rotular o dia como:
  - evento confirmado
  - candidato
  - marker-fonte
  - projeção legada
  - desconhecido real

Regra:

- se o nome depender de reader antigo e não houver evidência save-side atual suficiente, usar rótulo fraco
- exemplo:
  - `hidden_competition_projection_source_marker`
  - e não semântica forte de competição/final

### Etapa 4: cruzar com o comportamento da UI

Pergunta:

- a data aparece para o jogador?
- o calendário para nela?

Fonte:

- observação manual no jogo
- screenshots
- navegação com o cursor

Resultado esperado:

- classificar o dia em uma destas classes:
  - `visible + stop`
  - `visible + no stop`
  - `not visible + no stop`
  - `raw marker only`
  - `runtime projection only`

Observação:

- esta etapa é decisiva
- sem ela, o dado bruto sozinho não basta para afirmar `show + stop`

### Etapa 5: medir o runtime do dia selecionado

Pergunta:

- qual cache/estrutura o jogo carrega quando o cursor está naquela data?

Ferramentas:

- `pes2021_scan_runtime_day_index_clusters`
- `pes2021_dump_runtime_day_payload_family`
- `pes2021_compare_runtime_day_payload_family`
- `pes2021_dump_runtime_day_payload_cluster_detail`
- `pes2021_analyze_runtime_day_payload_cluster`

Resultado esperado:

- separar:
  - ruído global
  - cache privado de agenda visível
  - projeção do dia selecionado

Leitura:

- datas visíveis e stop costumam ter melhor ancoragem semântica no `secondary`
- datas projetadas/invisíveis podem ter runtime forte, mas sem evidência save-side local

### Etapa 6: comparar dias vizinhos e dias-controle

Pergunta:

- o que muda entre um dia visível/stop e um dia sem stop?

Comparações úteis:

1. `dia anterior` vs `dia alvo` vs `dia seguinte`
2. `visible + stop` vs `raw marker only`
3. `visible + stop` vs `runtime projection only`

Exemplos de bom uso:

- `28/12` vs `29/12` vs `30/12`
- `29/12` vs `30/12` vs `31/12`
- `10/12` vs `11/12` vs `12/12`

Objetivo:

- descobrir o que é:
  - marker bruto
  - projeção do reader/UI
  - stop-day real do jogador

## Como decidir se vale continuar numa trilha

Continuar na trilha se:

1. a data tem evidência nova em alguma camada
2. a data ajuda a separar `raw marker` de `visible stop`
3. a comparação com um controle próximo parece limpa

Encerrar ou rebaixar a trilha se:

## Estado validado atual para Libertadores tardia

No runtime atual do patch do usuário, a família tardia da Libertadores já está
suficientemente ancorada em três superfícies diferentes:

- `2026-03-19`
  - `secondary`: `0x0025 + 0x003F`
  - validação manual de ML/UI: dia seguinte de `Conmebol Libertadores Fase de grupos Jornada 2`
- `2026-04-16`
  - `secondary`: `0x0027 + 0x003F`
  - validação manual de ML/UI: dia seguinte de `Conmebol Libertadores Fase de grupos Jornada 4`
- `2026-06-13`
  - `secondary`: `0x000D + 0x003F`
  - validação manual de ML/UI: `Conmebol Libertadores Oitavas de final Jogo de ida`

Atualização estrutural adicional no runtime live:

- além de `secondary` e `runtime`, agora existe uma âncora estática no corredor compacto do módulo em `0x1429991BC` (`RVA 0x29991BC`), `11552` bytes antes do `ORIGINAL_21`
- nesse corredor, a fase de grupos aparece em um sub-bloco `slot-day-round` com as datas `2026-03-04`, `2026-03-18`, `2026-03-25`, `2026-04-15`, `2026-04-29` e `2026-05-20`
- imediatamente antes dele, um sub-bloco irmão `round-slot-day` ancora datas tardias da mesma família: `2026-06-13`, `2026-08-12`, `2026-09-16`, `2026-09-23`, `2026-10-24`, `2026-10-31`, `2026-11-21` e `2026-11-28`
- portanto, `2026-06-13` não depende mais apenas do par de headers `0x000D + 0x003F`; agora ele também tem uma âncora compacta estática no mesmo corredor estrutural da fase de grupos
- o que ainda permanece em aberto é a semântica exata dos `round` compactos tardios (`46`, `51`, `52`, `53`, `54`); por enquanto, só `2026-06-13` está validada manualmente como `Oitavas de final Jogo de ida`

Também já está validado que:

- `0x000D + 0x003F` não é assinatura exclusiva da Libertadores
- `2026-12-30` compartilha essa mesma dupla de headers em um evento semântico de fim de ano
- por isso, `0x000D + 0x003F` sozinho não pode ser promovido a placeholder forte da Libertadores sem contexto da data
- no inventário anual, o uso seguro dessa dupla exige contexto do dia, hoje representado por atividade adicional no `main`

Em termos de negócio, a leitura agora é mais precisa:

- `2026-03-19` e `2026-04-16` não são partidas visíveis da Libertadores em si, mas dias imediatamente posteriores a jornadas confirmadas da fase de grupos
- `2026-06-13` é um dia de agenda real da Libertadores, não apenas um marcador abstrato ou um controle técnico
- portanto, `2026-06-13` volta a ser o caso principal para fechar equivalência funcional com o BMPES, enquanto `2026-03-19` e `2026-04-16` funcionam como controles tardios de pós-evento

## Leitura atual do `runtime day payload`

Os achados mais estáveis até aqui são:

- `2026-03-19` e `2026-04-16`
  - classificam como `no_games_runtime`
  - apresentam um único cluster `Private/ReadWrite`
  - família dominante `528-like`
  - preview decodificado majoritariamente em fixtures genéricos de outras competições, não em uma família dedicada da Libertadores
- `2026-06-13`
  - continua semanticamente relevante para a Libertadores
  - está manualmente confirmado como dia real de `Oitavas de final Jogo de ida`
  - mas o `runtime payload` se abre em múltiplos clusters `528-like`
  - o preview mistura competições e datas futuras genéricas
  - a leitura atual é de caches/projeções genéricos, não de uma família codificada exclusiva da competição

Em termos práticos:

- `secondary` ainda é a melhor âncora para relevância semântica
- `main` continua sendo a melhor âncora para materialização objetiva do dia
- `runtime payload` deve ser usado como apoio diagnóstico até que um cluster específico prove relação causal com `show + stop`

## Comparação temporal de clusters

O comando `pes2021_compare_runtime_day_payload_family` existe para comparar `dia-1`, `dia`, `dia+1`, mas em dias multi-cluster ele não deve depender apenas da ordem ordinal dos clusters do mesmo stride.

A regra atual de comparação é:

1. casar clusters do mesmo stride por sobreposição de valores de preview
2. só usar fallback por ordinal quando não houver sobreposição útil

Isso é importante no caso de `2026-06-13`, porque vários clusters `528-like`
podem mudar de ordem entre capturas mantendo praticamente o mesmo conteúdo.
Sem esse casamento por similaridade, a análise temporal tende a produzir falsos deltas.

Também já está validado no código que o preview de cada cluster precisa respeitar o fim da região de memória onde o hit foi encontrado.
Sem esse corte, um cluster muito próximo da borda da região pode disparar leituras parciais e poluir o diagnóstico do comando sem agregar informação útil ao preview.

Na coleta live, ainda existe uma segunda fonte de ruído que não invalida o JSON final:

- o scanner global pode encontrar regiões voláteis onde uma leitura de chunk falha com `Win32=299`
- esses erros aparecem no `stderr`
- por isso, quando o objetivo é gerar artefato consumível de comparação/classificação, a captura correta é `stdout` puro

Exemplo prático:

```powershell
.\src\Overmem.Cli\bin\Debug\net8.0\Overmem.Cli.exe pes2021-compare-runtime-day-payload-family ... 1> compare.txt 2> $null
```

Esse formato preserva o JSON mesmo quando o processo registra falhas transitórias de leitura durante o scan amplo.

## Situação atual do contraste `06-13` versus `12-30`

Os artefatos limpos mais recentes confirmam que:

- `2026-03-19`
  - continua sendo a melhor linha de base limpa da família tardia
  - classifica como `no_games_runtime`
  - produz `1` cluster `528-like`
  - esse cluster aparece como `isolated`, sem casamento temporal útil com `d-1` ou `d+1`
- `2026-06-13`
  - produz `6` clusters `528-like`
  - classifica como `unknown_runtime`, embora a semântica continue fortemente ancorada como Libertadores tardia
  - o resumo temporal marca `1` match com `d-1`, `6` matches com `d+1`, `1` cluster estável e `0` isolados
  - o compare bruto ainda encontra majoritariamente `unmatched` ou `stride-ordinal-fallback`
  - os contadores de overlap de preview permanecem em `0`
- `2026-12-30`
  - produz `5` clusters `528-like`
  - classifica como `unknown_runtime`, com semântica forte de anúncio de prêmio de fim de ano
  - o resumo temporal marca `0` matches com `d-1`, `3` matches com `d+1`, `0` clusters estáveis e `2` isolados
  - também cai majoritariamente em `unmatched` ou `stride-ordinal-fallback`
  - os contadores de overlap de preview permanecem em `0`

Leitura atual:

- o compare bruto já é confiável como artefato
- mas, sozinho, ele ainda não separa o `0x000D + 0x003F` da Libertadores tardia do controle semântico de `2026-12-30`
- o discriminador mais promissor agora é o resumo temporal da classificação, não o compare bruto isolado
- `2026-06-13` se comporta como um caso mais contínuo em runtime do que `2026-12-30`, porque mantém `0` clusters isolados e pelo menos `1` cluster estável
- esse `1` cluster estável ainda deve ser tratado com cautela: no compare atual ele só sobrevive por fallback ordinal, não por overlap real de preview
- a validação manual da ML/UI resolve a semântica da data `2026-06-13`, mas não resolve sozinha qual cluster é fonte e qual cluster é derivado
- por isso, a próxima evidência útil continua sendo detalhamento local dos clusters de `2026-06-13` e comparação com o conjunto mínimo de estruturas que o BMPES realmente precisa tocar

## Bloco validado de fim de temporada `29/12-31/12`

No fim da temporada 2026, o trio abaixo já está confirmado manualmente como sequência semântica real da UI:

- `2026-12-29`
  - `Anúncio do Prêmio de melhor jogador da Ásia`
- `2026-12-30`
  - `Anúncio do Prêmio de melhor da América do Sul`
- `2026-12-31`
  - `Último dia da temp.`

Leitura operacional:

- `2026-12-30` não deve mais ser tratado apenas como um controle abstrato para o header `0x000D + 0x003F`
- ele pertence a um bloco anual visível e ordenado, com contexto claro em `d-1` e `d+1`
- `2026-12-29-31` agora formam o melhor bloco de controle positivo para eventos anuais não-Libertadores no fim da temporada
- isso reforça o uso de `2026-12-30` como contraste semântico forte contra `2026-06-13`, não como simples ruído de calendário

Estado técnico atual do bloco:

- `2026-12-29`
  - `secondary`: headers `32, 44, 63`, `Count = 0`
  - `main`: vazio (`TotalCompetitions = 0`, `TotalMatches = 0`)
- `2026-12-30`
  - `secondary`: headers `13, 63`, `Count = 0`
  - `main`: a sonda isolada de `dump-calendar-date` ainda ficou lenta o suficiente para exigir reroteamento da análise por `secondary` e `runtime`
- `2026-12-31`
  - `secondary`: headers `26, 14, 17, 63`
  - `Count = 0xFFFFFFFF` com payload real, fugindo fortemente do padrão de `29/12` e `30/12`

Implicação atual:

- `2026-12-31` já se comporta como um evento terminal/sentinel de temporada, não como apenas mais um anúncio anual vazio
- `2026-12-29` e `2026-12-30` continuam parecendo dias semanticamente visíveis sem materialização simples em `main`
- o bloco anual não é uniforme do ponto de vista estrutural, então ele deve ser usado como contraste positivo ordenado, não como uma única família homogênea

## Controles recomendados para fechar `show + stop`

Para fechar a regra de negócio de `stop real` versus `dia semanticamente visível`, os controles mais úteis continuam sendo:

- `2026-03-19`
- `2026-04-16`
- `2026-06-12`
- `2026-06-13`
- `2026-06-14`
- `2026-12-29`
- `2026-12-30`
- `2026-12-31`

Use esse conjunto para responder:

- o que é marcador semântico limpo
- o que é caso ambíguo dependente de contexto
- o que é apenas cache/projeção genérica de runtime

1. a data não existe no `main`
2. a data não existe no `secondary`
3. a semântica só sobrevive por heurística antiga
4. o runtime só produz ruído e não ajuda a separar comportamento

Exemplo de rebaixamento correto:

- `2026-12-11`
  - manter como caso de controle de projeção/runtime
  - não insistir nela como data de agenda bruta principal

## Caminho atual recomendado

Hoje a ordem de trabalho mais produtiva é:

1. priorizar datas `visible + stop`
2. usar datas projetadas/invisíveis apenas como controle negativo
3. comparar blocos locais de UI
4. procurar a regra que diferencia:
   - `marker semântico no secondary`
   - `data visível`
   - `parada real da simulação`

Na prática, isso significa:

1. usar blocos confirmados como:
   - `29/12`, `30/12`, `31/12`
   - `27/08`
   - `30/06`
   - `22/09`

2. usar casos como `10/12`, `11/12`, `12/12` só para testar:
   - projeção
   - ausência de materialização save-side
   - diferença entre marker-fonte e dia efetivo

## Passo a passo operacional

### Fluxo padrão para uma nova data

1. confirmar se a data é visível e se para a simulação
2. rodar `pes2021_dump_calendar_date`
3. rodar `pes2021_dump_secondary_calendar_day`
4. classificar o dia semanticamente
5. se o dia for visível ou suspeito de stop real, medir runtime com o cursor sobre ele
6. comparar com:
   - um vizinho sem evento
   - um vizinho com evento diferente
   - um controle negativo
7. decidir se o dia é:
   - `main-backed`
   - `secondary-backed`
   - `runtime-projected`
   - `legacy-heuristic-only`

### Fluxo padrão para isolar a regra de stop

1. escolher um dia `visible + stop`
2. escolher um dia `raw marker only` ou `runtime projection only`
3. medir `secondary`
4. medir runtime com o cursor sobre cada um
5. filtrar clusters `Private/ReadWrite`
6. comparar famílias recorrentes
7. tentar localizar a estrutura comum dos dias que realmente param

## O que não devemos fazer

1. dar nome forte a um tipo de evento só porque um reader antigo usava esse nome
2. tratar projeção `dayIdx + 1` como fato bruto do save
3. insistir indefinidamente em um dia sem evidência nova
4. confundir `evento do calendário mundial` com `evento visível ao jogador`

## Critério de sucesso

Esta linha de trabalho terá atingido o objetivo quando conseguirmos responder, com evidência:

1. qual é a fonte bruta do evento
2. qual camada o projeta para o jogador
3. qual condição faz o dia aparecer
4. qual condição faz o dia parar a simulação

## Próximos alvos recomendados

1. consolidar tecnicamente o bloco `29/12-31/12` em `main`, `secondary` e `runtime`, agora que a semântica da UI está confirmada
2. fechar o artefato limpo e estreito de `2026-04-16`, para completar o quarteto `03-19`, `04-16`, `06-13`, `12-30`
3. detalhar os clusters altos de `2026-06-13` que casam com `d+1`, porque o único cluster "estável" atual é fraco e parece derivado
4. comparar o conjunto mínimo de estruturas realmente necessárias em `2026-06-13` com o bloco anual validado `29/12-31/12`, tratando qualquer cluster extra primeiro como derivação/cache
5. comparar o trio `01/12-02/12-05/12` com os controles `11/12` e `13/12`
6. atacar as frentes de suporte:
   - `0xBEB3A8` como cache derivado de dois slots
   - `0xB42430..0xB432B8` como família monotônica por `dayIdx`
   - `PlayerEventTable` / `Struct3` / `0x22BC84..0x2307AC` como controle negativo
7. reduzir a diferença entre:
   - `semantic marker`
   - `visible agenda line`
   - `stop-day`
