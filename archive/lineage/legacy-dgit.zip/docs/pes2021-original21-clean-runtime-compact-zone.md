# PES 2021: ORIGINAL_21 no runtime limpo

## Escopo

Esta nota consolida a investigacao feita no runtime limpo do jogo, sem o patch de calendario do BMPES carregado, para entender o que realmente e o bloco `ORIGINAL_21` que o `MOD 14.lua` sobrescreve.

Base da analise:

- processo: `PES2021.exe`
- modulo principal: `0x140000000`
- ancora de `ORIGINAL_21`: `0x14299BEDC` (`RVA 0x299BEDC`)
- janela local analisada: `0x14299B57C..0x14299D19B` (`7200` bytes)

## Resultado principal

O `ORIGINAL_21` nao e um bloco criado pelo BMPES.

No runtime limpo, ele ja existe como parte de uma zona compacta maior, compartilhada por varias competicoes e acessada estaticamente pelo proprio executavel.

Isso muda a leitura da patchagem:

- o BMPES nao introduz uma nova tabela da Copa do Brasil
- o BMPES reescreve um trecho especifico de uma infraestrutura de agenda compacta que ja existe no jogo base

## Estrutura observada

Na janela local completa foram encontrados:

- `241` pares estruturados `dayOffset + round + slot`
- `97` `dayOffset`s distintos
- `143` pares que batem com pelo menos uma competicao real no runtime limpo
- `98` pares sem correspondencia de competicao no dump anual por data

A zona mistura duas familias de codificacao:

- `slot-day-round`
- `day-round-slot`

O recorte imediatamente ligado ao `ORIGINAL_21` pertence a familia `slot-day-round`, mas a zona ampliada tem espelhamentos na familia `day-round-slot` logo adiante.

## Competicoes vistas no mesmo bairro compacto

As contagens mais fortes dentro da janela local foram:

| CompetitionCode | CompetitionName | PairHits |
| --- | --- | ---: |
| 52 | JAPAO\J1 LEAGUE | 39 |
| 29 | BRASIL\BRASILEIRO SERIE A | 38 |
| 163 | BRASIL\BRASILEIRO SERIE B | 38 |
| 168 | COLOMBIA\LIGA BETPLAY | 19 |
| 169 | COLOMBIA\LIGA BETPLAY | 19 |
| 166 | URUGUAI\PRIMEIRA DIVISAO | 12 |
| 31 | BRASIL\COPA DO BRASIL | 11 |
| 126 | COLOMBIA\COPA BETPLAY | 11 |
| 68 | CHILE\COPA CHILE | 7 |

Conclusao pratica: a zona nao e exclusiva da Copa do Brasil. Ela e uma superficie compartilhada de agenda compacta.

Observacao importante: essas contagens descrevem o runtime limpo e a atribuicao atual do nosso resolvedor. Elas nao sao a mesma coisa que a tabela-base codificada em `ORIGINAL_21`.

Os nomes acima ja estao normalizados para o mapa do Gogosz (`GOGOSZ\Menu Server\map_competitions.txt`). Quando o runtime ativo for Gogosz, esses sao os nomes canonicos para os `CompetitionCode` vistos nessa zona compacta.

### Competition codes vistos na zona compacta com nomes do Gogosz

| CompetitionCode | Nome no Gogosz | Datas no `PairMap` | Jogos no `PairMap` |
| --- | --- | ---: | ---: |
| `29` | `BRASIL\BRASILEIRO SERIE A` | `38` | `380` |
| `31` | `BRASIL\COPA DO BRASIL` | `11` | `77` |
| `52` | `JAPAO\J1 LEAGUE` | `38` | `390` |
| `54` | `URUGUAI\COPA AUF URUGUAY` | `4` | `15` |
| `55` | `JAPAO\JFA CHAMPIONSHIP` | `3` | `14` |
| `67` | `CHILE\CAMPEONATO BETSSON` | `2` | `16` |
| `68` | `CHILE\COPA CHILE` | `7` | `29` |
| `120` | `CHINA\CSL SUPERLEAGUE` | `2` | `24` |
| `126` | `COLOMBIA\COPA BETPLAY` | `10` | `39` |
| `127` | `CHINA\CFA CUP` | `2` | `10` |
| `162` | `ARABIA SAUDITA\SAUDI PRO LEAGUE` | `3` | `36` |
| `163` | `BRASIL\BRASILEIRO SERIE B` | `38` | `380` |
| `164` | `ARABIA SAUDITA\KINGS CUP` | `3` | `12` |
| `166` | `URUGUAI\PRIMEIRA DIVISAO` | `11` | `96` |
| `168` | `COLOMBIA\LIGA BETPLAY` | `19` | `190` |
| `169` | `COLOMBIA\LIGA BETPLAY` | `19` | `190` |

O artefato `docs/pes2021-original21-live-competition-map-2026-05-27.json` foi exportado antes dessa correcao de nomenclatura. Portanto, os seus `CompetitionCode` continuam validos, mas os `CompetitionName` antigos nao devem ser tratados como canonicos sob Gogosz.

Quando o literal `ORIGINAL_21` e decodificado diretamente, ele contem `14` entradas brutas:

- `12` datas distintas: `2026-01-17`, `2026-01-21`, `2026-01-24`, `2026-02-01`, `2026-02-07`, `2026-02-14`, `2026-02-21`, `2026-02-28`, `2026-03-07`, `2026-03-14`, `2026-03-21` e `2026-03-28`
- mais duas entradas extras de `round 54` que repetem `2026-03-21` e `2026-03-28`

Portanto, do ponto de vista da tabela-base, o slice Copa-like tem `12` datas distintas. O numero `11` abaixo e apenas o total de datas em que o runtime limpo atual foi efetivamente atribuido ao codigo `31` pelo nosso mapeamento.

## Recorte Copa-like que interessa ao patch

### Competition 31: BRASIL\COPA DO BRASIL

No runtime limpo, os hits de `31` nessa zona aparecem assim:

| Date | DayOffset | Round | Slot | Encoding |
| --- | ---: | ---: | ---: | --- |
| 2026-01-17 | 16 | 46 | 0 | slot-day-round |
| 2026-01-21 | 20 | 46 | 0 | slot-day-round |
| 2026-01-24 | 23 | 47 | 1 | slot-day-round |
| 2026-02-01 | 31 | 47 | 0 | slot-day-round |
| 2026-02-07 | 37 | 48 | 1 | slot-day-round |
| 2026-02-14 | 44 | 48 | 0 | slot-day-round |
| 2026-02-21 | 51 | 51 | 1 | slot-day-round |
| 2026-02-28 | 58 | 51 | 0 | slot-day-round |
| 2026-03-07 | 65 | 52 | 1 | slot-day-round |
| 2026-03-14 | 72 | 52 | 0 | slot-day-round |
| 2026-03-21 | 79 | 53 | 1 | slot-day-round |

Essas sao as `11` datas que o nosso mapeamento atual atribuiu ao codigo `31` no runtime limpo. Isso nao contradiz a existencia de `12` datas distintas no literal `ORIGINAL_21`; apenas mostra que o tail `2026-03-28 / round 53 / slot 0` foi atribuido pelo resolvedor a `68`, nao a `31`.

Ja a agenda reescrita pelo BMPES passa a usar `12` datas ativas: `2026-02-14`, `2026-02-27`, `2026-05-07`, `2026-05-13`, `2026-08-03`, `2026-08-08`, `2026-09-07`, `2026-09-19`, `2026-10-15`, `2026-10-21`, `2026-11-21` e `2026-12-06`.

### Competition 68: CHILE\COPA CHILE

`68` divide parte da mesma familia compacta:

| Date | DayOffset | Round | Slot | Encoding |
| --- | ---: | ---: | ---: | --- |
| 2026-01-17 | 16 | 46 | 0 | slot-day-round |
| 2026-01-21 | 20 | 46 | 0 | slot-day-round |
| 2026-02-21 | 51 | 51 | 1 | slot-day-round |
| 2026-02-28 | 58 | 51 | 0 | slot-day-round |
| 2026-03-07 | 65 | 52 | 1 | slot-day-round |
| 2026-03-14 | 72 | 52 | 0 | slot-day-round |
| 2026-03-28 | 86 | 53 | 0 | slot-day-round |

### Competition 126: COLOMBIA\COPA BETPLAY

`126` aparece na familia espelhada `day-round-slot`:

| Date | DayOffset | Round | Slot | Encoding |
| --- | ---: | ---: | ---: | --- |
| 2026-02-16 | 46 | 46 | 0 | day-round-slot |
| 2026-02-18 | 48 | 46 | 1 | day-round-slot |
| 2026-04-22 | 111 | 47 | 0 | day-round-slot |
| 2026-05-06 | 125 | 47 | 1 | day-round-slot |
| 2026-05-30 | 149 | 51 | 0 | day-round-slot |
| 2026-06-17 | 167 | 51 | 1 | day-round-slot |
| 2026-09-09 | 251 | 52 | 0 | day-round-slot |
| 2026-09-30 | 272 | 52 | 1 | day-round-slot |
| 2026-11-02 | 305 | 53 | 0 | day-round-slot |
| 2026-11-04 | 307 | 53 | 0 | day-round-slot |
| 2026-11-04 | 307 | 53 | 1 | day-round-slot |

## Janela critica de rounds 46..54

Esse recorte foi o mais util para separar o que e Copa do Brasil, o que e compartilhado com `68` e o que nao materializa no runtime limpo.

Fatos verificados:

- `31` e `68` compartilham os pares `46`, `51` e `52` na familia `slot-day-round`
- o resolvedor atual atribuiu `31` a `79|53|slot 1`
- o resolvedor atual atribuiu `68` a `86|53|slot 0`
- os pares `round 54` desse tail nao materializaram nenhuma competicao no runtime limpo observado

Leitura operacional:

- a tabela-base `ORIGINAL_21` continua codificando `2026-03-21` e `2026-03-28` como as duas datas distintas do tail de `round 53`
- no estado limpo observado, a nossa atribuicao por competicao divergiu no ultimo par: `79|53` caiu em `31`, `86|53` caiu em `68`, e `54` ficou sem materializacao
- isso deve ser tratado como uma ambiguidade de atribuicao no runtime, nao como prova de que a tabela-base da Copa teria apenas `11` datas

## Revalidacao do resolvedor

Uma decodificacao independente do literal `ORIGINAL_21` em `MOD 14.lua` foi comparada contra o `PairMap` rastreado.

Resultado:

- os `14` registros brutos bateram `14/14` nos campos `slot`, `dayOffset`, `round` e `date`
- portanto, o risco remanescente do resolvedor nao esta no calculo desses campos
- o risco real esta na associacao heuristica entre cada par compacto e as competicoes materializadas no calendario principal

No sweep ampliado, isso aparece assim:

- `241` pares totais
- `58` pares com mais de uma competicao materializada na mesma combinacao `date + round`
- `98` pares sem nenhuma competicao materializada no dump anual observado

No slice `ORIGINAL_21`, a ambiguidade mais importante e a do proprio recorte Copa-like:

- `16|46`, `20|46`, `51|51`, `58|51`, `65|52` e `72|52` aparecem tanto em `31` quanto em `68`
- `79|53` cai apenas em `31`
- `86|53` cai apenas em `68`
- os placeholders `round 54` nao materializaram nenhuma competicao no runtime limpo observado

## Referencias de codigo

As buscas diretas no processo falharam:

- `discover-pointers` no inicio do run: `0` candidatos
- `scan-value Int64` para o VA exato: `0` matches
- `scan-value Int32` para o offset `0x299BDBC`: `0` matches

A explicacao veio da leitura estatica do `PES2021.exe`:

- a zona do `ORIGINAL_21` cai em `.idata`
- o executavel referencia essa regiao via instrucoes RIP-relative na `.text`
- nao ha evidencia de ownership por ponteiro heap-like

Clusters de funcoes encontrados apontando para a familia `0x299B000..0x299C400`:

| Function RVA range | Referenced compact-zone RVAs |
| --- | --- |
| `0x15856B0-0x15859CB` | `0x299B920`, `0x299BA50` |
| `0x15859D0-0x1585FA7` | `0x299C140`, `0x299C338`, `0x299C318`, `0x299C308` |
| `0x1585FDE-0x1586017` | `0x299C370` |
| `0x1586810-0x158690A` | `0x299BDC0` |
| `0x158693E-0x1586977` | `0x299C0B0` |
| `0x15869B0-0x1586AAA` | `0x299BB80` |
| `0x1587B70-0x1587FDE` | `0x299B3D0`, `0x299B608`, `0x299B5F8` |
| `0x1587FEC-0x15880F2` | `0x299B628` |
| `0x15886D0-0x15887CA` | `0x299B660` |
| `0x1589350-0x15897BE` | `0x299B6C0`, `0x299B8F8`, `0x299B8E8` |
| `0x15897C0-0x1589D97` | `0x299BCA0`, `0x299BDA0`, `0x299BD90`, `0x299BD88` |
| `0x1589DCE-0x1589E07` | `0x299BEE0` |
| `0x1589E6E-0x1589EA7` | `0x299BF90` |
| `0x1589F0E-0x1589F47` | `0x299C020` |
| `0x1589F80-0x158A557` | `0x299BA60`, `0x299BB60`, `0x299BB50`, `0x299BB48` |
| `0x158A600-0x158A6FA` | `0x299B070` |
| `0x158A970-0x158AA6A` | `0x299B260` |
| `0x158AB10-0x158AC0A` | `0x299B0B0` |

## Progresso adicional na frente de xrefs

As tres funcoes pequenas imediatamente relevantes para o bairro do `ORIGINAL_21` foram lidas byte a byte.

Elas tem a mesma forma geral:

- carregam um ponteiro base da zona compacta em `RBX`
- definem um contador em `EDI`
- iteram em passos de `0x0C` bytes
- chamam o mesmo helper em `0x158B7C0`

Resumo:

| Function | Block start | Iterations | Step | Shared helper |
| --- | --- | ---: | ---: | --- |
| `0x1589DCE-0x1589E07` | `0x299BEE0` | 14 | `0x0C` | `0x158B7C0` |
| `0x1589E6E-0x1589EA7` | `0x299BF90` | 12 | `0x0C` | `0x158B7C0` |
| `0x1589F0E-0x1589F47` | `0x299C020` | 12 | `0x0C` | `0x158B7C0` |

Isso reforca a leitura de que o executavel trata esses blocos como arrays compactos homogeneos de entradas de `12` bytes, e nao como uma unica tabela plana orientada a competicao.

## Novo bloco live da Libertadores (2026-05-27)

Uma validacao adicional no runtime live do usuario encontrou um segundo bairro compacto relevante para a Libertadores.

Enderecos validados:

- bloco da Libertadores: `0x1429991BC` (`RVA 0x29991BC`)
- bloco-controle AFC adjacente: `0x14299927C` (`RVA 0x299927C`)
- ancora do `ORIGINAL_21`: `0x14299BEDC` (`RVA 0x299BEDC`)

Leitura estrutural:

- esse bloco novo nao e o mesmo slice do `ORIGINAL_21`
- ele fica `11552` bytes antes da ancora `ORIGINAL_21`
- ainda assim, ele usa a mesma logica de entradas compactas de `12` bytes
- o scan live encontrou um hit unico tanto para a sequencia-target da Libertadores quanto para a sequencia-controle AFC
- a janela alinhada ampliada mostrou que o corredor imediato nao usa um unico layout: ha pelo menos um sub-bloco `round-slot-day` imediatamente antes do bloco `slot-day-round` da fase de grupos

O artefato do scan ficou em:

- `artifacts/investigation/live-libertadores/compact-date-sequence-scan.json`

Os blocos decodificados ficaram em:

- `artifacts/investigation/live-libertadores/compact-window-lib.json`
- `artifacts/investigation/live-libertadores/compact-window-afc.json`

### O que o bloco da Libertadores provou

A decodificacao live do bloco da Libertadores mostrou a seguinte sequencia `slot-day-round` para a fase de grupos:

| Date | DayOffset | Round | Slot |
| --- | ---: | ---: | ---: |
| `2026-03-04` | `62` | `0` | `0` |
| `2026-03-18` | `76` | `1` | `2` |
| `2026-03-25` | `83` | `2` | `2` |
| `2026-04-15` | `104` | `3` | `2` |
| `2026-04-29` | `118` | `4` | `2` |
| `2026-05-20` | `139` | `5` | `2` |

Na janela alinhada ampliada, o corredor imediatamente anterior ao bloco de grupos abriu uma segunda subfamilia relevante em `round-slot-day`:

| Date | Round | Slot | Encoding |
| --- | ---: | ---: | --- |
| `2026-06-13` | `53` | `1` | `round-slot-day` |
| `2026-08-12` | `46` | `0` | `round-slot-day` |
| `2026-09-16` | `46` | `1` | `round-slot-day` |
| `2026-09-23` | `51` | `0` | `round-slot-day` |
| `2026-10-24` | `51` | `1` | `round-slot-day` |
| `2026-10-31` | `52` | `0` | `round-slot-day` |
| `2026-11-21` | `52` | `1` | `round-slot-day` |
| `2026-11-28` | `53` | `0` | `round-slot-day` |

Tambem aparecem repeticoes/tail de fechamento nesse mesmo sub-bloco imediato:

- `2026-11-21` como `round 53 / slot 1`
- `2026-11-28` como `round 54 / slot 0`

Ja no bloco `slot-day-round` da propria fase de grupos continuam aparecendo placeholders anteriores da mesma familia:

- pre-Libertadores: `2026-02-04` e `2026-02-11` (`round 53`)

Conclusao operacional:

- isso confirma que as 6 datas da fase de grupos existem como placeholders compactos na memoria do modulo, mesmo quando nao materializam fixtures no `main`
- isso tambem mostra que a Libertadores usa a mesma familia estrutural de blocos compactos de agenda, mas em outro bloco irmao, nao no slice `ORIGINAL_21`
- a conclusao anterior sobre `2026-06-13` era estreita demais: a data realmente aparece no mesmo corredor imediato, mas em um sub-bloco `round-slot-day`, nao no bloco `slot-day-round` da fase de grupos
- o mesmo sub-bloco imediato tambem carrega `2026-08-12`, `2026-09-16`, `2026-09-23`, `2026-10-24`, `2026-10-31`, `2026-11-21` e `2026-11-28`, ou seja, uma parte material das fases tardias que o usuario vinha apontando
- o que ainda permanece em aberto nao e mais a existencia dessas datas, e sim a correlacao exata entre cada `round` compacto (`46`, `51`, `52`, `53`, `54`) e o nome semantico de fase; hoje so `2026-06-13` esta validada manualmente como `Oitavas de final Jogo de ida`
- por isso, a resposta correta agora e mais forte: mesmo tipo de superficie, mesmo corredor imediato, mas com sub-blocos irmaos em layouts diferentes

## Artefato machine-readable

O mapeamento completo das `241` entradas, com competicoes resolvidas por data no runtime limpo, foi exportado para:

- `docs/pes2021-original21-live-competition-map-2026-05-27.json`
