# ORIGINAL_21 live neighborhood map (2026-05-27)

Runtime anchor:

- process: `PES2021.exe`
- hit address: `0x14299BEDC`
- anchor block: `ORIGINAL_21`
- local interpretation: compact triplet zone, not a primary `0x254` calendar record

Observed triplet formats:

- `slot-day-round`: `(slot, dayOffset, roundCode)`
- `day-round-slot`: `(dayOffset, roundCode, slot)`
- `other`: local noise / mixed fields / probable separators / unrelated structure

Key delimiters around `ORIGINAL_21`:

- `0x14299BED0`: `(2, 0, 0)`
- `0x14299BF84`: `(1, 0, 0)`

Structured runs in the widened local window:

| Format | Start | End | Count | Notes |
| --- | --- | --- | ---: | --- |
| `slot-day-round` | `0x14299B57C` | `0x14299B5F4` | 11 | rounds `36..45`, mostly `slot=2` |
| `slot-day-round` | `0x14299B630` | `0x14299B654` | 4 | includes `dayOffset 168`, `round 46`, and `dayOffset 171/174`, `round 53` |
| `day-round-slot` | `0x14299B660` | `0x14299B6A8` | 7 | mirrored compact entries with rounds `46/52/53` |
| `day-round-slot` | `0x14299B6C0` | `0x14299B8DC` | 46 | day offsets `100..345`, rounds `0..45`, mostly `slot=2` |
| `slot-day-round` | `0x14299BA50` | `0x14299BB40` | 21 | day offsets `16..174`, rounds `0..18`, mostly `slot=2` |
| `slot-day-round` | `0x14299BB7C` | `0x14299BD80` | 44 | day offsets `20..338`, rounds `0..18`, mostly `slot=2` |
| `slot-day-round` | `0x14299BDBC` | `0x14299BF84` | 39 | contains the `ORIGINAL_21` slice |
| `day-round-slot` | `0x14299BF90` | `0x14299BFF0` | 9 | mirrored late-year entries with rounds `46/47/51/52/53` |
| `day-round-slot` | `0x14299C020` | `0x14299C2FC` | 62 | large mirrored continuation with additional round families |

`ORIGINAL_21` slice inside the containing run:

| Address | A | B | C | Interpreted |
| --- | ---: | ---: | ---: | --- |
| `0x14299BEDC` | 0 | 16 | 46 | slot 0, day 16, round 46 |
| `0x14299BEE8` | 0 | 20 | 46 | slot 0, day 20, round 46 |
| `0x14299BEF4` | 1 | 23 | 47 | slot 1, day 23, round 47 |
| `0x14299BF00` | 0 | 31 | 47 | slot 0, day 31, round 47 |
| `0x14299BF0C` | 1 | 37 | 48 | slot 1, day 37, round 48 |
| `0x14299BF18` | 0 | 44 | 48 | slot 0, day 44, round 48 |
| `0x14299BF24` | 1 | 51 | 51 | slot 1, day 51, round 51 |
| `0x14299BF30` | 0 | 58 | 51 | slot 0, day 58, round 51 |
| `0x14299BF3C` | 1 | 65 | 52 | slot 1, day 65, round 52 |
| `0x14299BF48` | 0 | 72 | 52 | slot 0, day 72, round 52 |
| `0x14299BF54` | 1 | 79 | 53 | slot 1, day 79, round 53 |
| `0x14299BF60` | 0 | 86 | 53 | slot 0, day 86, round 53 |
| `0x14299BF6C` | 1 | 79 | 54 | slot 1, day 79, round 54 |
| `0x14299BF78` | 0 | 86 | 54 | slot 0, day 86, round 54 |

Immediate post-`ORIGINAL_21` mirrored entries:

| Address | A | B | C | Interpreted |
| --- | ---: | ---: | ---: | --- |
| `0x14299BF90` | 233 | 46 | 0 | day 233, round 46, slot 0 |
| `0x14299BF9C` | 254 | 46 | 1 | day 254, round 46, slot 1 |
| `0x14299BFA8` | 261 | 47 | 0 | day 261, round 47, slot 0 |
| `0x14299BFB4` | 275 | 47 | 1 | day 275, round 47, slot 1 |
| `0x14299BFC0` | 286 | 51 | 0 | day 286, round 51, slot 0 |
| `0x14299BFCC` | 289 | 51 | 1 | day 289, round 51, slot 1 |
| `0x14299BFD8` | 307 | 52 | 0 | day 307, round 52, slot 0 |
| `0x14299BFE4` | 310 | 52 | 1 | day 310, round 52, slot 1 |
| `0x14299BFF0` | 338 | 53 | 0 | day 338, round 53, slot 0 |

Important local observations:

- `53` and `54` appear repeatedly as round values in this compact neighborhood.
- `31` does not appear as an explicit competition field in this local compact zone.
- `68` does not appear in this widened local window.
- no explicit `competitionCode` field has been identified in the compact neighborhood around `ORIGINAL_21`.
- the compact zone appears to mix at least two mirrored representations of schedule-like triplets.

Current conclusion:

- `ORIGINAL_21` belongs to a larger compact schedule zone.
- nearby data supports `slot/dayOffset/roundCode` style structures, but not direct competition ownership.
- competition ownership must be inferred from an external referencing structure or a higher-level index.