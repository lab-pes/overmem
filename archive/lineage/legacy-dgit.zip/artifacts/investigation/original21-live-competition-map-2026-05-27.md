# ORIGINAL_21 live competition map and xref sweep (2026-05-27)

## Runtime basis

- Process: `PES2021.exe` (clean runtime, no BMPES calendar patch loaded)
- Main module base: `0x140000000`
- Compact-zone anchor: `0x14299BEDC` (`RVA 0x299BEDC`)
- Containing PE section: `.idata`
- Local sweep window used for pair extraction: `0x14299B57C..0x14299D19B` (`7200` bytes)
- Pair decoding accepted both mirrored compact encodings already observed locally:
  - `slot-day-round`
  - `day-round-slot`

## Full local sweep summary

- Unique structured `dayOffset+round+slot` pairs in the local window: `241`
- Unique day offsets represented in the local window: `97`
- Pairs that matched at least one live competition summary on the clean runtime: `143`
- Pairs with no live competition match on the queried date: `98`

Top competition hit counts inside this compact-zone sweep:

| CompetitionCode | CompetitionName | PairHits |
| --- | --- | ---: |
| 52 | Roshn Saudi League | 39 |
| 29 | Brasileiro Serie A | 38 |
| 163 | Brasileiro Serie B | 38 |
| 168 | Liga Betplay | 19 |
| 169 | Liga Betplay | 19 |
| 166 | Uruguaio | 12 |
| 31 | Copa Betano do Brasil | 11 |
| 126 | Copa BetPlay Dimayor | 11 |
| 68 | Chilean Cup | 7 |
| 54 | Uruguaio | 4 |
| 162 | TOYOTA Thai League | 4 |
| 55 | Copa Saudita | 3 |

## Target competitions inside the compact zone

### Competition 31: Copa Betano do Brasil

All observed hits used the `slot-day-round` encoding.

| Date | DayOffset | Round | Slot |
| --- | ---: | ---: | ---: |
| 2026-01-17 | 16 | 46 | 0 |
| 2026-01-21 | 20 | 46 | 0 |
| 2026-01-24 | 23 | 47 | 1 |
| 2026-02-01 | 31 | 47 | 0 |
| 2026-02-07 | 37 | 48 | 1 |
| 2026-02-14 | 44 | 48 | 0 |
| 2026-02-21 | 51 | 51 | 1 |
| 2026-02-28 | 58 | 51 | 0 |
| 2026-03-07 | 65 | 52 | 1 |
| 2026-03-14 | 72 | 52 | 0 |
| 2026-03-21 | 79 | 53 | 1 |

No live match was found for competition `31` at `dayOffset 86 / round 53`; on the clean runtime that date was owned by competition `68` instead.

### Competition 68: Chilean Cup

All observed hits also used the `slot-day-round` encoding.

| Date | DayOffset | Round | Slot |
| --- | ---: | ---: | ---: |
| 2026-01-17 | 16 | 46 | 0 |
| 2026-01-21 | 20 | 46 | 0 |
| 2026-02-21 | 51 | 51 | 1 |
| 2026-02-28 | 58 | 51 | 0 |
| 2026-03-07 | 65 | 52 | 1 |
| 2026-03-14 | 72 | 52 | 0 |
| 2026-03-28 | 86 | 53 | 0 |

### Competition 126: Copa BetPlay Dimayor

All observed hits used the mirrored `day-round-slot` encoding.

| Date | DayOffset | Round | Slot |
| --- | ---: | ---: | ---: |
| 2026-02-16 | 46 | 46 | 0 |
| 2026-02-18 | 48 | 46 | 1 |
| 2026-04-22 | 111 | 47 | 0 |
| 2026-05-06 | 125 | 47 | 1 |
| 2026-05-30 | 149 | 51 | 0 |
| 2026-06-17 | 167 | 51 | 1 |
| 2026-09-09 | 251 | 52 | 0 |
| 2026-09-30 | 272 | 52 | 1 |
| 2026-11-02 | 305 | 53 | 0 |
| 2026-11-04 | 307 | 53 | 0 |
| 2026-11-04 | 307 | 53 | 1 |

## Round 46..54 window inside the compact zone

This was the most useful slice for discriminating Copa-related behavior.

- `31` and `68` overlap on rounds `46`, `51`, and `52` in the same compact encoding family.
- `31` alone owns `dayOffset 79 / round 53 / slot 1`.
- `68` alone owns `dayOffset 86 / round 53 / slot 0`.
- Round `54` did not match a live competition for the Copa-related `slot-day-round` entries at `dayOffset 79` and `86`.
- The mirrored `day-round-slot` family also carries other cup-style schedules in the same round band:
  - `126` at `46/47/51/52/53`
  - `54` (Uruguaio) at `167/51`, `226/52`, `310/53`
  - `55` (Copa Saudita), `127` (Chinese Cup), `164` (Thai Cup) on some mirrored `46/47/52` dates

Selected `46..54` lines that matter for the ORIGINAL_21 neighborhood:

| Date | DayOffset | Round | Slot | Encoding | Live competitions |
| --- | ---: | ---: | ---: | --- | --- |
| 2026-01-17 | 16 | 46 | 0 | slot-day-round | 31, 68 |
| 2026-01-21 | 20 | 46 | 0 | slot-day-round | 31, 68 |
| 2026-01-24 | 23 | 47 | 1 | slot-day-round | 31 |
| 2026-02-01 | 31 | 47 | 0 | slot-day-round | 31 |
| 2026-02-07 | 37 | 48 | 1 | slot-day-round | 31 |
| 2026-02-14 | 44 | 48 | 0 | slot-day-round | 31 |
| 2026-02-21 | 51 | 51 | 1 | slot-day-round | 31, 68 |
| 2026-02-28 | 58 | 51 | 0 | slot-day-round | 31, 68 |
| 2026-03-07 | 65 | 52 | 1 | slot-day-round | 31, 68 |
| 2026-03-14 | 72 | 52 | 0 | slot-day-round | 31, 68 |
| 2026-03-21 | 79 | 53 | 1 | slot-day-round | 31 |
| 2026-03-21 | 79 | 54 | 1 | slot-day-round | none |
| 2026-03-28 | 86 | 53 | 0 | slot-day-round | 68 |
| 2026-03-28 | 86 | 54 | 0 | slot-day-round | none |
| 2026-11-02 | 305 | 53 | 0 | day-round-slot | 126 |
| 2026-11-04 | 307 | 53 | 0 | day-round-slot | 126 |
| 2026-11-04 | 307 | 53 | 1 | day-round-slot | 126 |
| 2026-11-07 | 310 | 53 | 1 | day-round-slot | 54 |

## Reference search results

Direct memory-ownership probes against the live process stayed negative:

- `discover-pointers --target-address 0x14299BDBC --max-depth 1`: `0` candidates
- `scan-value --value-kind Int64 --value 5412339420`: `0` matches
- `scan-value --value-kind Int32 --value 0x299BDBC`: `0` matches

Static PE analysis explains why those direct scans failed:

- The compact zone lives in image data, not in a heap object graph.
- Heuristic static scanning over `PES2021.exe` found multiple RIP-relative `lea` instructions in `.text` that resolve into the local range `RVA 0x299B000..0x299C400`.
- In other words, the executable appears to reference this area by image-relative code references, not by storing the absolute runtime VA or the raw module-relative offset as plain data.

Observed function clusters referencing this neighborhood:

| Function RVA range | Referenced compact-zone RVAs |
| --- | --- |
| `0x15856B0-0x15859CB` | `0x299B920`, `0x299BA50` |
| `0x15859D0-0x1585FA7` | `0x299C140`, `0x299C338`, `0x299C318`, `0x299C308` |
| `0x1585FDE-0x1586017` | `0x299C370` |
| `0x1586810-0x158690A` | `0x299BDC0` |
| `0x158693E-0x1586977` | `0x299C0B0` |
| `0x15869B0-0x1586AAA` | `0x299BB80` |
| `0x1587B70-0x1587FDE` | `0x299B3D0`, `0x299B608`, `0x299B5F8` |
| `0x1587FEC-0x15880F2` | `0x299B628` |
| `0x15886D0-0x15887CA` | `0x299B660` |
| `0x1589350-0x15897BE` | `0x299B6C0`, `0x299B8F8`, `0x299B8E8` |
| `0x15897C0-0x1589D97` | `0x299BCA0`, `0x299BDA0`, `0x299BD90`, `0x299BD88` |
| `0x1589DCE-0x1589E07` | `0x299BEE0` |
| `0x1589E6E-0x1589EA7` | `0x299BF90` |
| `0x1589F0E-0x1589F47` | `0x299C020` |
| `0x1589F80-0x158A557` | `0x299BA60`, `0x299BB60`, `0x299BB50`, `0x299BB48` |
| `0x158A600-0x158A6FA` | `0x299B070` |
| `0x158A970-0x158AA6A` | `0x299B260` |
| `0x158AB10-0x158AC0A` | `0x299B0B0` |

The most relevant immediate neighborhood around `ORIGINAL_21` is covered by three tiny adjacent functions, each loading one compact block start:

- `0x1589DCE-0x1589E07` -> `0x299BEE0`
- `0x1589E6E-0x1589EA7` -> `0x299BF90`
- `0x1589F0E-0x1589F47` -> `0x299C020`

That is the strongest current evidence that the local `ORIGINAL_21` slice belongs to a larger family of statically-addressed compact schedule blocks rather than to a single competition-owned table.