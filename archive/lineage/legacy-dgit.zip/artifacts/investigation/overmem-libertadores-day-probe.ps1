param(
    [string]$CliPath = 'd:\git\overmem\src\Overmem.Cli\bin\Debug\net8.0\Overmem.Cli.exe',
    [string]$ProcessName = 'PES2021',
    [uint64]$SecondaryBaseAddress = 0,
    [switch]$SecondaryOnly,
    [string]$OutputPath = 'd:\git\overmem\artifacts\investigation\overmem-libertadores-days-20260527.json'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Convert-FromCliText {
    param([string]$Text)

    $lines = @($Text -split "`r?`n")
    $startLine = -1
    $endLine = -1

    for ($lineIndex = 0; $lineIndex -lt $lines.Count; $lineIndex++) {
        $trimmed = $lines[$lineIndex].TrimStart()
        if ($trimmed.StartsWith('{') -or $trimmed.StartsWith('[')) {
            $startLine = $lineIndex
            break
        }
    }

    for ($lineIndex = $lines.Count - 1; $lineIndex -ge 0; $lineIndex--) {
        $trimmed = $lines[$lineIndex].TrimEnd()
        if ($trimmed.EndsWith('}') -or $trimmed.EndsWith(']')) {
            $endLine = $lineIndex
            break
        }
    }

    if ($startLine -lt 0 -or $endLine -lt $startLine) {
        throw 'JSON_NOT_FOUND'
    }

    $jsonText = ($lines[$startLine..$endLine] -join [Environment]::NewLine)
    return ($jsonText | ConvertFrom-Json -Depth 100)
}

function Invoke-CliJson {
    param([string[]]$Arguments)

    $text = & $CliPath @Arguments 2>&1 | Out-String
    return Convert-FromCliText -Text $text
}

$dates = @(
    '2026-02-04',
    '2026-02-11',
    '2026-03-04',
    '2026-03-18',
    '2026-03-25',
    '2026-04-15',
    '2026-04-29',
    '2026-05-20',
    '2026-06-13',
    '2026-08-12',
    '2026-09-16',
    '2026-09-23',
    '2026-10-24',
    '2026-10-31',
    '2026-11-28'
)

$results = foreach ($dateText in $dates) {
    $date = [datetime]::ParseExact($dateText, 'yyyy-MM-dd', $null)

    $main = $null
    $secondary = $null
    $mainError = $null
    $secondaryError = $null

    if (-not $SecondaryOnly) {
        try {
            $main = Invoke-CliJson -Arguments @(
                'pes2021-dump-calendar-date',
                '--name', $ProcessName,
                '--year', $date.Year.ToString(),
                '--month', $date.Month.ToString(),
                '--day', $date.Day.ToString())
        }
        catch {
            $mainError = $_.Exception.Message
        }
    }

    try {
        $secondaryArguments = @(
            'pes2021-dump-secondary-calendar-day',
            '--name', $ProcessName,
            '--year', $date.Year.ToString(),
            '--month', $date.Month.ToString(),
            '--day', $date.Day.ToString())

        if ($SecondaryBaseAddress -ne 0) {
            $secondaryArguments += @('--base-address', $SecondaryBaseAddress.ToString())
        }

        $secondary = Invoke-CliJson -Arguments $secondaryArguments
    }
    catch {
        $secondaryError = $_.Exception.Message
    }

    [pscustomobject]@{
        Date = $dateText
        MainOk = ($null -ne $main)
        MainError = $mainError
        MainSummary = if ($null -ne $main) {
            [pscustomobject]@{
                TotalCompetitions = [int]$main.TotalCompetitions
                TotalMatches = [int]$main.TotalMatches
                Competitions = @(
                    foreach ($competition in @($main.Competitions)) {
                        [pscustomobject]@{
                            CompetitionCode = [int]$competition.CompetitionCode
                            CompetitionName = [string]$competition.CompetitionName
                            MatchCount = [int]$competition.MatchCount
                            Rounds = [string]$competition.Rounds
                        }
                    }
                )
            }
        }
        SecondaryOk = ($null -ne $secondary)
        SecondaryError = $secondaryError
        SecondarySummary = if ($null -ne $secondary) {
            [pscustomobject]@{
                Count = [uint32]$secondary.Count
                HeaderTypes = @($secondary.HeaderEvents | Select-Object -ExpandProperty Type -Unique | Sort-Object)
                HeaderPairs = @(
                    @($secondary.HeaderEvents) | ForEach-Object {
                        [pscustomobject]@{
                            SlotIndex = [int]$_.SlotIndex
                            Type = [int]$_.Type
                            Value = [int]$_.Value
                        }
                    }
                )
                ItemCount = @($secondary.Items).Count
            }
        }
    }
}

$results | ConvertTo-Json -Depth 8 | Set-Content -Path $OutputPath -Encoding UTF8
Write-Output $OutputPath
