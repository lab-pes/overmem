param(
    [string]$CliPath = 'd:\git\overmem\src\Overmem.Cli\bin\Debug\net8.0\Overmem.Cli.exe',
    [string]$ProcessName = 'PES2021',
    [uint64]$Address,
    [int]$TripletCount = 16,
    [string]$OutputPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Convert-FromCliText {
    param([string]$Text)

    $lines = @($Text -split "`r?`n")
    $startLine = -1
    $endLine = -1

    for ($lineIndex = 0; $lineIndex -lt $lines.Count; $lineIndex++) {
        $trimmed = $lines[$lineIndex].TrimStart()
        if ($trimmed.StartsWith('{') -or $trimmed.StartsWith('[')) {
            $startLine = $lineIndex
            break
        }
    }

    for ($lineIndex = $lines.Count - 1; $lineIndex -ge 0; $lineIndex--) {
        $trimmed = $lines[$lineIndex].TrimEnd()
        if ($trimmed.EndsWith('}') -or $trimmed.EndsWith(']')) {
            $endLine = $lineIndex
            break
        }
    }

    if ($startLine -lt 0 -or $endLine -lt $startLine) {
        throw 'JSON_NOT_FOUND'
    }

    $jsonText = ($lines[$startLine..$endLine] -join [Environment]::NewLine)
    return ($jsonText | ConvertFrom-Json -Depth 100)
}

if (-not $PSBoundParameters.ContainsKey('OutputPath')) {
    $OutputPath = 'd:\git\overmem\artifacts\investigation\live-libertadores\compact-window.json'
}

$size = $TripletCount * 12
$text = & $CliPath read --name $ProcessName --address $Address.ToString() --value-kind Bytes --size $size.ToString() 2>&1 | Out-String
$json = Convert-FromCliText -Text $text
$bytes = [Convert]::FromHexString([string]$json.Value)
$origin = [datetime]'2026-01-01'

$triplets = for ($i = 0; $i -lt $bytes.Length; $i += 12) {
    $first = [BitConverter]::ToUInt32($bytes, $i)
    $second = [BitConverter]::ToUInt32($bytes, $i + 4)
    $third = [BitConverter]::ToUInt32($bytes, $i + 8)
    [pscustomobject]@{
        Entry = [int]($i / 12)
        Address = [uint64]($Address + [uint64]$i)
        SlotDayRound = [pscustomobject]@{
            Slot = [int]$first
            DayOffset = [int]$second
            Round = [int]$third
            Date = if ($second -le 366) { $origin.AddDays([int]$second).ToString('yyyy-MM-dd') } else { '' }
        }
        DayRoundSlot = [pscustomobject]@{
            DayOffset = [int]$first
            Round = [int]$second
            Slot = [int]$third
            Date = if ($first -le 366) { $origin.AddDays([int]$first).ToString('yyyy-MM-dd') } else { '' }
        }
        RoundSlotDay = [pscustomobject]@{
            Round = [int]$first
            Slot = [int]$second
            DayOffset = [int]$third
            Date = if ($third -le 366) { $origin.AddDays([int]$third).ToString('yyyy-MM-dd') } else { '' }
        }
    }
}

$result = [pscustomobject]@{
    Address = $Address
    TripletCount = $TripletCount
    Triplets = $triplets
}

$result | ConvertTo-Json -Depth 8 | Set-Content -Path $OutputPath -Encoding UTF8
Write-Output $OutputPath
