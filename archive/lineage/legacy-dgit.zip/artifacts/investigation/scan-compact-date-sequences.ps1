param(
    [string]$CliPath = 'd:\git\overmem\src\Overmem.Cli\bin\Debug\net8.0\Overmem.Cli.exe',
    [string]$ProcessName = 'PES2021',
    [string]$ModuleName = 'PES2021.exe',
    [string]$OutputPath = 'd:\git\overmem\artifacts\investigation\live-libertadores\compact-date-sequence-scan.json'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Convert-FromCliText {
    param([string]$Text)

    $lines = @($Text -split "`r?`n")
    $startLine = -1
    $endLine = -1

    for ($lineIndex = 0; $lineIndex -lt $lines.Count; $lineIndex++) {
        $trimmed = $lines[$lineIndex].TrimStart()
        if ($trimmed.StartsWith('{') -or $trimmed.StartsWith('[')) {
            $startLine = $lineIndex
            break
        }
    }

    for ($lineIndex = $lines.Count - 1; $lineIndex -ge 0; $lineIndex--) {
        $trimmed = $lines[$lineIndex].TrimEnd()
        if ($trimmed.EndsWith('}') -or $trimmed.EndsWith(']')) {
            $endLine = $lineIndex
            break
        }
    }

    if ($startLine -lt 0 -or $endLine -lt $startLine) {
        throw 'JSON_NOT_FOUND'
    }

    $jsonText = ($lines[$startLine..$endLine] -join [Environment]::NewLine)
    return ($jsonText | ConvertFrom-Json -Depth 100)
}

function New-SlotDayRoundPattern {
    param([int[]]$DayOffsets)

    $tokens = New-Object System.Collections.Generic.List[string]
    foreach ($dayOffset in $DayOffsets) {
        foreach ($token in @('??','??','??','??')) {
            [void]$tokens.Add($token)
        }

        foreach ($token in ([BitConverter]::GetBytes([uint32]$dayOffset) | ForEach-Object { $_.ToString('X2') })) {
            [void]$tokens.Add($token)
        }

        foreach ($token in @('??','??','??','??')) {
            [void]$tokens.Add($token)
        }
    }

    return ($tokens -join ' ')
}

function New-DayRoundSlotPattern {
    param([int[]]$DayOffsets)

    $tokens = New-Object System.Collections.Generic.List[string]
    foreach ($dayOffset in $DayOffsets) {
        foreach ($token in ([BitConverter]::GetBytes([uint32]$dayOffset) | ForEach-Object { $_.ToString('X2') })) {
            [void]$tokens.Add($token)
        }

        foreach ($token in @('??','??','??','??','??','??','??','??')) {
            [void]$tokens.Add($token)
        }
    }

    return ($tokens -join ' ')
}

function Invoke-PatternScan {
    param(
        [string]$Name,
        [string]$Pattern
    )

    $text = & $CliPath scan-pattern --name $ProcessName --module-name $ModuleName --pattern $Pattern --max-results 20 2>&1 | Out-String
    $json = Convert-FromCliText -Text $text

    return [pscustomobject]@{
        Name = $Name
        Pattern = $Pattern
        AddressCount = @($json.Addresses).Count
        Addresses = @($json.Addresses)
    }
}

$results = @(
    Invoke-PatternScan -Name 'afc-slot-day-round' -Pattern (New-SlotDayRoundPattern -DayOffsets @(55, 62, 76, 97, 111, 125))
    Invoke-PatternScan -Name 'afc-day-round-slot' -Pattern (New-DayRoundSlotPattern -DayOffsets @(55, 62, 76, 97, 111, 125))
    Invoke-PatternScan -Name 'lib-slot-day-round' -Pattern (New-SlotDayRoundPattern -DayOffsets @(62, 76, 83, 104, 118, 139))
    Invoke-PatternScan -Name 'lib-day-round-slot' -Pattern (New-DayRoundSlotPattern -DayOffsets @(62, 76, 83, 104, 118, 139))
)

$results | ConvertTo-Json -Depth 6 | Set-Content -Path $OutputPath -Encoding UTF8
Write-Output $OutputPath
