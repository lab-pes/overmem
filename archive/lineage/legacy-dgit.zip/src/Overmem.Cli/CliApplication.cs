using Microsoft.Extensions.DependencyInjection;
using Overmem.Abstractions.Memory;
using Overmem.Abstractions.Processes;
using Overmem.Abstractions.Search;
using Overmem.Application;
using Overmem.Application.Pes2021;
using Overmem.Application.Pointers;
using Overmem.Application.Tables;
using Overmem.Search;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Overmem.Cli;

public static class CliApplication
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        Converters = { new JsonStringEnumConverter() }
    };

    public static async Task<int> RunAsync(
        string[] args,
        IServiceProvider services,
        TextWriter stdout,
        TextWriter stderr,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var command = CliArgumentParser.Parse(args);
            if (command is HelpCliCommand)
            {
                await stdout.WriteLineAsync(GetHelpText());
                return 0;
            }

            var memoryTableService = services.GetRequiredService<MemoryTableService>();
            return await (command switch
            {
                ListModulesCliCommand modules => ExecuteWithAttachmentAsync(modules.Selector, services.GetRequiredService<ProcessMemoryApplicationService>(), attachment => services.GetRequiredService<ProcessMemoryApplicationService>().ListModulesAsync(attachment.AttachmentId, cancellationToken), stdout, cancellationToken),
                ListRegionsCliCommand regions => ExecuteWithAttachmentAsync(regions.Selector, services.GetRequiredService<ProcessMemoryApplicationService>(), attachment => services.GetRequiredService<ProcessMemoryApplicationService>().ListRegionsAsync(attachment.AttachmentId, cancellationToken), stdout, cancellationToken),
                ReadCliCommand read => ExecuteWithAttachmentAsync(read.Selector, services.GetRequiredService<ProcessMemoryApplicationService>(), attachment => services.GetRequiredService<ProcessMemoryApplicationService>().ReadAsync(new ReadMemoryRequest(attachment.AttachmentId, read.Address, read.ValueKind, read.Size), cancellationToken), stdout, cancellationToken),
                WriteCliCommand write => ExecuteWithAttachmentAsync(write.Selector, services.GetRequiredService<ProcessMemoryApplicationService>(), attachment => services.GetRequiredService<ProcessMemoryApplicationService>().WriteAsync(new WriteMemoryRequest(attachment.AttachmentId, write.Address, write.ValueKind, write.Value, write.Size), cancellationToken), stdout, cancellationToken),
                ScanPatternCliCommand scan => ExecuteWithAttachmentAsync(scan.Selector, services.GetRequiredService<ProcessMemoryApplicationService>(), attachment => services.GetRequiredService<ProcessMemoryApplicationService>().ScanPatternAsync(new PatternScanRequest(attachment.AttachmentId, scan.Pattern, scan.ModuleName, scan.MaxResults), cancellationToken), stdout, cancellationToken),
                ResolvePointerCliCommand resolve => ExecuteWithAttachmentAsync(resolve.Selector, services.GetRequiredService<ProcessMemoryApplicationService>(), attachment => services.GetRequiredService<ProcessMemoryApplicationService>().ResolvePointerAsync(new ResolvePointerRequest(attachment.AttachmentId, resolve.BaseAddress, resolve.Offsets), cancellationToken), stdout, cancellationToken),
                ResolveModulePointerCliCommand resolveModule => ExecuteWithAttachmentAsync(resolveModule.Selector, services.GetRequiredService<ProcessMemoryApplicationService>(), attachment => services.GetRequiredService<ProcessMemoryApplicationService>().ResolveModulePointerAsync(new ResolveModulePointerRequest(attachment.AttachmentId, resolveModule.ModuleName, resolveModule.BaseOffset, resolveModule.Offsets), cancellationToken), stdout, cancellationToken),
                LoadTableCliCommand loadTable => ExecuteAsync(async () => await memoryTableService.LoadAsync(loadTable.FilePath, cancellationToken), stdout),
                SaveTableCliCommand saveTable => ExecuteAsync(async () =>
                {
                    var document = await memoryTableService.LoadAsync(saveTable.SourceFilePath, cancellationToken);
                    await memoryTableService.SaveAsync(saveTable.DestinationFilePath, document, cancellationToken);
                    return new
                    {
                        SourceFilePath = saveTable.SourceFilePath,
                        DestinationFilePath = saveTable.DestinationFilePath,
                        document.Name,
                        EntryCount = document.Entries.Count
                    };
                }, stdout),
                RefreshTableCliCommand refreshTable => ExecuteWithAttachmentAsync(refreshTable.Selector, services.GetRequiredService<ProcessMemoryApplicationService>(), async attachment =>
                {
                    var document = await memoryTableService.LoadAsync(refreshTable.FilePath, cancellationToken);
                    return await memoryTableService.RefreshAsync(attachment.AttachmentId, document, cancellationToken);
                }, stdout, cancellationToken),
                ScanValueCliCommand scanValue => ExecuteWithAttachmentAsync(scanValue.Selector, services.GetRequiredService<ProcessMemoryApplicationService>(), async attachment =>
                {
                    var valueSearchService = services.GetRequiredService<IValueSearchService>();
                    var result = await valueSearchService.StartExactSearchAsync(new StartValueSearchRequest(
                        attachment.AttachmentId,
                        scanValue.ValueKind,
                        scanValue.Value,
                        scanValue.Size,
                        scanValue.Alignment,
                        scanValue.MaxResults), cancellationToken);

                    await valueSearchService.CloseSessionAsync(result.SessionId, cancellationToken);
                    return result;
                }, stdout, cancellationToken),
                DiscoverPointersCliCommand discoverPointers => ExecuteWithAttachmentAsync(discoverPointers.Selector, services.GetRequiredService<ProcessMemoryApplicationService>(), async attachment =>
                {
                    var pointerDiscoveryService = services.GetRequiredService<IPointerDiscoveryService>();
                    return await pointerDiscoveryService.DiscoverAsync(new DiscoverPointersRequest(
                        attachment.AttachmentId,
                        discoverPointers.TargetAddress,
                        discoverPointers.MaxDepth,
                        discoverPointers.MaxOffset,
                        discoverPointers.Alignment,
                        discoverPointers.MaxResults,
                        discoverPointers.BaseModuleName,
                        discoverPointers.RevalidateCandidates), cancellationToken);
                }, stdout, cancellationToken),
                Pes2021FindCalendarBaseCliCommand findCalendarBase => ExecuteWithAttachmentAsync(findCalendarBase.Selector, services.GetRequiredService<ProcessMemoryApplicationService>(), attachment =>
                    services.GetRequiredService<Pes2021AgendaService>().FindBaseAsync(
                        attachment.AttachmentId,
                        findCalendarBase.Year,
                        findCalendarBase.Month,
                        findCalendarBase.Day,
                        findCalendarBase.RoundValue,
                        findCalendarBase.CompetitionCode,
                        findCalendarBase.ModuleName,
                        findCalendarBase.MaxResults,
                        cancellationToken), stdout, cancellationToken),
                Pes2021DumpCalendarDateCliCommand dumpCalendarDate => ExecuteWithAttachmentAsync(dumpCalendarDate.Selector, services.GetRequiredService<ProcessMemoryApplicationService>(), attachment =>
                    services.GetRequiredService<Pes2021AgendaService>().DumpDateAsync(
                        attachment.AttachmentId,
                        dumpCalendarDate.Year,
                        dumpCalendarDate.Month,
                        dumpCalendarDate.Day,
                        dumpCalendarDate.BaseAddress,
                        dumpCalendarDate.MaxRecords,
                        cancellationToken), stdout, cancellationToken),
                Pes2021CompareCalendarDatesCliCommand compareCalendarDates => ExecuteWithAttachmentAsync(compareCalendarDates.Selector, services.GetRequiredService<ProcessMemoryApplicationService>(), attachment =>
                    services.GetRequiredService<Pes2021AgendaService>().CompareDatesAsync(
                        attachment.AttachmentId,
                        compareCalendarDates.FirstYear,
                        compareCalendarDates.FirstMonth,
                        compareCalendarDates.FirstDay,
                        compareCalendarDates.SecondYear,
                        compareCalendarDates.SecondMonth,
                        compareCalendarDates.SecondDay,
                        compareCalendarDates.BaseAddress,
                        compareCalendarDates.MaxRecords,
                        cancellationToken), stdout, cancellationToken),
                Pes2021CalendarSummaryCliCommand calendarSummary => ExecuteWithAttachmentAsync(calendarSummary.Selector, services.GetRequiredService<ProcessMemoryApplicationService>(), attachment =>
                    services.GetRequiredService<Pes2021AgendaService>().CalendarSummaryAsync(
                        attachment.AttachmentId,
                        calendarSummary.BaseAddress,
                        calendarSummary.MaxRecords,
                        cancellationToken), stdout, cancellationToken),
                Pes2021InventoryAnnualEventsCliCommand inventoryAnnualEvents => ExecuteWithAttachmentAsync(inventoryAnnualEvents.Selector, services.GetRequiredService<ProcessMemoryApplicationService>(), attachment =>
                    services.GetRequiredService<Pes2021AgendaService>().InventoryAnnualEventsAsync(
                        attachment.AttachmentId,
                        inventoryAnnualEvents.Year,
                        inventoryAnnualEvents.CalendarBaseAddress,
                        inventoryAnnualEvents.SecondaryBaseAddress,
                        cancellationToken), stdout, cancellationToken),
                Pes2021FindSecondaryCalendarBaseByDateCliCommand findSecondaryBaseByDate => ExecuteWithAttachmentAsync(findSecondaryBaseByDate.Selector, services.GetRequiredService<ProcessMemoryApplicationService>(), attachment =>
                    services.GetRequiredService<Pes2021AgendaService>().FindSecondaryBaseByDateAsync(
                        attachment.AttachmentId,
                        findSecondaryBaseByDate.Year,
                        findSecondaryBaseByDate.Month,
                        findSecondaryBaseByDate.Day,
                        findSecondaryBaseByDate.ModuleName,
                        findSecondaryBaseByDate.MaxResults,
                        cancellationToken), stdout, cancellationToken),
                Pes2021DumpSecondaryCalendarDayCliCommand dumpSecondaryCalendarDay => ExecuteWithAttachmentAsync(dumpSecondaryCalendarDay.Selector, services.GetRequiredService<ProcessMemoryApplicationService>(), attachment =>
                    services.GetRequiredService<Pes2021AgendaService>().DumpSecondaryDayAsync(
                        attachment.AttachmentId,
                        dumpSecondaryCalendarDay.Year,
                        dumpSecondaryCalendarDay.Month,
                        dumpSecondaryCalendarDay.Day,
                        dumpSecondaryCalendarDay.BaseAddress,
                        cancellationToken), stdout, cancellationToken),
                Pes2021ScanRuntimeDayIndexClustersCliCommand scanRuntimeDayIndexClusters => ExecuteWithAttachmentAsync(scanRuntimeDayIndexClusters.Selector, services.GetRequiredService<ProcessMemoryApplicationService>(), attachment =>
                    services.GetRequiredService<Pes2021AgendaService>().ScanRuntimeDayIndexClustersAsync(
                        attachment.AttachmentId,
                        scanRuntimeDayIndexClusters.Year,
                        scanRuntimeDayIndexClusters.Month,
                        scanRuntimeDayIndexClusters.Day,
                        scanRuntimeDayIndexClusters.MaxResults,
                        scanRuntimeDayIndexClusters.ClusterGap,
                        scanRuntimeDayIndexClusters.PreviewBytes,
                        cancellationToken), stdout, cancellationToken),
                Pes2021DumpRuntimeDayPayloadFamilyCliCommand dumpRuntimeDayPayloadFamily => ExecuteWithAttachmentAsync(dumpRuntimeDayPayloadFamily.Selector, services.GetRequiredService<ProcessMemoryApplicationService>(), attachment =>
                    services.GetRequiredService<Pes2021AgendaService>().DumpRuntimeDayPayloadFamilyAsync(
                        attachment.AttachmentId,
                        dumpRuntimeDayPayloadFamily.Year,
                        dumpRuntimeDayPayloadFamily.Month,
                        dumpRuntimeDayPayloadFamily.Day,
                        dumpRuntimeDayPayloadFamily.StartAddress,
                        dumpRuntimeDayPayloadFamily.StopAddress,
                        dumpRuntimeDayPayloadFamily.CalendarBaseAddress,
                        dumpRuntimeDayPayloadFamily.PreferredStrides,
                        dumpRuntimeDayPayloadFamily.MinHitCount,
                        dumpRuntimeDayPayloadFamily.ClusterGap,
                        dumpRuntimeDayPayloadFamily.PreviewBytes,
                        cancellationToken), stdout, cancellationToken),
                Pes2021CompareRuntimeDayPayloadFamilyCliCommand compareRuntimeDayPayloadFamily => ExecuteWithAttachmentAsync(compareRuntimeDayPayloadFamily.Selector, services.GetRequiredService<ProcessMemoryApplicationService>(), attachment =>
                    services.GetRequiredService<Pes2021AgendaService>().CompareRuntimeDayPayloadFamilyAsync(
                        attachment.AttachmentId,
                        compareRuntimeDayPayloadFamily.Year,
                        compareRuntimeDayPayloadFamily.Month,
                        compareRuntimeDayPayloadFamily.Day,
                        compareRuntimeDayPayloadFamily.StartAddress,
                        compareRuntimeDayPayloadFamily.StopAddress,
                        compareRuntimeDayPayloadFamily.CalendarBaseAddress,
                        compareRuntimeDayPayloadFamily.PreferredStrides,
                        compareRuntimeDayPayloadFamily.MinHitCount,
                        compareRuntimeDayPayloadFamily.ClusterGap,
                        compareRuntimeDayPayloadFamily.PreviewBytes,
                        cancellationToken), stdout, cancellationToken),
                Pes2021DumpRuntimeDayPayloadClusterDetailCliCommand dumpRuntimeDayPayloadClusterDetail => ExecuteWithAttachmentAsync(dumpRuntimeDayPayloadClusterDetail.Selector, services.GetRequiredService<ProcessMemoryApplicationService>(), attachment =>
                    services.GetRequiredService<Pes2021AgendaService>().DumpRuntimeDayPayloadClusterDetailAsync(
                        attachment.AttachmentId,
                        dumpRuntimeDayPayloadClusterDetail.Year,
                        dumpRuntimeDayPayloadClusterDetail.Month,
                        dumpRuntimeDayPayloadClusterDetail.Day,
                        dumpRuntimeDayPayloadClusterDetail.ClusterOrdinal,
                        dumpRuntimeDayPayloadClusterDetail.StartAddress,
                        dumpRuntimeDayPayloadClusterDetail.StopAddress,
                        dumpRuntimeDayPayloadClusterDetail.CalendarBaseAddress,
                        dumpRuntimeDayPayloadClusterDetail.PreferredStrides,
                        dumpRuntimeDayPayloadClusterDetail.MinHitCount,
                        dumpRuntimeDayPayloadClusterDetail.ClusterGap,
                        dumpRuntimeDayPayloadClusterDetail.PreviewBytes,
                        dumpRuntimeDayPayloadClusterDetail.IntsBeforeHit,
                        dumpRuntimeDayPayloadClusterDetail.IntsAfterHit,
                        cancellationToken), stdout, cancellationToken),
                Pes2021AnalyzeRuntimeDayPayloadClusterCliCommand analyzeRuntimeDayPayloadCluster => ExecuteWithAttachmentAsync(analyzeRuntimeDayPayloadCluster.Selector, services.GetRequiredService<ProcessMemoryApplicationService>(), attachment =>
                    services.GetRequiredService<Pes2021AgendaService>().AnalyzeRuntimeDayPayloadClusterAsync(
                        attachment.AttachmentId,
                        analyzeRuntimeDayPayloadCluster.Year,
                        analyzeRuntimeDayPayloadCluster.Month,
                        analyzeRuntimeDayPayloadCluster.Day,
                        analyzeRuntimeDayPayloadCluster.ClusterOrdinal,
                        analyzeRuntimeDayPayloadCluster.StartAddress,
                        analyzeRuntimeDayPayloadCluster.StopAddress,
                        analyzeRuntimeDayPayloadCluster.CalendarBaseAddress,
                        analyzeRuntimeDayPayloadCluster.PreferredStrides,
                        analyzeRuntimeDayPayloadCluster.MinHitCount,
                        analyzeRuntimeDayPayloadCluster.ClusterGap,
                        analyzeRuntimeDayPayloadCluster.PreviewBytes,
                        analyzeRuntimeDayPayloadCluster.IntsBeforeHit,
                        analyzeRuntimeDayPayloadCluster.IntsAfterHit,
                        cancellationToken), stdout, cancellationToken),
                Pes2021ClassifyRuntimeDayVariantCliCommand classifyRuntimeDayVariant => ExecuteWithAttachmentAsync(classifyRuntimeDayVariant.Selector, services.GetRequiredService<ProcessMemoryApplicationService>(), attachment =>
                    services.GetRequiredService<Pes2021AgendaService>().ClassifyRuntimeDayVariantAsync(
                        attachment.AttachmentId,
                        classifyRuntimeDayVariant.Year,
                        classifyRuntimeDayVariant.Month,
                        classifyRuntimeDayVariant.Day,
                        classifyRuntimeDayVariant.StartAddress,
                        classifyRuntimeDayVariant.StopAddress,
                        classifyRuntimeDayVariant.SecondaryBaseAddress,
                        classifyRuntimeDayVariant.CalendarBaseAddress,
                        classifyRuntimeDayVariant.PreferredStrides,
                        classifyRuntimeDayVariant.MinHitCount,
                        classifyRuntimeDayVariant.ClusterGap,
                        classifyRuntimeDayVariant.PreviewBytes,
                        cancellationToken), stdout, cancellationToken),
                _ => throw new ArgumentOutOfRangeException(nameof(command), $"Unsupported command type '{command.GetType().Name}'.")
            });
        }
        catch (Exception exception)
        {
            await stderr.WriteLineAsync(exception.Message);
            return 1;
        }
    }

    private static async Task<int> ExecuteWithAttachmentAsync<T>(
        ProcessSelector selector,
        ProcessMemoryApplicationService applicationService,
        Func<AttachmentInfo, Task<T>> action,
        TextWriter stdout,
        CancellationToken cancellationToken)
    {
        var attachment = await applicationService.AttachAsync(selector, cancellationToken);
        try
        {
            var result = await action(attachment);
            await stdout.WriteLineAsync(JsonSerializer.Serialize(result, JsonOptions));
            return 0;
        }
        finally
        {
            await applicationService.DetachAsync(attachment.AttachmentId, cancellationToken);
        }
    }

    private static async Task<int> ExecuteAsync<T>(Func<Task<T>> action, TextWriter stdout)
    {
        var result = await action();
        await stdout.WriteLineAsync(JsonSerializer.Serialize(result, JsonOptions));
        return 0;
    }

    private static string GetHelpText()
        => string.Join(Environment.NewLine,
            "Overmem CLI",
            "",
            "Commands:",
            "  modules --pid <id>|--name <process>",
            "  regions --pid <id>|--name <process>",
            "  read --pid <id>|--name <process> --address <value> --value-kind <kind> [--size <bytes>]",
            "  write --pid <id>|--name <process> --address <value> --value-kind <kind> --value <value> [--size <bytes>]",
            "  scan-pattern --pid <id>|--name <process> --pattern <pattern> [--module-name <module>] [--max-results <count>]",
            "  resolve-pointer --pid <id>|--name <process> --base-address <value> [--offsets <o1,o2,...>]",
            "  resolve-module-pointer --pid <id>|--name <process> --module-name <module> [--base-offset <value>] [--offsets <o1,o2,...>]",
            "  table-load --file <path>",
            "  table-save --source-file <path> --destination-file <path>",
            "  table-refresh --pid <id>|--name <process> --file <path>",
            "  scan-value --pid <id>|--name <process> --value-kind <kind> --value <value> [--size <bytes>] [--alignment <step>] [--max-results <count>]",
            "  discover-pointers --pid <id>|--name <process> --target-address <value> [--max-depth <levels>] [--max-offset <value>] [--alignment <step>] [--max-results <count>] [--base-module-name <module>] [--skip-revalidation]",
            "  pes2021-find-calendar-base --pid <id>|--name <process> [--year <yyyy>] [--month <mm>] [--day <dd>] [--round <value>] [--competition-code <code>] [--module-name <module>] [--max-results <count>]",
            "  pes2021-dump-calendar-date --pid <id>|--name <process> --year <yyyy> --month <mm> --day <dd> [--base-address <value>] [--max-records <count>]",
            "  pes2021-compare-calendar-dates --pid <id>|--name <process> --first-year <yyyy> --first-month <mm> --first-day <dd> --second-year <yyyy> --second-month <mm> --second-day <dd> [--base-address <value>] [--max-records <count>]",
            "  pes2021-calendar-summary --pid <id>|--name <process> [--base-address <value>] [--max-records <count>]",
            "  pes2021-inventory-annual-events --pid <id>|--name <process> --year <yyyy> [--calendar-base-address <value>] [--secondary-base-address <value>]",
            "  pes2021-find-secondary-calendar-base-by-date --pid <id>|--name <process> --year <yyyy> --month <mm> --day <dd> [--module-name <module>] [--max-results <count>]",
            "  pes2021-dump-secondary-calendar-day --pid <id>|--name <process> --year <yyyy> --month <mm> --day <dd> [--base-address <value>]",
            "  pes2021-scan-runtime-day-index-clusters --pid <id>|--name <process> --year <yyyy> --month <mm> --day <dd> [--max-results <count>] [--cluster-gap <bytes>] [--preview-bytes <bytes>]",
            "  pes2021-dump-runtime-day-payload-family --pid <id>|--name <process> --year <yyyy> --month <mm> --day <dd> [--start-address <value>] [--stop-address <value>] [--calendar-base-address <value>] [--preferred-strides <s1,s2,...>] [--min-hit-count <count>] [--cluster-gap <bytes>] [--preview-bytes <bytes>]",
            "  pes2021-compare-runtime-day-payload-family --pid <id>|--name <process> --year <yyyy> --month <mm> --day <dd> [--start-address <value>] [--stop-address <value>] [--calendar-base-address <value>] [--preferred-strides <s1,s2,...>] [--min-hit-count <count>] [--cluster-gap <bytes>] [--preview-bytes <bytes>]",
            "  pes2021-dump-runtime-day-payload-cluster-detail --pid <id>|--name <process> --year <yyyy> --month <mm> --day <dd> --cluster-ordinal <index> [--start-address <value>] [--stop-address <value>] [--calendar-base-address <value>] [--preferred-strides <s1,s2,...>] [--min-hit-count <count>] [--cluster-gap <bytes>] [--preview-bytes <bytes>] [--ints-before-hit <count>] [--ints-after-hit <count>]",
            "  pes2021-analyze-runtime-day-payload-cluster --pid <id>|--name <process> --year <yyyy> --month <mm> --day <dd> --cluster-ordinal <index> [--start-address <value>] [--stop-address <value>] [--calendar-base-address <value>] [--preferred-strides <s1,s2,...>] [--min-hit-count <count>] [--cluster-gap <bytes>] [--preview-bytes <bytes>] [--ints-before-hit <count>] [--ints-after-hit <count>]",
            "  pes2021-classify-runtime-day-variant --pid <id>|--name <process> --year <yyyy> --month <mm> --day <dd> [--start-address <value>] [--stop-address <value>] [--secondary-base-address <value>] [--calendar-base-address <value>] [--preferred-strides <s1,s2,...>] [--min-hit-count <count>] [--cluster-gap <bytes>] [--preview-bytes <bytes>]",
            "",
            "Numeric options accept decimal or hexadecimal values prefixed with 0x.",
            $"Supported value kinds: {string.Join(", ", Enum.GetNames<MemoryValueKind>())}");
}