# Overmem Copa do Brasil for Sider

Arquivos deste diretório:

1. `overmem_copa_do_brasil.lua`
   Módulo Lua do Sider para aplicar o fallback validado do record isolado da final e sondar a camada derivada/UI.
2. `sider.ini.snippet.txt`
   Linha pronta para colar no `sider.ini`.

## Instalação

1. Copiar [port/sider/overmem_copa_do_brasil.lua](d:/git/overmem/port/sider/overmem_copa_do_brasil.lua) para a pasta `modules` da sua instalação do Sider.
2. Abrir o `sider.ini` e adicionar a linha do snippet abaixo na seção de módulos Lua:

```ini
lua.module = "overmem_copa_do_brasil.lua"
```

## Comportamento

1. O módulo tenta aplicar no `init` o unlock inicial do patch.
2. O caminho literal de `unlock` e de bloco completo `ORIGINAL_21 -> COPA_DO_BRASIL` foi desabilitado neste momento, porque no runtime atual ele atingiu hits literais inseguros.
3. O patch ativo hoje é o fallback do record principal já validado da final (`2026-03-28 -> 2026-03-29`).
4. O overlay agora é apenas leitura de estado em cache; ele não dispara novas buscas em memória.
5. `PageUp` força uma reaplicação manual.
6. `PageDown` reseta os estados locais do módulo para uma nova sondagem manual.
7. O overlay continua expondo cinco estados: `carga`, `unlock`, `cal`, `fb` e `ui`.

## Limite atual

1. Este módulo ainda não corrige a cache derivada/UI residual que pode continuar exibindo `28`.
2. Ele sonda, sem escrever, a assinatura única já documentada da camada derivada/UI.
3. O caminho literal `unlock + bloco completo` foi desligado até encontrarmos a instância ativa correta do calendário.
4. O patch estrutural da competição `31` ainda não foi portado.

## Leitura esperada no overlay

1. `carga: modulo ativo | init` ou `overlay` confirma que o Sider carregou o módulo.
2. `unlock: desabilitado ... | hit literal inseguro` confirma que o caminho perigoso está desligado.
3. `cal: desabilitado ... | hit literal inseguro` confirma que o bloco completo não será escrito nesta versão.
4. `fb: aplicado ...` ou `ja aplicado ...` confirma o patch seguro do record principal.
5. `ui: assinatura derivada encontrada ...` confirma que a assinatura única da camada residual apareceu no processo.