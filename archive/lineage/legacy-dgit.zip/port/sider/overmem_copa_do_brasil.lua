-- Drop-in Sider module.
-- Install this file into Sider's modules/ directory and add the line below to sider.ini:
-- lua.module = "overmem_copa_do_brasil.lua"

local memory = memory

local m = {}

local PATCH_NAME = "Overmem Copa do Brasil"
local PAGE_UP = 0x21
local PAGE_DOWN = 0x22

local PRIMARY_OLD_RECORD = "\x44\x00\x35\x20\xEA\x07\x03\x1C"
local PRIMARY_NEW_RECORD = "\x44\x00\x35\x20\xEA\x07\x03\x1D"
local LEGACY_OLD_RECORD = "\x1F\x00\x35\x10\xEA\x07\x03\x1C"
local LEGACY_NEW_RECORD = "\x1F\x00\x35\x10\xEA\x07\x03\x1D"
local OLD_DATE = "\xEA\x07\x03\x1C"
local NEW_DATE = "\xEA\x07\x03\x1D"
local DATE_FIELD_OFFSET = 4
local UI_CANDIDATE = "\x1F\x00\x00\x00\x56\x00\x00\x00\x1D\x00\x00\x00\x66\x01\x00\x00\xF3\x0D\x00\x00"

local load_status = "nao inicializado"
local unlock_status = "desabilitado"
local calendar_status = "desabilitado"
local fallback_status = "aguardando alvo"
local ui_status = "nao sondado"
local patched = false
local last_main_address = nil
local last_ui_address = nil
local overlay_retry_pending = true

local function append_status(parts, value)
    if value and value ~= "" then
        table.insert(parts, value)
    end
end

local function format_address(addr)
    if not addr then
        return "n/a"
    end

    if memory.hex then
        return memory.hex(addr)
    end

    return string.format("0x%X", addr)
end

local function write_log(message)
    if log then
        log(string.format("[%s] %s", PATCH_NAME, message))
    end
end

local function log_statuses(reason)
    write_log(string.format(
        "%s | unlock=%s | cal=%s | fb=%s | ui=%s",
        reason,
        unlock_status,
        calendar_status,
        fallback_status,
        ui_status))
end

local function try_apply_record(label, old_record, new_record, reason)
    local new_addr = memory.search_process(new_record)
    if new_addr then
        return true, string.format("%s ja aplicado | %s | %s", label, reason, format_address(new_addr)), new_addr
    end

    local old_addr = memory.search_process(old_record)
    if not old_addr then
        return false, string.format("%s ausente | %s", label, reason), nil
    end

    local current_date = memory.read(old_addr + DATE_FIELD_OFFSET, 4)
    if current_date ~= OLD_DATE then
        return false, string.format("%s data inesperada | %s | %s", label, reason, format_address(old_addr)), old_addr
    end

    memory.write(old_addr + DATE_FIELD_OFFSET, NEW_DATE)

    local after_date = memory.read(old_addr + DATE_FIELD_OFFSET, 4)
    if after_date ~= NEW_DATE then
        return false, string.format("%s falha no reread | %s | %s", label, reason, format_address(old_addr)), old_addr
    end

    return true, string.format("%s aplicado | %s | %s", label, reason, format_address(old_addr)), old_addr
end

local function try_apply_main_fallback(reason)
    local status_parts = {}

    local primary_ok, primary_status, primary_addr = try_apply_record(
        "principal 68/53",
        PRIMARY_OLD_RECORD,
        PRIMARY_NEW_RECORD,
        reason)
    append_status(status_parts, primary_status)
    if primary_addr then
        last_main_address = primary_addr
    end

    local legacy_ok, legacy_status, legacy_addr = try_apply_record(
        "legado 31/53",
        LEGACY_OLD_RECORD,
        LEGACY_NEW_RECORD,
        reason)
    append_status(status_parts, legacy_status)
    if not last_main_address and legacy_addr then
        last_main_address = legacy_addr
    end

    patched = primary_ok or legacy_ok
    fallback_status = table.concat(status_parts, " | ")
    if primary_ok and primary_addr then
        write_log("record principal 68/53 aplicado")
    elseif legacy_ok and legacy_addr then
        write_log("record legado 31/53 aplicado")
    end

    return patched
end

local function probe_ui_candidate(reason)
    local ui_addr = memory.search_process(UI_CANDIDATE)
    if not ui_addr then
        last_ui_address = nil
        ui_status = string.format("assinatura derivada ausente | %s", reason)
        return false
    end

    last_ui_address = ui_addr
    ui_status = string.format("assinatura derivada encontrada | %s | %s", reason, format_address(ui_addr))
    return true
end

local function refresh(reason)
    load_status = string.format("modulo ativo | %s", reason)
    unlock_status = string.format("desabilitado | %s | hit literal inseguro", reason)
    calendar_status = string.format("desabilitado | %s | hit literal inseguro", reason)
    try_apply_main_fallback(reason)

    probe_ui_candidate(reason)
    log_statuses(reason)
end

function m.init(ctx)
    ctx.register("key_up", m.key_up)
    ctx.register("overlay_on", m.overlay_on)
    write_log("modulo carregado")
    refresh("init")
    overlay_retry_pending = not patched
    return PATCH_NAME
end

function m.key_up(ctx, vkey)
    if vkey == PAGE_UP then
        patched = false
        refresh("manual")
        overlay_retry_pending = not patched
    elseif vkey == PAGE_DOWN then
        patched = false
        last_main_address = nil
        last_ui_address = nil
        load_status = "modulo ativo | reset manual"
        unlock_status = "desabilitado"
        calendar_status = "desabilitado"
        fallback_status = "aguardando alvo"
        ui_status = "nao sondado"
        overlay_retry_pending = true
    end
end

function m.overlay_on(ctx)
    if overlay_retry_pending and not patched then
        overlay_retry_pending = false
        refresh("overlay")
    end

    return string.format(
        "%s | PageUp reaplica | PageDown reseta | carga: %s | unlock: %s | cal: %s | fb: %s | ui: %s",
        PATCH_NAME,
        load_status,
        unlock_status,
        calendar_status,
        fallback_status,
        ui_status)
end

return m