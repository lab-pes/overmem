[CmdletBinding()]
param(
    [string]$CliPath = (Join-Path (Split-Path $PSScriptRoot -Parent) 'src\Overmem.Cli\bin\Debug\net8.0\Overmem.Cli.exe'),
    [string]$ProcessName = 'PES2021',
    [int]$Year = 2026,
    [uint64]$BaseAddress = 0,
    [int]$MaxRecords = 13014,
    [string]$OutputPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$maxCompetitionCode = 0x3FFF

function Get-CompetitionMap {
    $map = @{}
    $programFilesX86 = [Environment]::GetFolderPath([Environment+SpecialFolder]::ProgramFilesX86)
    if ([string]::IsNullOrWhiteSpace($programFilesX86))
    {
        return $map
    }

    $commonRoot = Join-Path $programFilesX86 'Steam\steamapps\common'
    if (-not (Test-Path $commonRoot))
    {
        return $map
    }

    $roots = Get-ChildItem $commonRoot -Directory -Filter 'eFootball PES 2021*' -ErrorAction SilentlyContinue
    foreach ($root in $roots)
    {
        $gogoszMenuMapPath = Join-Path $root.FullName 'GOGOSZ\Menu Server\map_competitions.txt'
        if (Test-Path $gogoszMenuMapPath)
        {
            foreach ($line in Get-Content $gogoszMenuMapPath)
            {
                if ($line -match '^\s*(\d+)\s*,\s*([^#]+?)\s*(?:#.*)?$')
                {
                    $code = [int]$matches[1]
                    $label = $matches[2].Trim()
                    if ($label.Length -gt 0 -and -not $map.ContainsKey($code))
                    {
                        $map[$code] = $label
                    }
                }
            }
        }

        $menuMapPath = Join-Path $root.FullName 'BMPES\Servidor de Menus\map_competitions.txt'
        if (Test-Path $menuMapPath)
        {
            foreach ($line in Get-Content $menuMapPath)
            {
                if ($line -match '^\s*(\d+)\s*,\s*([^#]+?)\s*(?:#.*)?$')
                {
                    $code = [int]$matches[1]
                    $label = $matches[2].Trim()
                    if ($label.Length -gt 0 -and -not $map.ContainsKey($code))
                    {
                        $map[$code] = $label
                    }
                }
            }
        }

        $tournamentsPath = Join-Path $root.FullName 'doc\tournaments.txt'
        if (Test-Path $tournamentsPath)
        {
            foreach ($line in Get-Content $tournamentsPath)
            {
                if ($line -match '^\s*(.+?)\s*-\s*(\d+)\s*$')
                {
                    $label = $matches[1].Trim()
                    $code = [int]$matches[2]
                    if ($label.Length -gt 0 -and -not $map.ContainsKey($code))
                    {
                        $map[$code] = $label
                    }
                }
            }
        }
    }

    return $map
}

function Invoke-CliJson {
    param(
        [Parameter(Mandatory = $true)]
        [string[]]$Arguments
    )

    $text = & $CliPath @Arguments 2>$null | Out-String
    $trimmed = $text.Trim()

    if ([string]::IsNullOrWhiteSpace($trimmed))
    {
        throw "CLI output was empty. Command: $($Arguments -join ' ')"
    }

    return $trimmed | ConvertFrom-Json
}

if (-not (Test-Path $CliPath))
{
    throw "CLI executable not found at '$CliPath'. Build Overmem.Cli first or pass -CliPath explicitly."
}

$resolvedCliPath = (Resolve-Path $CliPath).ProviderPath

if (-not $PSBoundParameters.ContainsKey('OutputPath'))
{
    $OutputPath = Join-Path $env:TEMP ("overmem-calendar-family-map-{0}.json" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
}

$outputDirectory = Split-Path -Parent $OutputPath

if ($outputDirectory -and -not (Test-Path $outputDirectory))
{
    New-Item -ItemType Directory -Path $outputDirectory -Force | Out-Null
}

$summaryArguments = @(
    'pes2021-calendar-summary',
    '--name', $ProcessName,
    '--max-records', $MaxRecords.ToString()
)

if ($BaseAddress -ne 0)
{
    $summaryArguments += @('--base-address', $BaseAddress.ToString())
}

$summary = Invoke-CliJson -Arguments $summaryArguments

if ($BaseAddress -eq 0)
{
    $BaseAddress = [uint64]$summary.BaseAddress
}

$competitionNameMap = Get-CompetitionMap

$readSize = $MaxRecords * 596
$rawRead = Invoke-CliJson -Arguments @(
    'read',
    '--name', $ProcessName,
    '--address', $BaseAddress.ToString(),
    '--value-kind', 'Bytes',
    '--size', $readSize.ToString()
)

$bytes = [Convert]::FromHexString([string]$rawRead.Value)
$recordStride = 596
$rawRecordCount = [math]::Floor($bytes.Length / $recordStride)
$records = New-Object System.Collections.Generic.List[object]

for ($index = 0; $index -lt $rawRecordCount; $index++)
{
    $offset = $index * $recordStride
    $competitionCode = [BitConverter]::ToUInt16($bytes, $offset + 0x00)
    $round = $bytes[$offset + 0x02]
    $yearValue = [BitConverter]::ToUInt16($bytes, $offset + 0x04)
    $monthValue = $bytes[$offset + 0x06]
    $dayValue = $bytes[$offset + 0x07]

    if ($competitionCode -le 0 -or $competitionCode -gt $maxCompetitionCode)
    {
        continue
    }

    if ($yearValue -ne $Year)
    {
        continue
    }

    if ($monthValue -lt 1 -or $monthValue -gt 12 -or $dayValue -lt 1 -or $dayValue -gt 31)
    {
        continue
    }

    if ($round -lt 0 -or $round -gt 80)
    {
        continue
    }

    $records.Add([pscustomobject]@{
        Date = ('{0:D4}-{1:D2}-{2:D2}' -f $yearValue, $monthValue, $dayValue)
        CompetitionCode = [int]$competitionCode
        Round = [int]$round
    })
}

$dateReports = $records |
    Group-Object Date |
    Sort-Object Name |
    ForEach-Object {
        $competitions = @(
            $_.Group |
                Group-Object CompetitionCode |
                Sort-Object Name |
                ForEach-Object {
                    $rounds = @($_.Group | Select-Object -ExpandProperty Round -Unique | Sort-Object)
                    [pscustomobject]@{
                        CompetitionCode = [int]$_.Name
                        CompetitionName = if ($competitionNameMap.ContainsKey([int]$_.Name)) { [string]$competitionNameMap[[int]$_.Name] } else { 'DESCONHECIDA' }
                        MatchCount = [int]$_.Count
                        Rounds = ($rounds | ForEach-Object { $_.ToString() }) -join ','
                    }
                }
        )

        [pscustomobject]@{
            Date = [string]$_.Name
            MatchCount = [int]$_.Count
            CompetitionCount = [int]$competitions.Count
            Competitions = $competitions
        }
    }

$competitionMap = $records |
    Group-Object CompetitionCode |
    Sort-Object Name |
    ForEach-Object {
        $dates = @(
            $_.Group |
                Group-Object Date |
                Sort-Object Name |
                ForEach-Object {
                    $rounds = @($_.Group | Select-Object -ExpandProperty Round -Unique | Sort-Object)
                    [pscustomobject]@{
                        Date = [string]$_.Name
                        MatchCount = [int]$_.Count
                        Rounds = ($rounds | ForEach-Object { $_.ToString() }) -join ','
                    }
                }
        )

        [pscustomobject]@{
            CompetitionCode = [int]$_.Name
            CompetitionName = if ($competitionNameMap.ContainsKey([int]$_.Name)) { [string]$competitionNameMap[[int]$_.Name] } else { 'DESCONHECIDA' }
            TotalDates = [int]$dates.Count
            TotalMatches = [int]$_.Count
            Dates = $dates
        }
    } |
    Sort-Object CompetitionCode

$result = [pscustomobject]@{
    TimestampUtc = (Get-Date).ToUniversalTime().ToString('o')
    CliPath = $resolvedCliPath
    ProcessName = $ProcessName
    Year = $Year
    BaseAddress = $BaseAddress
    RecordStride = $recordStride
    RawRecordCount = $rawRecordCount
    BytesRead = [int]$rawRead.BytesRead
    SummaryDateCount = [int]$summary.TotalDates
    SummaryMatchCount = [int]$summary.TotalMatches
    DateReports = @($dateReports)
    CompetitionMap = $competitionMap
}

$result | ConvertTo-Json -Depth 8 | Set-Content -Path $OutputPath -Encoding utf8
$result | ConvertTo-Json -Depth 8