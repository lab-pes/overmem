[CmdletBinding()]
param(
    [string]$CliPath = (Join-Path (Split-Path $PSScriptRoot -Parent) 'src\Overmem.Cli\bin\Debug\net8.0\Overmem.Cli.exe'),
    [string]$ConfigPath = (Join-Path $PSScriptRoot 'copa-do-brasil-supporting-data.json'),
    [string]$ProcessName = 'PES2021',
    [int]$CompetitionCode = 31,
    [uint64]$BaseAddress = 0,
    [int]$ExpectedRound = 53,
    [string]$OldDate = '2026-03-28',
    [string]$NewDate = '2026-03-29',
    [int]$DateFieldOffset = 4,
    [int]$PreviewSize = 8,
    [switch]$Apply
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-PortConfig {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    if (-not (Test-Path $Path))
    {
        return $null
    }

    $resolvedPath = (Resolve-Path $Path).ProviderPath
    return [System.IO.File]::ReadAllText($resolvedPath) | ConvertFrom-Json
}

function Invoke-CliJson {
    param(
        [Parameter(Mandatory = $true)]
        [string[]]$Arguments
    )

    $text = & $CliPath @Arguments 2>&1 | Out-String
    $start = $text.IndexOf('{')
    $end = $text.LastIndexOf('}')

    if ($start -lt 0 -or $end -lt $start)
    {
        throw "CLI output did not contain a JSON object. Command: $($Arguments -join ' ')"
    }

    return $text.Substring($start, ($end - $start) + 1) | ConvertFrom-Json
}

function Convert-DateToRuntimeBytes {
    param(
        [Parameter(Mandatory = $true)]
        [datetime]$Date
    )

    $yearBytes = [BitConverter]::GetBytes([uint16]$Date.Year)
    return '{0}{1}{2:X2}{3:X2}' -f $yearBytes[0].ToString('X2'), $yearBytes[1].ToString('X2'), $Date.Month, $Date.Day
}

function Convert-CompetitionToPrefix {
    param(
        [Parameter(Mandatory = $true)]
        [int]$Code
    )

    $codeBytes = [BitConverter]::GetBytes([uint16]$Code)
    return '{0} {1}' -f $codeBytes[0].ToString('X2'), $codeBytes[1].ToString('X2')
}

function Get-DatePattern {
    param(
        [Parameter(Mandatory = $true)]
        [int]$Code,
        [Parameter(Mandatory = $true)]
        [datetime]$Date
    )

    $prefix = Convert-CompetitionToPrefix -Code $Code
    $dateBytes = Convert-DateToRuntimeBytes -Date $Date
    return '{0} ?? ?? {1} {2} {3} {4}' -f $prefix, $dateBytes.Substring(0, 2), $dateBytes.Substring(2, 2), $dateBytes.Substring(4, 2), $dateBytes.Substring(6, 2)
}

function Resolve-UniqueMatchAddress {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Pattern,
        [Parameter(Mandatory = $true)]
        [string]$Purpose
    )

    $scan = Invoke-CliJson -Arguments @(
        'scan-pattern',
        '--name', $ProcessName,
        '--pattern', $Pattern,
        '--max-results', '4'
    )

    $addresses = @($scan.Addresses)

    if ($addresses.Count -eq 0)
    {
        return $null
    }

    if ($addresses.Count -gt 1)
    {
        throw "$Purpose pattern is ambiguous. Found $($addresses.Count) matches for '$Pattern'."
    }

    return [uint64]$addresses[0]
}

function Resolve-UniqueMatchAddressFromDate {
    param(
        [Parameter(Mandatory = $true)]
        [datetime]$Date,
        [Parameter(Mandatory = $true)]
        [string]$Purpose
    )

    if ($BaseAddress -eq 0)
    {
        return $null
    }

    $report = Invoke-CliJson -Arguments @(
        'pes2021-dump-calendar-date',
        '--name', $ProcessName,
        '--year', $Date.Year.ToString(),
        '--month', $Date.Month.ToString(),
        '--day', $Date.Day.ToString(),
        '--base-address', $BaseAddress.ToString()
    )

    $matches = @($report.Matches | Where-Object {
        $_.CompetitionCode -eq $CompetitionCode -and $_.Round -eq $ExpectedRound
    })

    if ($matches.Count -eq 0)
    {
        return $null
    }

    if ($matches.Count -gt 1)
    {
        throw "$Purpose date lookup is ambiguous. Found $($matches.Count) matches for competition $CompetitionCode round $ExpectedRound on $($Date.ToString('yyyy-MM-dd'))."
    }

    return [uint64]$matches[0].Address
}

if (-not (Test-Path $CliPath))
{
    throw "CLI executable not found at '$CliPath'. Build Overmem.Cli first or pass -CliPath explicitly."
}

$config = Get-PortConfig -Path $ConfigPath

if ($config -and -not $PSBoundParameters.ContainsKey('ProcessName') -and $config.ProcessName)
{
    $ProcessName = [string]$config.ProcessName
}

if ($config -and -not $PSBoundParameters.ContainsKey('BaseAddress') -and $null -ne $config.CalendarBaseAddress)
{
    $BaseAddress = [uint64]$config.CalendarBaseAddress
}

$oldDateValue = [datetime]::ParseExact($OldDate, 'yyyy-MM-dd', [System.Globalization.CultureInfo]::InvariantCulture)
$newDateValue = [datetime]::ParseExact($NewDate, 'yyyy-MM-dd', [System.Globalization.CultureInfo]::InvariantCulture)

$oldPattern = Get-DatePattern -Code $CompetitionCode -Date $oldDateValue
$newPattern = Get-DatePattern -Code $CompetitionCode -Date $newDateValue
$newDateBytes = Convert-DateToRuntimeBytes -Date $newDateValue

$oldAddress = Resolve-UniqueMatchAddressFromDate -Date $oldDateValue -Purpose 'Old-date'

if ($null -eq $oldAddress)
{
    $oldAddress = Resolve-UniqueMatchAddress -Pattern $oldPattern -Purpose 'Old-date'
}

$newAddress = $null

if ($null -eq $oldAddress)
{
    $newAddress = Resolve-UniqueMatchAddressFromDate -Date $newDateValue -Purpose 'New-date'

    if ($null -eq $newAddress)
    {
        $newAddress = Resolve-UniqueMatchAddress -Pattern $newPattern -Purpose 'New-date'
    }

    if ($null -eq $newAddress)
    {
        throw "Neither the old pattern '$oldPattern' nor the new pattern '$newPattern' matched the process uniquely."
    }
}

$targetAddress = if ($null -ne $oldAddress) { $oldAddress } else { $newAddress }
$dateFieldAddress = $targetAddress + [uint64]$DateFieldOffset

$before = Invoke-CliJson -Arguments @(
    'read',
    '--name', $ProcessName,
    '--address', $targetAddress.ToString(),
    '--value-kind', 'Bytes',
    '--size', $PreviewSize.ToString()
)

$status = if ($null -ne $oldAddress) { 'Patchable' } else { 'AlreadyPatched' }
$writeResult = $null
$after = $before

if ($Apply -and $null -ne $oldAddress)
{
    $writeResult = Invoke-CliJson -Arguments @(
        'write',
        '--name', $ProcessName,
        '--address', $dateFieldAddress.ToString(),
        '--value-kind', 'Bytes',
        '--size', '4',
        '--value', $newDateBytes
    )

    $after = Invoke-CliJson -Arguments @(
        'read',
        '--name', $ProcessName,
        '--address', $targetAddress.ToString(),
        '--value-kind', 'Bytes',
        '--size', $PreviewSize.ToString()
    )

    $status = 'Patched'
}

$result = [pscustomobject]@{
    Script = $MyInvocation.MyCommand.Path
    ConfigPath = if (Test-Path $ConfigPath) { (Resolve-Path $ConfigPath).ProviderPath } else { $null }
    Mode = if ($Apply) { 'apply' } else { 'dry-run' }
    ProcessName = $ProcessName
    CompetitionCode = $CompetitionCode
    BaseAddress = $BaseAddress
    ExpectedRound = $ExpectedRound
    OldDate = $oldDateValue.ToString('yyyy-MM-dd')
    NewDate = $newDateValue.ToString('yyyy-MM-dd')
    OldPattern = $oldPattern
    NewPattern = $newPattern
    TargetAddress = $targetAddress
    DateFieldAddress = $dateFieldAddress
    Status = $status
    Before = [pscustomobject]@{
        Address = $targetAddress
        Bytes = $before.Value
    }
    IntendedWrite = [pscustomobject]@{
        Address = $dateFieldAddress
        Bytes = $newDateBytes
    }
    WriteResult = $writeResult
    After = [pscustomobject]@{
        Address = $targetAddress
        Bytes = $after.Value
    }
}

$result | ConvertTo-Json -Depth 6