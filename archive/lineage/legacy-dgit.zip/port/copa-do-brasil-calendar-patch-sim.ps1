[CmdletBinding()]
param(
    [string]$CliPath = (Join-Path (Split-Path $PSScriptRoot -Parent) 'src\Overmem.Cli\bin\Debug\net8.0\Overmem.Cli.exe'),
    [string]$ConfigPath = (Join-Path $PSScriptRoot 'copa-do-brasil-supporting-data.json'),
    [string]$ProcessName = 'PES2021',
    [uint64]$BaseAddress = 140689614307100,
    [string]$Date = '2026-02-01',
    [int]$CompetitionCode = 31,
    [int]$SampleSize = 3,
    [switch]$IncludeAllCompetitionMatches
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-PortConfig {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    if (-not (Test-Path $Path))
    {
        return $null
    }

    $resolvedPath = (Resolve-Path $Path).ProviderPath
    return [System.IO.File]::ReadAllText($resolvedPath) | ConvertFrom-Json
}

function Invoke-CliJson {
    param(
        [Parameter(Mandatory = $true)]
        [string[]]$Arguments
    )

    $text = & $CliPath @Arguments 2>&1 | Out-String
    $start = $text.IndexOf('{')
    $end = $text.LastIndexOf('}')

    if ($start -lt 0 -or $end -lt $start)
    {
        throw "CLI output did not contain a JSON object. Command: $($Arguments -join ' ')"
    }

    return $text.Substring($start, ($end - $start) + 1) | ConvertFrom-Json
}

if (-not (Test-Path $CliPath))
{
    throw "CLI executable not found at '$CliPath'. Build Overmem.Cli first or pass -CliPath explicitly."
}

$config = Get-PortConfig -Path $ConfigPath

if ($config)
{
    if (-not $PSBoundParameters.ContainsKey('ProcessName') -and $config.ProcessName)
    {
        $ProcessName = [string]$config.ProcessName
    }

    if (-not $PSBoundParameters.ContainsKey('BaseAddress') -and $null -ne $config.CalendarBaseAddress)
    {
        $BaseAddress = [uint64]$config.CalendarBaseAddress
    }

    if (-not $PSBoundParameters.ContainsKey('Date') -and $config.DefaultProbeDate)
    {
        $Date = [string]$config.DefaultProbeDate
    }

    if (-not $PSBoundParameters.ContainsKey('CompetitionCode') -and $null -ne $config.CompetitionId)
    {
        $CompetitionCode = [int]$config.CompetitionId
    }
}

$targetDate = [datetime]::ParseExact($Date, 'yyyy-MM-dd', [System.Globalization.CultureInfo]::InvariantCulture)
$previousDate = $targetDate.AddDays(-1)
$targetDateText = $targetDate.ToString('yyyy-MM-dd')
$previousDateText = $previousDate.ToString('yyyy-MM-dd')

$dateReport = Invoke-CliJson -Arguments @(
    'pes2021-dump-calendar-date',
    '--name', $ProcessName,
    '--year', $targetDate.Year.ToString(),
    '--month', $targetDate.Month.ToString(),
    '--day', $targetDate.Day.ToString(),
    '--base-address', $BaseAddress.ToString()
)

$inventory = Invoke-CliJson -Arguments @(
    'pes2021-inventory-annual-events',
    '--name', $ProcessName,
    '--year', $targetDate.Year.ToString(),
    '--calendar-base-address', $BaseAddress.ToString()
)

$competitionSummary = $dateReport.Competitions | Where-Object CompetitionCode -eq $CompetitionCode | Select-Object -First 1

if (-not $competitionSummary)
{
    throw "CompetitionCode $CompetitionCode was not found on $targetDateText."
}

$competitionMatches = @($dateReport.Matches | Where-Object CompetitionCode -eq $CompetitionCode)
$currentDayInventory = $inventory.Days | Where-Object Date -eq $targetDateText | Select-Object -First 1
$previousDayInventory = $inventory.Days | Where-Object Date -eq $previousDateText | Select-Object -First 1

$result = [pscustomobject]@{
    ConfigPath = if (Test-Path $ConfigPath) { (Resolve-Path $ConfigPath).ProviderPath } else { $null }
    Date = $targetDateText
    BaseAddress = $BaseAddress
    CompetitionCode = $CompetitionCode
    CompetitionName = $competitionSummary.CompetitionName
    CompetitionMatchCount = [int]$competitionSummary.MatchCount
    CompetitionRounds = $competitionSummary.Rounds
    TotalMatches = [int]$dateReport.TotalMatches
    TotalCompetitions = [int]$dateReport.TotalCompetitions
    SourceRole = $dateReport.SourceRole
    Visibility = $dateReport.Visibility
    StopState = $dateReport.StopState
    Pairing = [pscustomobject]@{
        PreviousDate = $previousDateText
        PreviousSecondaryCount = if ($previousDayInventory) { [int]$previousDayInventory.SecondaryCount } else { $null }
        PreviousPatternKey = if ($previousDayInventory) { $previousDayInventory.InventoryPatternKey } else { $null }
        PreviousSemanticEventKey = if ($previousDayInventory) { $previousDayInventory.SemanticEventKey } else { $null }
        PreviousNextDayMainMatchCount = if ($previousDayInventory) { [int]$previousDayInventory.NextDayMainMatchCount } else { $null }
        CurrentMainMatchCount = if ($currentDayInventory) { [int]$currentDayInventory.MainMatchCount } else { [int]$dateReport.TotalMatches }
        PairingMatches = if ($previousDayInventory) { [int]$previousDayInventory.SecondaryCount -eq [int]$dateReport.TotalMatches } else { $false }
    }
    CompetitionMix = @($dateReport.Competitions)
    MatchSamples = [pscustomobject]@{
        First = @($competitionMatches | Select-Object -First $SampleSize)
        Last = @($competitionMatches | Select-Object -Last $SampleSize)
    }
    AllCompetitionMatches = if ($IncludeAllCompetitionMatches) { $competitionMatches } else { $null }
}

$result | ConvertTo-Json -Depth 6
