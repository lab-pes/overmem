[CmdletBinding()]
param(
    [string]$CliPath = (Join-Path (Split-Path $PSScriptRoot -Parent) 'src\Overmem.Cli\bin\Debug\net8.0\Overmem.Cli.exe'),
    [string]$ConfigPath = (Join-Path $PSScriptRoot 'copa-do-brasil-supporting-data.json'),
    [string]$OutputPath,
    [switch]$IncludeAllRecords,
    [switch]$IncludeAllCompetitionMatches
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-PortConfig {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    if (-not (Test-Path $Path))
    {
        throw "Supporting data file was not found at '$Path'."
    }

    $resolvedPath = (Resolve-Path $Path).ProviderPath
    return [System.IO.File]::ReadAllText($resolvedPath) | ConvertFrom-Json
}

function Get-CheckValue {
    param(
        [Parameter(Mandatory = $true)]
        [bool]$Condition,
        [Parameter(Mandatory = $true)]
        [object]$Expected,
        [Parameter(Mandatory = $true)]
        [object]$Actual
    )

    return [pscustomobject]@{
        Passed = $Condition
        Expected = $Expected
        Actual = $Actual
    }
}

$config = Get-PortConfig -Path $ConfigPath
$resolvedConfigPath = (Resolve-Path $ConfigPath).ProviderPath
$resolvedCliPath = (Resolve-Path $CliPath).ProviderPath

if (-not $PSBoundParameters.ContainsKey('OutputPath'))
{
    $OutputPath = Join-Path $env:TEMP ("overmem-copa-do-brasil-validation-{0}.json" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
}

$outputDirectory = Split-Path -Parent $OutputPath

if ($outputDirectory -and -not (Test-Path $outputDirectory))
{
    New-Item -ItemType Directory -Path $outputDirectory -Force | Out-Null
}

$remapScript = Join-Path $PSScriptRoot 'copa-do-brasil-remap-probe.ps1'
$calendarScript = Join-Path $PSScriptRoot 'copa-do-brasil-calendar-patch-sim.ps1'
$resolvedRemapScript = (Resolve-Path $remapScript).ProviderPath
$resolvedCalendarScript = (Resolve-Path $calendarScript).ProviderPath

$remapArgs = @{
    CliPath = $resolvedCliPath
    ConfigPath = $resolvedConfigPath
}

if ($IncludeAllRecords)
{
    $remapArgs.IncludeAllRecords = $true
}

$remapResult = & $resolvedRemapScript @remapArgs | ConvertFrom-Json

$calendarResults = foreach ($entry in $config.ValidationDates)
{
    $calendarArgs = @{
        CliPath = $resolvedCliPath
        ConfigPath = $resolvedConfigPath
        Date = [string]$entry.Date
    }

    if ($IncludeAllCompetitionMatches)
    {
        $calendarArgs.IncludeAllCompetitionMatches = $true
    }

    $probe = & $resolvedCalendarScript @calendarArgs | ConvertFrom-Json

    $checks = [ordered]@{
        TotalMatches = Get-CheckValue -Condition ([int]$probe.TotalMatches -eq [int]$entry.ExpectedTotalMatches) -Expected $entry.ExpectedTotalMatches -Actual $probe.TotalMatches
        CompetitionMatches = Get-CheckValue -Condition ([int]$probe.CompetitionMatchCount -eq [int]$entry.ExpectedCompetitionMatches) -Expected $entry.ExpectedCompetitionMatches -Actual $probe.CompetitionMatchCount
        CompetitionRounds = Get-CheckValue -Condition ([string]$probe.CompetitionRounds -eq [string]$entry.ExpectedRounds) -Expected $entry.ExpectedRounds -Actual $probe.CompetitionRounds
        PreviousSecondaryCount = Get-CheckValue -Condition ([int]$probe.Pairing.PreviousSecondaryCount -eq [int]$entry.ExpectedPreviousSecondaryCount) -Expected $entry.ExpectedPreviousSecondaryCount -Actual $probe.Pairing.PreviousSecondaryCount
        PairingMatches = Get-CheckValue -Condition ([bool]$probe.Pairing.PairingMatches) -Expected $true -Actual $probe.Pairing.PairingMatches
    }

    if ($entry.PSObject.Properties.Name -contains 'ExpectedPreviousPatternKey')
    {
        $checks['PreviousPatternKey'] = Get-CheckValue -Condition ([string]$probe.Pairing.PreviousPatternKey -eq [string]$entry.ExpectedPreviousPatternKey) -Expected $entry.ExpectedPreviousPatternKey -Actual $probe.Pairing.PreviousPatternKey
    }

    if ($entry.PSObject.Properties.Name -contains 'ExpectedPreviousSemanticEventKey')
    {
        $checks['PreviousSemanticEventKey'] = Get-CheckValue -Condition ([string]$probe.Pairing.PreviousSemanticEventKey -eq [string]$entry.ExpectedPreviousSemanticEventKey) -Expected $entry.ExpectedPreviousSemanticEventKey -Actual $probe.Pairing.PreviousSemanticEventKey
    }

    $allChecksPassed = (@($checks.Values | Where-Object { -not $_.Passed }).Count -eq 0)

    [pscustomobject]@{
        Date = [string]$entry.Date
        Role = [string]$entry.Role
        Expected = $entry
        Actual = $probe
        Checks = [pscustomobject]$checks
        AllChecksPassed = $allChecksPassed
    }
}

$summary = [pscustomobject]@{
    ReadOnlyHarness = $true
    QuartetCount = @($calendarResults).Count
    PassedDates = @($calendarResults | Where-Object AllChecksPassed).Count
    FailedDates = @($calendarResults | Where-Object { -not $_.AllChecksPassed }).Count
    AllChecksPassed = (@($calendarResults | Where-Object { -not $_.AllChecksPassed }).Count -eq 0)
    RemapTargetCompetitionId = [int]$remapResult.TargetRecord.CompetitionId
    RemapTargetRecordAddress = [uint64]$remapResult.TargetRecord.RecordAddress
}

$result = [pscustomobject]@{
    TimestampUtc = (Get-Date).ToUniversalTime().ToString('o')
    ConfigPath = $resolvedConfigPath
    CliPath = $resolvedCliPath
    OutputPath = $OutputPath
    RemapProbe = $remapResult
    CalendarValidation = @($calendarResults)
    Summary = $summary
}

$result | ConvertTo-Json -Depth 8 | Set-Content -Path $OutputPath -Encoding utf8
$result | ConvertTo-Json -Depth 8