[CmdletBinding()]
param(
    [string]$CliPath = (Join-Path (Split-Path $PSScriptRoot -Parent) 'src\Overmem.Cli\bin\Debug\net8.0\Overmem.Cli.exe'),
    [string]$ProcessName = 'PES2021',
    [string]$Date = '2026-03-28',
    [string]$OutputPath,
    [uint64]$CalendarBaseAddress = 0,
    [uint64]$SecondaryBaseAddress = 0,
    [uint64]$StartAddress = 0,
    [uint64]$StopAddress = 0,
    [string]$PreferredStrides = '',
    [int]$MinHitCount = 4,
    [int]$ClusterGap = 4096,
    [int]$PreviewBytes = 256,
    [int]$MaxRecords = 13014,
    [switch]$IncludeAnnualInventory
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Invoke-CliJson {
    param(
        [Parameter(Mandatory = $true)]
        [string[]]$Arguments
    )

    $text = & $CliPath @Arguments 2>&1 | Out-String
    $start = $text.IndexOf('{')
    $end = $text.LastIndexOf('}')

    if ($start -lt 0 -or $end -lt $start)
    {
        throw "CLI output did not contain a JSON object. Command: $($Arguments -join ' ')"
    }

    return $text.Substring($start, ($end - $start) + 1) | ConvertFrom-Json
}

function Invoke-CaptureStep {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Name,
        [Parameter(Mandatory = $true)]
        [string[]]$Arguments
    )

    try
    {
        $result = Invoke-CliJson -Arguments $Arguments
        return [pscustomobject]@{
            Name = $Name
            Success = $true
            Arguments = @($Arguments)
            Result = $result
            Error = $null
        }
    }
    catch
    {
        return [pscustomobject]@{
            Name = $Name
            Success = $false
            Arguments = @($Arguments)
            Result = $null
            Error = $_.Exception.Message
        }
    }
}

function New-DateArguments {
    param(
        [Parameter(Mandatory = $true)]
        [datetime]$Value
    )

    return @(
        '--year', $Value.Year.ToString(),
        '--month', $Value.Month.ToString(),
        '--day', $Value.Day.ToString()
    )
}

function Get-DateOnlyPattern {
    param(
        [Parameter(Mandatory = $true)]
        [datetime]$Value
    )

    $yearBytes = [BitConverter]::GetBytes([uint16]$Value.Year)
    return '?? ?? ?? ?? {0} {1} {2:X2} {3:X2}' -f $yearBytes[0].ToString('X2'), $yearBytes[1].ToString('X2'), $Value.Month, $Value.Day
}

function Add-OptionalArgument {
    param(
        [Parameter(Mandatory = $true)]
        [System.Collections.Generic.List[string]]$List,
        [Parameter(Mandatory = $true)]
        [string]$Name,
        [Parameter(Mandatory = $true)]
        [AllowEmptyString()]
        [string]$Value
    )

    if (-not [string]::IsNullOrWhiteSpace($Value))
    {
        $List.Add($Name)
        $List.Add($Value)
    }
}

if (-not (Test-Path $CliPath))
{
    throw "CLI executable not found at '$CliPath'. Build Overmem.Cli first or pass -CliPath explicitly."
}

$resolvedCliPath = (Resolve-Path $CliPath).ProviderPath
$dateValue = [datetime]::ParseExact($Date, 'yyyy-MM-dd', [System.Globalization.CultureInfo]::InvariantCulture)

if (-not $PSBoundParameters.ContainsKey('OutputPath'))
{
    $OutputPath = Join-Path $env:TEMP ("overmem-bmpes-runtime-capture-{0}.json" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
}

$outputDirectory = Split-Path -Parent $OutputPath

if ($outputDirectory -and -not (Test-Path $outputDirectory))
{
    New-Item -ItemType Directory -Path $outputDirectory -Force | Out-Null
}

$steps = New-Object System.Collections.Generic.List[object]

$rawDateScan = Invoke-CaptureStep -Name 'raw_date_scan' -Arguments @(
    'scan-pattern',
    '--name', $ProcessName,
    '--pattern', (Get-DateOnlyPattern -Value $dateValue),
    '--max-results', '24'
)
$steps.Add($rawDateScan)

$calendarBaseStep = Invoke-CaptureStep -Name 'calendar_base' -Arguments @(
    'pes2021-find-calendar-base',
    '--name', $ProcessName
) + (New-DateArguments -Value $dateValue) + @(
    '--max-results', '8'
)
$steps.Add($calendarBaseStep)

if ($CalendarBaseAddress -eq 0 -and $calendarBaseStep.Success -and $null -ne $calendarBaseStep.Result.NormalizedBaseAddress)
{
    $CalendarBaseAddress = [uint64]$calendarBaseStep.Result.NormalizedBaseAddress
}

$calendarDumpArguments = New-Object System.Collections.Generic.List[string]
$calendarDumpArguments.AddRange(@('pes2021-dump-calendar-date', '--name', $ProcessName))
$calendarDumpArguments.AddRange((New-DateArguments -Value $dateValue))
$calendarDumpArguments.Add('--max-records')
$calendarDumpArguments.Add($MaxRecords.ToString())

if ($CalendarBaseAddress -ne 0)
{
    $calendarDumpArguments.Add('--base-address')
    $calendarDumpArguments.Add($CalendarBaseAddress.ToString())
}

$calendarDumpStep = Invoke-CaptureStep -Name 'calendar_dump' -Arguments $calendarDumpArguments.ToArray()
$steps.Add($calendarDumpStep)

$secondaryBaseStep = Invoke-CaptureStep -Name 'secondary_base' -Arguments @(
    'pes2021-find-secondary-calendar-base-by-date',
    '--name', $ProcessName
) + (New-DateArguments -Value $dateValue) + @(
    '--max-results', '8'
)
$steps.Add($secondaryBaseStep)

if ($SecondaryBaseAddress -eq 0 -and $secondaryBaseStep.Success)
{
    if ($null -ne $secondaryBaseStep.Result.ResolvedBaseAddress)
    {
        $SecondaryBaseAddress = [uint64]$secondaryBaseStep.Result.ResolvedBaseAddress
    }
    elseif ($null -ne $secondaryBaseStep.Result.BaseAddress)
    {
        $SecondaryBaseAddress = [uint64]$secondaryBaseStep.Result.BaseAddress
    }
}

$secondaryDumpArguments = New-Object System.Collections.Generic.List[string]
$secondaryDumpArguments.AddRange(@('pes2021-dump-secondary-calendar-day', '--name', $ProcessName))
$secondaryDumpArguments.AddRange((New-DateArguments -Value $dateValue))

if ($SecondaryBaseAddress -ne 0)
{
    $secondaryDumpArguments.Add('--base-address')
    $secondaryDumpArguments.Add($SecondaryBaseAddress.ToString())
}

$secondaryDumpStep = Invoke-CaptureStep -Name 'secondary_dump' -Arguments $secondaryDumpArguments.ToArray()
$steps.Add($secondaryDumpStep)

$runtimeFamilyArguments = New-Object System.Collections.Generic.List[string]
$runtimeFamilyArguments.AddRange(@('pes2021-dump-runtime-day-payload-family', '--name', $ProcessName))
$runtimeFamilyArguments.AddRange((New-DateArguments -Value $dateValue))
Add-OptionalArgument -List $runtimeFamilyArguments -Name '--preferred-strides' -Value $PreferredStrides
$runtimeFamilyArguments.Add('--min-hit-count')
$runtimeFamilyArguments.Add($MinHitCount.ToString())
$runtimeFamilyArguments.Add('--cluster-gap')
$runtimeFamilyArguments.Add($ClusterGap.ToString())
$runtimeFamilyArguments.Add('--preview-bytes')
$runtimeFamilyArguments.Add($PreviewBytes.ToString())

if ($CalendarBaseAddress -ne 0)
{
    $runtimeFamilyArguments.Add('--calendar-base-address')
    $runtimeFamilyArguments.Add($CalendarBaseAddress.ToString())
}

if ($StartAddress -ne 0)
{
    $runtimeFamilyArguments.Add('--start-address')
    $runtimeFamilyArguments.Add($StartAddress.ToString())
}

if ($StopAddress -ne 0)
{
    $runtimeFamilyArguments.Add('--stop-address')
    $runtimeFamilyArguments.Add($StopAddress.ToString())
}

$runtimeFamilyStep = Invoke-CaptureStep -Name 'runtime_family_dump' -Arguments $runtimeFamilyArguments.ToArray()
$steps.Add($runtimeFamilyStep)

$runtimeCompareArguments = New-Object System.Collections.Generic.List[string]
$runtimeCompareArguments.AddRange(@('pes2021-compare-runtime-day-payload-family', '--name', $ProcessName))
$runtimeCompareArguments.AddRange((New-DateArguments -Value $dateValue))
Add-OptionalArgument -List $runtimeCompareArguments -Name '--preferred-strides' -Value $PreferredStrides
$runtimeCompareArguments.Add('--min-hit-count')
$runtimeCompareArguments.Add($MinHitCount.ToString())
$runtimeCompareArguments.Add('--cluster-gap')
$runtimeCompareArguments.Add($ClusterGap.ToString())
$runtimeCompareArguments.Add('--preview-bytes')
$runtimeCompareArguments.Add($PreviewBytes.ToString())

if ($CalendarBaseAddress -ne 0)
{
    $runtimeCompareArguments.Add('--calendar-base-address')
    $runtimeCompareArguments.Add($CalendarBaseAddress.ToString())
}

if ($StartAddress -ne 0)
{
    $runtimeCompareArguments.Add('--start-address')
    $runtimeCompareArguments.Add($StartAddress.ToString())
}

if ($StopAddress -ne 0)
{
    $runtimeCompareArguments.Add('--stop-address')
    $runtimeCompareArguments.Add($StopAddress.ToString())
}

$runtimeCompareStep = Invoke-CaptureStep -Name 'runtime_family_compare' -Arguments $runtimeCompareArguments.ToArray()
$steps.Add($runtimeCompareStep)

$classifyArguments = New-Object System.Collections.Generic.List[string]
$classifyArguments.AddRange(@('pes2021-classify-runtime-day-variant', '--name', $ProcessName))
$classifyArguments.AddRange((New-DateArguments -Value $dateValue))
Add-OptionalArgument -List $classifyArguments -Name '--preferred-strides' -Value $PreferredStrides
$classifyArguments.Add('--min-hit-count')
$classifyArguments.Add($MinHitCount.ToString())
$classifyArguments.Add('--cluster-gap')
$classifyArguments.Add($ClusterGap.ToString())
$classifyArguments.Add('--preview-bytes')
$classifyArguments.Add($PreviewBytes.ToString())

if ($CalendarBaseAddress -ne 0)
{
    $classifyArguments.Add('--calendar-base-address')
    $classifyArguments.Add($CalendarBaseAddress.ToString())
}

if ($SecondaryBaseAddress -ne 0)
{
    $classifyArguments.Add('--secondary-base-address')
    $classifyArguments.Add($SecondaryBaseAddress.ToString())
}

if ($StartAddress -ne 0)
{
    $classifyArguments.Add('--start-address')
    $classifyArguments.Add($StartAddress.ToString())
}

if ($StopAddress -ne 0)
{
    $classifyArguments.Add('--stop-address')
    $classifyArguments.Add($StopAddress.ToString())
}

$classifyStep = Invoke-CaptureStep -Name 'runtime_variant' -Arguments $classifyArguments.ToArray()
$steps.Add($classifyStep)

if ($IncludeAnnualInventory)
{
    $annualInventoryArguments = New-Object System.Collections.Generic.List[string]
    $annualInventoryArguments.AddRange(@(
        'pes2021-inventory-annual-events',
        '--name', $ProcessName,
        '--year', $dateValue.Year.ToString()
    ))

    if ($CalendarBaseAddress -ne 0)
    {
        $annualInventoryArguments.Add('--calendar-base-address')
        $annualInventoryArguments.Add($CalendarBaseAddress.ToString())
    }

    if ($SecondaryBaseAddress -ne 0)
    {
        $annualInventoryArguments.Add('--secondary-base-address')
        $annualInventoryArguments.Add($SecondaryBaseAddress.ToString())
    }

    $annualInventoryStep = Invoke-CaptureStep -Name 'annual_inventory' -Arguments $annualInventoryArguments.ToArray()
    $steps.Add($annualInventoryStep)
}

$summary = [pscustomobject]@{
    ReadOnlyHarness = $true
    ProcessName = $ProcessName
    Date = $Date
    CalendarBaseAddress = if ($CalendarBaseAddress -ne 0) { $CalendarBaseAddress } else { $null }
    SecondaryBaseAddress = if ($SecondaryBaseAddress -ne 0) { $SecondaryBaseAddress } else { $null }
    SuccessfulSteps = @($steps | Where-Object Success).Count
    FailedSteps = @($steps | Where-Object { -not $_.Success }).Count
    FailedStepNames = @($steps | Where-Object { -not $_.Success } | ForEach-Object { $_.Name })
}

$result = [pscustomobject]@{
    TimestampUtc = (Get-Date).ToUniversalTime().ToString('o')
    CliPath = $resolvedCliPath
    ProcessName = $ProcessName
    Date = $Date
    OutputPath = $OutputPath
    Summary = $summary
    Steps = @($steps)
}

$result | ConvertTo-Json -Depth 12 | Set-Content -Path $OutputPath -Encoding utf8
$result | ConvertTo-Json -Depth 12