[CmdletBinding()]
param(
    [string]$CliPath = (Join-Path (Split-Path $PSScriptRoot -Parent) 'src\Overmem.Cli\bin\Debug\net8.0\Overmem.Cli.exe'),
    [string]$ConfigPath = (Join-Path $PSScriptRoot 'copa-do-brasil-supporting-data.json'),
    [string]$ProcessName = 'PES2021',
    [string]$ModuleName = 'PES2021.exe',
    [int]$CompetitionId = 31,
    [string]$AnchorPattern = '00 00 00 00 00 00 00 00 01 00 00 00 4F 00 00 00',
    [int]$Stride = 264,
    [int]$RecordCount = 192,
    [int]$AnchorBaseDelta = 8,
    [switch]$IncludeAllRecords
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-PortConfig {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    if (-not (Test-Path $Path))
    {
        return $null
    }

    $resolvedPath = (Resolve-Path $Path).ProviderPath
    return [System.IO.File]::ReadAllText($resolvedPath) | ConvertFrom-Json
}

function Invoke-CliJson {
    param(
        [Parameter(Mandatory = $true)]
        [string[]]$Arguments
    )

    $text = & $CliPath @Arguments 2>&1 | Out-String
    $start = $text.IndexOf('{')
    $end = $text.LastIndexOf('}')

    if ($start -lt 0 -or $end -lt $start)
    {
        throw "CLI output did not contain a JSON object. Command: $($Arguments -join ' ')"
    }

    return $text.Substring($start, ($end - $start) + 1) | ConvertFrom-Json
}

function Convert-HexToBytes {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Hex
    )

    if (($Hex.Length % 2) -ne 0)
    {
        throw 'Hex payload must have an even number of characters.'
    }

    $bytes = New-Object byte[] ($Hex.Length / 2)

    for ($index = 0; $index -lt $bytes.Length; $index++)
    {
        $bytes[$index] = [Convert]::ToByte($Hex.Substring($index * 2, 2), 16)
    }

    return $bytes
}

function Read-UInt16Le {
    param(
        [Parameter(Mandatory = $true)]
        [byte[]]$Bytes,
        [Parameter(Mandatory = $true)]
        [int]$Offset
    )

    return [BitConverter]::ToUInt16($Bytes, $Offset)
}

function Read-UInt32Le {
    param(
        [Parameter(Mandatory = $true)]
        [byte[]]$Bytes,
        [Parameter(Mandatory = $true)]
        [int]$Offset
    )

    return [BitConverter]::ToUInt32($Bytes, $Offset)
}

function Read-ByteValue {
    param(
        [Parameter(Mandatory = $true)]
        [byte[]]$Bytes,
        [Parameter(Mandatory = $true)]
        [int]$Offset
    )

    return [int]$Bytes[$Offset]
}

$config = Get-PortConfig -Path $ConfigPath

if ($config)
{
    if (-not $PSBoundParameters.ContainsKey('ProcessName') -and $config.ProcessName)
    {
        $ProcessName = [string]$config.ProcessName
    }

    if (-not $PSBoundParameters.ContainsKey('ModuleName') -and $config.ModuleName)
    {
        $ModuleName = [string]$config.ModuleName
    }

    if (-not $PSBoundParameters.ContainsKey('CompetitionId') -and $null -ne $config.CompetitionId)
    {
        $CompetitionId = [int]$config.CompetitionId
    }

    if (-not $PSBoundParameters.ContainsKey('AnchorPattern') -and $config.AnchorPattern)
    {
        $AnchorPattern = [string]$config.AnchorPattern
    }

    if (-not $PSBoundParameters.ContainsKey('Stride') -and $null -ne $config.CompetitionTable.Stride)
    {
        $Stride = [int]$config.CompetitionTable.Stride
    }

    if (-not $PSBoundParameters.ContainsKey('RecordCount') -and $null -ne $config.CompetitionTable.RecordCount)
    {
        $RecordCount = [int]$config.CompetitionTable.RecordCount
    }

    if (-not $PSBoundParameters.ContainsKey('AnchorBaseDelta') -and $null -ne $config.CompetitionTable.AnchorBaseDelta)
    {
        $AnchorBaseDelta = [int]$config.CompetitionTable.AnchorBaseDelta
    }
}

if (-not (Test-Path $CliPath))
{
    throw "CLI executable not found at '$CliPath'. Build Overmem.Cli first or pass -CliPath explicitly."
}

$scan = Invoke-CliJson -Arguments @(
    'scan-pattern',
    '--name', $ProcessName,
    '--module-name', $ModuleName,
    '--pattern', $AnchorPattern,
    '--max-results', '2'
)

if (-not $scan.Addresses -or $scan.Addresses.Count -eq 0)
{
    throw 'Competition remap anchor was not found in the target module.'
}

if ($scan.Addresses.Count -gt 1)
{
    throw "Competition remap anchor is ambiguous. Found $($scan.Addresses.Count) matches."
}

$anchorAddress = [uint64]$scan.Addresses[0]
$baseAddress = $anchorAddress + [uint64]$AnchorBaseDelta
$blockSize = $Stride * $RecordCount

$block = Invoke-CliJson -Arguments @(
    'read',
    '--name', $ProcessName,
    '--address', $baseAddress.ToString(),
    '--value-kind', 'Bytes',
    '--size', $blockSize.ToString()
)

$bytes = Convert-HexToBytes -Hex $block.Value

if ($bytes.Length -lt $blockSize)
{
    throw "Expected $blockSize bytes from the remap table, but CLI returned $($bytes.Length)."
}

$records = for ($index = 0; $index -lt $RecordCount; $index++)
{
    $recordOffset = $index * $Stride
    $recordAddress = $baseAddress + [uint64]$recordOffset

    [pscustomobject]@{
        Index = $index
        RecordAddress = $recordAddress
        Slot = Read-UInt32Le -Bytes $bytes -Offset ($recordOffset + 0x00)
        CompetitionId = Read-UInt32Le -Bytes $bytes -Offset ($recordOffset + 0x04)
        Field06 = Read-UInt16Le -Bytes $bytes -Offset ($recordOffset + 0x06)
        Field0E = Read-UInt16Le -Bytes $bytes -Offset ($recordOffset + 0x0E)
        Field18 = Read-ByteValue -Bytes $bytes -Offset ($recordOffset + 0x18)
        Field19 = Read-ByteValue -Bytes $bytes -Offset ($recordOffset + 0x19)
        Field68 = Read-ByteValue -Bytes $bytes -Offset ($recordOffset + 0x68)
        CalendarByte100 = Read-ByteValue -Bytes $bytes -Offset ($recordOffset + 0x100)
        CalendarUInt32100 = Read-UInt32Le -Bytes $bytes -Offset ($recordOffset + 0x100)
    }
}

$targetRecord = $records | Where-Object CompetitionId -eq $CompetitionId | Select-Object -First 1

if (-not $targetRecord)
{
    throw "CompetitionId $CompetitionId was not found in the remap table block."
}

$anchorRecord = $records | Select-Object -First 1
$neighborStart = [Math]::Max(0, $targetRecord.Index - 1)
$neighborEnd = [Math]::Min($RecordCount - 1, $targetRecord.Index + 1)
$neighbors = $records[$neighborStart..$neighborEnd]

$result = [pscustomobject]@{
    ConfigPath = if (Test-Path $ConfigPath) { (Resolve-Path $ConfigPath).ProviderPath } else { $null }
    ProcessName = $ProcessName
    ModuleName = $ModuleName
    AnchorPattern = $AnchorPattern
    AnchorAddress = $anchorAddress
    OperationalBaseAddress = $baseAddress
    Stride = $Stride
    RecordCount = $RecordCount
    AnchorRecord = $anchorRecord
    TargetRecord = $targetRecord
    NeighborRecords = $neighbors
    AllRecords = if ($IncludeAllRecords) { @($records) } else { $null }
}

$result | ConvertTo-Json -Depth 5