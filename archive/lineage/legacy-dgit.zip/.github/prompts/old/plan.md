**Plano: API de Memória em C# + Servidor MCP**

O workspace está vazio, então tratei isso como greenfield. Mantive a escolha em C# e fechei o uso via MCP como um servidor MCP local em stdio, separado da engine de memória. A decisão central é: a lógica de leitura/escrita de memória fica numa biblioteca reutilizável, e o MCP vira só um adaptador sobre serviços de aplicação com contratos JSON-safe.

**Passos**
1. Bootstrap da solução. Criar uma solução .NET 8 x64 para Windows com estes projetos: Overmem.Abstractions, Overmem.Application, Overmem.Windows, Overmem.McpServer, Overmem.TestTarget e Overmem.Tests. Definir desde o início que a primeira versão falha explicitamente fora de Windows ou em bitness não suportada.
2. Definir os contratos públicos antes do Win32. Modelar ProcessSelector, AttachmentId, ModuleInfo, MemoryRegionInfo, PointerChain, PatternSignature, MemoryValueKind, ReadRequest, WriteRequest, MemoryEntryDefinition e erros/resultados. A API direta em C# pode ser tipada e genérica; a camada MCP precisa usar DTOs serializáveis e sem generics.
3. Implementar a engine Windows em uma camada isolada. Concentrar P/Invoke e structs nativas em wrappers pequenos sobre OpenProcess, ReadProcessMemory, WriteProcessMemory, VirtualQueryEx, VirtualProtectEx, enumeração de módulos e checagem de arquitetura. Usar SafeHandle, erros determinísticos e leitura orientada por páginas válidas.
4. Subir os serviços de alto nível. Adicionar attach/detach, catálogo de módulos, resolução de pointer chains, codecs de tipos, filtro de regiões, pattern scan e freeze/unfreeze. Esses serviços devem ser a única porta de entrada para UI, testes e MCP.
5. Adicionar a camada “tipo Cheat Table”, mas sem dependência de formato CE. Modelar entradas nomeadas com base relativa a módulo, offsets, tipo, encoding, refresh interval e frozen value opcional. Incluir refresh e freeze orchestration, mas deixar fora import/export de .CT na v1.
6. Construir o adaptador MCP como console separado. Usar o padrão do SDK C# com Host.CreateApplicationBuilder, AddMcpServer, WithStdioServerTransport e WithTools. Expor tools como attach_process, detach_process, list_modules, list_regions, resolve_pointer, read_value, write_value, scan_pattern, load_table, refresh_table, freeze_entry e unfreeze_entry.
7. Fechar os detalhes operacionais do MCP. Manter um registro em memória de attachments por AttachmentId, nunca expor handle bruto no protocolo, mandar logs só para stderr, suportar cancellation nos scans longos e habilitar task store em memória para operações demoradas.
8. Criar um processo-alvo próprio para integração. O TestTarget deve alocar valores, strings, arrays e cadeias de ponteiros conhecidas, além de informar PID e endereços esperados para os testes. Isso evita depender de executáveis terceiros.
9. Documentar e empacotar. README com limites, arquitetura suportada, uso direto da library, inicialização do servidor MCP, contratos das tools e opções de segurança. Entregar Overmem.McpServer como executável local para clientes MCP e as libraries como artefatos reutilizáveis.

**Arquivos planejados**
- d:\git\overmem\Overmem.sln — solução e referências entre projetos
- d:\git\overmem\src\Overmem.Abstractions\Overmem.Abstractions.csproj — contratos e interfaces
- d:\git\overmem\src\Overmem.Abstractions\Processes\ProcessSelector.cs — seleção de processo e attachment
- d:\git\overmem\src\Overmem.Abstractions\Memory\PointerChain.cs — base relativa + offsets
- d:\git\overmem\src\Overmem.Abstractions\Memory\MemoryValueKind.cs — sistema de tipos para MCP
- d:\git\overmem\src\Overmem.Application\Overmem.Application.csproj — casos de uso
- d:\git\overmem\src\Overmem.Application\Tables\MemoryEntryDefinition.cs — modelo de entrada estilo table
- d:\git\overmem\src\Overmem.Application\Tables\TableService.cs — refresh/freeze de múltiplas entradas
- d:\git\overmem\src\Overmem.Windows\Overmem.Windows.csproj — implementação Windows-only
- d:\git\overmem\src\Overmem.Windows\Interop\Kernel32Native.cs — P/Invoke
- d:\git\overmem\src\Overmem.Windows\Processes\WindowsProcessSession.cs — ciclo de vida do handle
- d:\git\overmem\src\Overmem.Windows\Memory\WindowsMemoryAccessor.cs — read/write page-aware
- d:\git\overmem\src\Overmem.Windows\Memory\PointerResolver.cs — resolução de ponteiros
- d:\git\overmem\src\Overmem.Windows\Scanning\PatternScanner.cs — varredura por assinatura
- d:\git\overmem\src\Overmem.McpServer\Overmem.McpServer.csproj — host MCP local
- d:\git\overmem\src\Overmem.McpServer\Program.cs — composição DI, transporte e logging
- d:\git\overmem\src\Overmem.McpServer\Tools\ProcessTools.cs — attach/detach/list
- d:\git\overmem\src\Overmem.McpServer\Tools\MemoryTools.cs — read/write/resolve
- d:\git\overmem\src\Overmem.McpServer\Tools\TableTools.cs — table/load/refresh/freeze
- d:\git\overmem\tests\Overmem.TestTarget\Overmem.TestTarget.csproj — alvo controlado para integração
- d:\git\overmem\tests\Overmem.TestTarget\Program.cs — valores e ponteiros conhecidos
- d:\git\overmem\tests\Overmem.Tests\Overmem.Tests.csproj — testes unitários e integração
- d:\git\overmem\tests\Overmem.Tests\WindowsMemoryAccessorTests.cs — leitura/escrita tipada
- d:\git\overmem\tests\Overmem.Tests\McpServerIntegrationTests.cs — validação MCP
- d:\git\overmem\README.md — arquitetura, setup e limites

**Verificação**
1. Build x64 da solução e falha explícita em ambiente não suportado.
2. Testes de attach, read, write, resolve_pointer e detach contra o TestTarget.
3. Testes de pattern scan com cancelamento e cleanup de task longa.
4. Testes de freeze/unfreeze validando restauração do valor e parada do worker.
5. Teste de integração do servidor MCP em stdio cobrindo initialize, tools/list, attach_process, read_value, write_value, scan_pattern e detach_process.
6. Verificação de que stdout carrega só mensagens MCP e stderr recebe logs.
7. Teste explícito de bitness incompatível com erro previsível.
8. Um fluxo manual fim a fim de cliente MCP local contra o TestTarget.

**Decisões**
- C# em .NET 8, Windows-only, x64-first.
- MCP local em stdio na v1; sem HTTP remoto na primeira entrega.
- Win32 fica isolado em Overmem.Windows; o MCP não conhece detalhes nativos.
- O protocolo MCP usa AttachmentId e DTOs, não handles nem métodos genéricos.
- A v1 exclui driver/kernel, bypass de proteção, evasão de anti-cheat, injeção remota, patching de código e compatibilidade nativa com arquivos do Cheat Engine.
- A camada table entra na v1, mas sem tentar cobrir toda a superfície de CE.

Salvei esse plano em /memories/session/plan.md. Se quiser, eu ajusto agora o corte de escopo antes do handoff, por exemplo x86 mais cedo, ou MCP com write/freeze liberado por padrão em vez de ficar atrás de configuração.